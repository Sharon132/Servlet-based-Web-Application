public class TransactionPayment {
    private int orderId;
    private String loginId;
    private String customerName;
    private int customerAge;
    private String customerOccupation;

    private String creditCard;
    private String orderDate;
    private String expectedDate;
    private String actualDate;
    private String productId;

    private String productName;
    private String category;
    private String retailer;
    private int reviewRating;
    private String deliveryId;

    private String deliveryType;
    private String deliveryZip;
    private String transactionStatus;
    private String orderReturned;
    private String deliveryOnTime;

    public TransactionPayment(int orderId, String loginId, String customerName, int customerAge, String customerOccupation, String creditCard, String orderDate, String expectedDate, String actualDate, String productId, String productName, String category, String retailer, int reviewRating, String deliveryId, String deliveryType, String deliveryZip, String transactionStatus, String orderReturned, String deliveryOnTime) {
        this.orderId = orderId;
        this.loginId = loginId;
        this.customerName = customerName;
        this.customerAge = customerAge;
        this.customerOccupation = customerOccupation;
        this.creditCard = creditCard;
        this.orderDate = orderDate;
        this.expectedDate = expectedDate;
        this.actualDate = actualDate;
        this.productId = productId;
        this.productName = productName;
        this.category = category;
        this.retailer = retailer;
        this.reviewRating = reviewRating;
        this.deliveryId = deliveryId;
        this.deliveryType = deliveryType;
        this.deliveryZip = deliveryZip;
        this.transactionStatus = transactionStatus;
        this.orderReturned = orderReturned;
        this.deliveryOnTime = deliveryOnTime;
    }

    public TransactionPayment(int orderId, int customerAge, int reviewRating, String loginId, String customerName, String customerOccupation, String productId, String productName, String category, String retailer, String transactionStatus, String orderReturned, String deliveryZip) {
        this.orderId = orderId;
        this.loginId = loginId;
        this.customerName = customerName;
        this.customerAge = customerAge;
        this.customerOccupation = customerOccupation;
        this.productId = productId;
        this.productName = productName;
        this.category = category;
        this.retailer = retailer;
        this.reviewRating = reviewRating;
        this.transactionStatus = transactionStatus;
        this.orderReturned = orderReturned;
        this.deliveryZip = deliveryZip;
    }

    public int getOrderId() {
        return orderId;
    }

    public void setOrderId(int orderId) {
        this.orderId = orderId;
    }

    public String getLoginId() {
        return loginId;
    }

    public void setLoginId(String loginId) {
        this.loginId = loginId;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public int getCustomerAge() {
        return customerAge;
    }

    public void setCustomerAge(int customerAge) {
        this.customerAge = customerAge;
    }

    public String getCustomerOccupation() {
        return customerOccupation;
    }

    public void setCustomerOccupation(String customerOccupation) {
        this.customerOccupation = customerOccupation;
    }

    public String getCreditCard() {
        return creditCard;
    }

    public void setCreditCard(String creditCard) {
        this.creditCard = creditCard;
    }

    public String getOrderDate() {
        return orderDate;
    }

    public void setOrderDate(String orderDate) {
        this.orderDate = orderDate;
    }

    public String getExpectedDate() {
        return expectedDate;
    }

    public void setExpectedDate(String expectedDate) {
        this.expectedDate = expectedDate;
    }

    public String getActualDate() {
        return actualDate;
    }

    public void setActualDate(String actualDate) {
        this.actualDate = actualDate;
    }

    public String getProductId() {
        return productId;
    }

    public void setProductId(String productId) {
        this.productId = productId;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getRetailer() {
        return retailer;
    }

    public void setRetailer(String retailer) {
        this.retailer = retailer;
    }

    public int getReviewRating() {
        return reviewRating;
    }

    public void setReviewRating(int reviewRating) {
        this.reviewRating = reviewRating;
    }

    public String getDeliveryId() {
        return deliveryId;
    }

    public void setDeliveryId(String deliveryId) {
        this.deliveryId = deliveryId;
    }

    public String getDeliveryType() {
        return deliveryType;
    }

    public void setDeliveryType(String deliveryType) {
        this.deliveryType = deliveryType;
    }

    public String getDeliveryZip() {
        return deliveryZip;
    }

    public void setDeliveryZip(String deliveryZip) {
        this.deliveryZip = deliveryZip;
    }

    public String getTransactionStatus() {
        return transactionStatus;
    }

    public void setTransactionStatus(String transactionStatus) {
        this.transactionStatus = transactionStatus;
    }

    public String getOrderReturned() {
        return orderReturned;
    }

    public void setOrderReturned(String orderReturned) {
        this.orderReturned = orderReturned;
    }

    public String getDeliveryOnTime() {
        return deliveryOnTime;
    }

    public void setDeliveryOnTime(String deliveryOnTime) {
        this.deliveryOnTime = deliveryOnTime;
    }
}
