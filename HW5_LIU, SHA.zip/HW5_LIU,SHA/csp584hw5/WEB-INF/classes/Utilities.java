import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.io.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


import java.io.File;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.xml.sax.SAXException;

@WebServlet("/Utilities")

/* 
	Utilities class contains class variables of type HttpServletRequest, PrintWriter,String and HttpSession.

	Utilities class has a constructor with  HttpServletRequest, PrintWriter variables.
	  
*/

public class Utilities extends HttpServlet {
    HttpServletRequest req;
    PrintWriter pw;
    String url;
    HttpSession session;

    public Utilities() {
    }

    public Utilities(HttpServletRequest req, PrintWriter pw) {
        this.req = req;
        this.pw = pw;
        this.url = this.getFullURL();
        this.session = req.getSession(true);
    }



	/*  Printhtml Function gets the html file name as function Argument, 
		If the html file name is Header.html then It gets Username from session variables.
		Account ,Cart Information ang Logout Options are Displayed*/

    public void printHtml(String file) {
        String result = HtmlToString(file);
        //to print the right navigation in header of username cart and logout etc
        if (file.equals("Header.html")) {
            result = result + "<div id='menu'><ul>";
            if (session.getAttribute("username") != null) {
                String username = session.getAttribute("username").toString();
                username = Character.toUpperCase(username.charAt(0)) + username.substring(1);

                String userType = session.getAttribute("userType").toString();
                switch (userType) {
                    case "Customer":
                        result = result + "<li><a><span class='glyphicon'>Hello, " + username + "</span></a></li>"
                                + "<li><a href='Account'><span class='glyphicon'>Account</span></a></li>"
                                + "<li><a href='Logout'><span class='glyphicon'>Logout</span></a></li>";
                        break;
                    case "StoreManager":
                        result = result + "<li><a href='StoreManagerHome'><span class='glyphicon'>ViewProduct</span></a></li>"
                                + "<li><a><span class='glyphicon'>Hello, " + username + "</span></a></li>"
                                + "<li><a href='Inventory'><span class='glyphicon'>InventoryReport</span></a></li>"
                                + "<li><a href='SalesReport'><span class='glyphicon'>SalesReport</span></a></li>"
                                + "<li><a href='Logout'><span class='glyphicon'>Logout</span></a></li>";
                        break;
                    case "Salesman":
                        result = result + "<li><a href='SalesmanHome'><span class='glyphicon'>ViewOrder</span></a></li>"
                                + "<li><a><span class='glyphicon'>Hello, " + username + "</span></a></li>"
                                + "<li><a href='Logout'><span class='glyphicon'>Logout</span></a></li>";
                        break;
                }
            } else
                result = result + "<li><a href='ViewOrder'><span class='glyphicon'>ViewOrder</span></a></li>" + "<li><a href='Login'><span class='glyphicon'>Login</span></a></li>";
            result = result + "<li><a href='Cart'><span class='glyphicon'>Cart(" + CartCount() + ")</span></a></li></ul></div></div></div><div id='page'>";
            pw.print(result);
        } else
            pw.print(result);
    }

    /*  getFullURL Function - Reconstructs the URL user request  */

    public String getFullURL() {
        String scheme = req.getScheme();
        String serverName = req.getServerName();
        int serverPort = req.getServerPort();
        String contextPath = req.getContextPath();
        StringBuffer url = new StringBuffer();
        url.append(scheme).append("://").append(serverName);

        if ((serverPort != 80) && (serverPort != 443)) {
            url.append(":").append(serverPort);
        }
        url.append(contextPath);
        url.append("/");
        return url.toString();
    }

    /*  HtmlToString - Gets the Html file and Converts into String and returns the String.*/
    public String HtmlToString(String file) {
        String result = null;
        try {
            String webPage = url + file;
            URL url = new URL(webPage);
            URLConnection urlConnection = url.openConnection();
            InputStream is = urlConnection.getInputStream();
            InputStreamReader isr = new InputStreamReader(is);

            int numCharsRead;
            char[] charArray = new char[1024];
            StringBuffer sb = new StringBuffer();
            while ((numCharsRead = isr.read(charArray)) > 0) {
                sb.append(charArray, 0, numCharsRead);
            }
            result = sb.toString();
        } catch (Exception ignored) {
        }
        return result;
    }

    /*  logout Function removes the username , usertype attributes from the session variable*/

    public void logout() {
        session.removeAttribute("username");
        session.removeAttribute("usertype");
    }

    /*  logout Function checks whether the user is loggedIn or Not*/

    public boolean isLoggedin() {
        return session.getAttribute("username") != null;
    }

    public boolean isItemExist(String itemCatalog, String itemName) {

        HashMap<String, Object> hm = new HashMap<String, Object>();

        switch (itemCatalog) {
            case "FitnessWatch":
                hm.putAll(SaxParserDataStore.fitnesses);
                break;
            case "SmartWatch":
                hm.putAll(SaxParserDataStore.smarts);
                break;
            case "VirtualReality":
                hm.putAll(SaxParserDataStore.virtuals);
                break;
            case "PetTracker":
                hm.putAll(SaxParserDataStore.pets);
                break;
            case "Headphone":
                hm.putAll(SaxParserDataStore.headphones);
                break;
            case "Phone":
                hm.putAll(SaxParserDataStore.phones);
                break;
            case "Laptop":
                hm.putAll(SaxParserDataStore.laptops);
                break;
            case "VoiceAssistant":
                hm.putAll(SaxParserDataStore.voices);
                break;
            case "Accessory":
                hm.putAll(SaxParserDataStore.accessories);
                break;
        }
        return true;
    }

    public String getRealPath(String catalog) {
        String realPath = "images";
        switch (catalog) {
            case "FitnessWatch":
                realPath = realPath + "/FitnessWatch";
                break;
            case "SmartWatch":
                realPath = realPath + "/SmartWatch";
                break;
            case "VirtualReality":
                realPath = realPath + "/VirtualReality";
                break;
            case "PetTracker":
                realPath = realPath + "/PetTracker";
                break;
            case "Headphone":
                realPath = realPath + "/Headphone";
                break;
            case "TV":
                realPath = realPath + "/TV";
                break;
            case "SoundSystem":
                realPath = realPath + "/SoundSystem";
                break;
            case "Phone":
                realPath = realPath + "/Phone";
                break;
            case "Laptop":
                realPath = realPath + "/Laptop";
                break;
            case "VoiceAssistant":
                realPath = realPath + "/VoiceAssistant";
                break;
            case "Accessory":
                realPath = realPath + "/Accessory";
                break;
        }

        return realPath;
    }

    public boolean storeNewProduct(Map<String, Object> map) {
        String id = String.valueOf(map.get("id"));
        String name = String.valueOf(map.get("name"));
        double price = Double.parseDouble(String.valueOf(map.get("price")));
        String image = String.valueOf(map.get("image"));
        String retailer = String.valueOf(map.get("manufacturer"));
        String condition = String.valueOf(map.get("condition"));
        double discount = Double.parseDouble(String.valueOf(map.get("discount")));
        String productType = String.valueOf(map.get("productCatalog"));
        double rebates = Double.parseDouble(String.valueOf(map.get("rebates")));
        int inventory = Integer.parseInt(String.valueOf(map.get("inventory")));

        switch (productType) {
            case "FitnessWatch":
                FitnessWatch fitnessWatch = new FitnessWatch();
                fitnessWatch.setId(id);
                fitnessWatch.setName(name);
                fitnessWatch.setPrice(price);
                fitnessWatch.setImage(image);
                fitnessWatch.setRetailer(retailer);
                fitnessWatch.setCondition(condition);
                fitnessWatch.setDiscount(discount);
                fitnessWatch.setRebates(rebates);
                fitnessWatch.setInventory(inventory);
                SaxParserDataStore.fitnesses.put(id, fitnessWatch);
                MySqlDataStoreUtilities.insertProduct(productType, id, name, price, image, retailer, condition, discount, rebates, inventory);
                return true;
            case "SmartWatch":
                SmartWatch smartWatch = new SmartWatch();
                smartWatch.setId(id);
                smartWatch.setName(name);
                smartWatch.setPrice(price);
                smartWatch.setImage(image);
                smartWatch.setRetailer(retailer);
                smartWatch.setCondition(condition);
                smartWatch.setDiscount(discount);
                smartWatch.setRebates(rebates);
                smartWatch.setInventory(inventory);
                SaxParserDataStore.smarts.put(id, smartWatch);
                MySqlDataStoreUtilities.insertProduct(productType, id, name, price, image, retailer, condition, discount, rebates, inventory);
                return true;
            case "VirtualReality":
                VirtualReality virtualReality = new VirtualReality();
                virtualReality.setId(id);
                virtualReality.setName(name);
                virtualReality.setPrice(price);
                virtualReality.setImage(image);
                virtualReality.setRetailer(retailer);
                virtualReality.setCondition(condition);
                virtualReality.setDiscount(discount);
                virtualReality.setRebates(rebates);
                virtualReality.setInventory(inventory);
                SaxParserDataStore.virtuals.put(id, virtualReality);
                MySqlDataStoreUtilities.insertProduct(productType, id, name, price, image, retailer, condition, discount, rebates, inventory);
                return true;
            case "PetTracker":
                PetTracker petTracker = new PetTracker();
                petTracker.setId(id);
                petTracker.setName(name);
                petTracker.setPrice(price);
                petTracker.setImage(image);
                petTracker.setRetailer(retailer);
                petTracker.setCondition(condition);
                petTracker.setDiscount(discount);
                petTracker.setRebates(rebates);
                petTracker.setInventory(inventory);
                SaxParserDataStore.pets.put(id, petTracker);
                MySqlDataStoreUtilities.insertProduct(productType, id, name, price, image, retailer, condition, discount, rebates, inventory);
                return true;
            case "Headphone":
                Headphone headphone = new Headphone();
                headphone.setId(id);
                headphone.setName(name);
                headphone.setPrice(price);
                headphone.setImage(image);
                headphone.setRetailer(retailer);
                headphone.setCondition(condition);
                headphone.setDiscount(discount);
                headphone.setRebates(rebates);
                headphone.setInventory(inventory);
                SaxParserDataStore.headphones.put(id, headphone);
                MySqlDataStoreUtilities.insertProduct(productType, id, name, price, image, retailer, condition, discount, rebates, inventory);
                return true;
            case "TV":
                TV tv = new TV();
                tv.setId(id);
                tv.setName(name);
                tv.setPrice(price);
                tv.setImage(image);
                tv.setRetailer(retailer);
                tv.setCondition(condition);
                tv.setDiscount(discount);
                tv.setRebates(rebates);
                tv.setInventory(inventory);
                SaxParserDataStore.tvs.put(id, tv);
                MySqlDataStoreUtilities.insertProduct(productType, id, name, price, image, retailer, condition, discount, rebates, inventory);
                return true;
            case "SoundSystem":
                SoundSystem soundSystem = new SoundSystem();
                soundSystem.setId(id);
                soundSystem.setName(name);
                soundSystem.setPrice(price);
                soundSystem.setImage(image);
                soundSystem.setRetailer(retailer);
                soundSystem.setCondition(condition);
                soundSystem.setDiscount(discount);
                soundSystem.setRebates(rebates);
                soundSystem.setInventory(inventory);
                SaxParserDataStore.sounds.put(id, soundSystem);
                MySqlDataStoreUtilities.insertProduct(productType, id, name, price, image, retailer, condition, discount, rebates, inventory);
                return true;
            case "Phone":
                Phone phone = new Phone();
                phone.setId(id);
                phone.setName(name);
                phone.setPrice(price);
                phone.setImage(image);
                phone.setRetailer(retailer);
                phone.setCondition(condition);
                phone.setDiscount(discount);
                phone.setRebates(rebates);
                phone.setInventory(inventory);
                SaxParserDataStore.phones.put(id, phone);
                MySqlDataStoreUtilities.insertProduct(productType, id, name, price, image, retailer, condition, discount, rebates, inventory);
                return true;
            case "Laptop":
                Laptop laptop = new Laptop();
                laptop.setId(id);
                laptop.setName(name);
                laptop.setPrice(price);
                laptop.setImage(image);
                laptop.setRetailer(retailer);
                laptop.setCondition(condition);
                laptop.setDiscount(discount);
                laptop.setRebates(rebates);
                laptop.setInventory(inventory);
                SaxParserDataStore.laptops.put(id, laptop);
                MySqlDataStoreUtilities.insertProduct(productType, id, name, price, image, retailer, condition, discount, rebates, inventory);
                return true;
            case "VoiceAssistant":
                VoiceAssistant voiceAssistant = new VoiceAssistant();
                voiceAssistant.setId(id);
                voiceAssistant.setName(name);
                voiceAssistant.setPrice(price);
                voiceAssistant.setImage(image);
                voiceAssistant.setRetailer(retailer);
                voiceAssistant.setCondition(condition);
                voiceAssistant.setDiscount(discount);
                voiceAssistant.setRebates(rebates);
                voiceAssistant.setInventory(inventory);
                SaxParserDataStore.voices.put(id, voiceAssistant);
                MySqlDataStoreUtilities.insertProduct(productType, id, name, price, image, retailer, condition, discount, rebates, inventory);
                return true;
            case "Accessory":
                Accessory accessory = new Accessory();
                accessory.setId(id);
                accessory.setName(name);
                accessory.setPrice(price);
                accessory.setImage(image);
                accessory.setRetailer(retailer);
                accessory.setCondition(condition);
                accessory.setDiscount(discount);
                accessory.setRebates(rebates);
                accessory.setInventory(inventory);
                SaxParserDataStore.accessories.put(id, accessory);
                MySqlDataStoreUtilities.insertProduct(productType, id, name, price, image, retailer, condition, discount, rebates, inventory);
                return true;
        }
        return false;
    }

    public boolean removeProduct(String productId, String catalog) {
        switch (catalog) {
            case "FitnessWatch":
                SaxParserDataStore.fitnesses.remove(productId);
                return true;
            case "SmartWatch":

                SaxParserDataStore.smarts.remove(productId);
                return true;
            case "VirtualReality":

                SaxParserDataStore.virtuals.remove(productId);
                return true;
            case "PetTracker":

                SaxParserDataStore.pets.remove(productId);
                return true;
            case "Headphone":

                SaxParserDataStore.headphones.remove(productId);
                return true;
            case "TV":

                SaxParserDataStore.tvs.remove(productId);
                return true;
            case "SoundSystem":

                SaxParserDataStore.sounds.remove(productId);
                return true;
            case "Phone":

                SaxParserDataStore.phones.remove(productId);
                return true;
            case "Laptop":

                SaxParserDataStore.laptops.remove(productId);
                return true;
            case "VoiceAssistant":

                SaxParserDataStore.voices.remove(productId);
                return true;
            case "Accessory":

                SaxParserDataStore.accessories.remove(productId);
                return true;
        }
        return false;
    }

    public boolean updateProduct(String id, String name, String price, String manufacturer, String condition, String discount, String image, String catalog, String rebates, String inventory) {

        switch (catalog) {
            case "FitnessWatch":
                SaxParserDataStore.fitnesses.remove(id);
                FitnessWatch fitnessWatch = new FitnessWatch();
                fitnessWatch.setId(id);
                fitnessWatch.setName(name);
                fitnessWatch.setPrice(Double.parseDouble(price));
                fitnessWatch.setRetailer(manufacturer);
                fitnessWatch.setCondition(condition);
                fitnessWatch.setDiscount(Double.parseDouble(discount));
                fitnessWatch.setImage(image);
                fitnessWatch.setRebates(Double.parseDouble(rebates));
                fitnessWatch.setInventory(Integer.parseInt(inventory));
                SaxParserDataStore.fitnesses.put(id, fitnessWatch);
                MySqlDataStoreUtilities.insertProduct(catalog, id, name, Double.parseDouble(price), image, manufacturer, condition, Double.parseDouble(discount), Double.parseDouble(rebates), Integer.parseInt(inventory));

                return true;
            case "SmartWatch":

                SmartWatch smartWatch = new SmartWatch();
                smartWatch.setId(id);
                smartWatch.setName(name);
                smartWatch.setPrice(Double.parseDouble(price));
                smartWatch.setRetailer(manufacturer);
                smartWatch.setCondition(condition);
                smartWatch.setDiscount(Double.parseDouble(discount));
                smartWatch.setImage(image);
                smartWatch.setRebates(Double.parseDouble(rebates));
                smartWatch.setInventory(Integer.parseInt(inventory));
                SaxParserDataStore.smarts.remove(id);
                SaxParserDataStore.smarts.put(id, smartWatch);
                return true;
            case "VirtualReality":

                VirtualReality virtualReality = new VirtualReality();
                virtualReality.setId(id);
                virtualReality.setName(name);
                virtualReality.setPrice(Double.parseDouble(price));
                virtualReality.setRetailer(manufacturer);
                virtualReality.setCondition(condition);
                virtualReality.setDiscount(Double.parseDouble(discount));
                virtualReality.setImage(image);
                virtualReality.setRebates(Double.parseDouble(rebates));
                virtualReality.setInventory(Integer.parseInt(inventory));
                SaxParserDataStore.virtuals.remove(id);
                SaxParserDataStore.virtuals.put(id, virtualReality);
                return true;
            case "PetTracker":

                PetTracker petTracker = new PetTracker();
                petTracker.setId(id);
                petTracker.setName(name);
                petTracker.setPrice(Double.parseDouble(price));
                petTracker.setRetailer(manufacturer);
                petTracker.setCondition(condition);
                petTracker.setDiscount(Double.parseDouble(discount));
                petTracker.setImage(image);
                petTracker.setRebates(Double.parseDouble(rebates));
                petTracker.setInventory(Integer.parseInt(inventory));
                SaxParserDataStore.pets.remove(id);
                SaxParserDataStore.pets.put(id, petTracker);
                return true;
            case "Headphone":

                Headphone headphone = new Headphone();
                headphone.setId(id);
                headphone.setName(name);
                headphone.setPrice(Double.parseDouble(price));
                headphone.setRetailer(manufacturer);
                headphone.setCondition(condition);
                headphone.setDiscount(Double.parseDouble(discount));
                headphone.setImage(image);
                headphone.setRebates(Double.parseDouble(rebates));
                headphone.setInventory(Integer.parseInt(inventory));
                SaxParserDataStore.headphones.remove(id);
                SaxParserDataStore.headphones.put(id, headphone);
                return true;
            case "TV":

                TV tv = new TV();
                tv.setId(id);
                tv.setName(name);
                tv.setPrice(Double.parseDouble(price));
                tv.setRetailer(manufacturer);
                tv.setCondition(condition);
                tv.setDiscount(Double.parseDouble(discount));
                tv.setImage(image);
                tv.setRebates(Double.parseDouble(rebates));
                tv.setInventory(Integer.parseInt(inventory));
                SaxParserDataStore.tvs.remove(id);
                SaxParserDataStore.tvs.put(id, tv);
                return true;
            case "SoundSystem":

                SoundSystem soundSystem = new SoundSystem();
                soundSystem.setId(id);
                soundSystem.setName(name);
                soundSystem.setPrice(Double.parseDouble(price));
                soundSystem.setRetailer(manufacturer);
                soundSystem.setCondition(condition);
                soundSystem.setDiscount(Double.parseDouble(discount));
                soundSystem.setImage(image);
                soundSystem.setRebates(Double.parseDouble(rebates));
                soundSystem.setInventory(Integer.parseInt(inventory));
                SaxParserDataStore.sounds.remove(id);
                SaxParserDataStore.sounds.put(id, soundSystem);
                return true;
            case "Phone":

                Phone phone = new Phone();
                phone.setId(id);
                phone.setName(name);
                phone.setPrice(Double.parseDouble(price));
                phone.setRetailer(manufacturer);
                phone.setCondition(condition);
                phone.setDiscount(Double.parseDouble(discount));
                phone.setImage(image);
                phone.setRebates(Double.parseDouble(rebates));
                phone.setInventory(Integer.parseInt(inventory));
                SaxParserDataStore.phones.remove(id);
                SaxParserDataStore.phones.put(id, phone);
                return true;
            case "Laptop":

                Laptop laptop = new Laptop();
                laptop.setId(id);
                laptop.setName(name);
                laptop.setPrice(Double.parseDouble(price));
                laptop.setRetailer(manufacturer);
                laptop.setCondition(condition);
                laptop.setDiscount(Double.parseDouble(discount));
                laptop.setImage(image);
                laptop.setRebates(Double.parseDouble(rebates));
                laptop.setInventory(Integer.parseInt(inventory));
                SaxParserDataStore.laptops.remove(id);
                SaxParserDataStore.laptops.put(id, laptop);
                return true;
            case "VoiceAssistant":

                VoiceAssistant voiceAssistant = new VoiceAssistant();
                voiceAssistant.setId(id);
                voiceAssistant.setName(name);
                voiceAssistant.setPrice(Double.parseDouble(price));
                voiceAssistant.setRetailer(manufacturer);
                voiceAssistant.setCondition(condition);
                voiceAssistant.setDiscount(Double.parseDouble(discount));
                voiceAssistant.setImage(image);
                voiceAssistant.setRebates(Double.parseDouble(rebates));
                voiceAssistant.setInventory(Integer.parseInt(inventory));
                SaxParserDataStore.voices.remove(id);
                SaxParserDataStore.voices.put(id, voiceAssistant);
                return true;
            case "Accessory":

                Accessory accessory = new Accessory();
                accessory.setId(id);
                accessory.setName(name);
                accessory.setPrice(Double.parseDouble(price));
                accessory.setRetailer(manufacturer);
                accessory.setCondition(condition);
                accessory.setDiscount(Double.parseDouble(discount));
                accessory.setImage(image);
                accessory.setRebates(Double.parseDouble(rebates));
                accessory.setInventory(Integer.parseInt(inventory));
                SaxParserDataStore.accessories.remove(id);
                SaxParserDataStore.accessories.put(id, accessory);
                return true;
        }
        return false;
    }

    public boolean isContainsStr(String string) {
        String regex = ".*[a-zA-Z]+.*";
        Matcher m = Pattern.compile(regex).matcher(string);
        return m.matches();
    }

    /*  username Function returns the username from the session variable.*/

    public String username() {
        if (session.getAttribute("username") != null)
            return session.getAttribute("username").toString();
        return null;
    }

    /*  usertype Function returns the usertype from the session variable.*/
    public String usertype() {
        if (session.getAttribute("usertype") != null)
            return session.getAttribute("usertype").toString();
        return null;
    }

    /*  getUser Function checks the user is a customer or retailer or manager and returns the user class variable.*/
    public User getUser() {
        String usertype = usertype();
        HashMap<String, User> hm = new HashMap<String, User>();
        hm = MySqlDataStoreUtilities.selectUser();

        return hm.get(username());
    }

    /*  getCustomerOrders Function gets  the Orders for the user*/
    public ArrayList<OrderItem> getCustomerOrders() {
        ArrayList<OrderItem> order = new ArrayList<OrderItem>();
        if (OrdersHashMap.orders.containsKey(username()))
            order = OrdersHashMap.orders.get(username());
        return order;
    }

    public HashMap<String, Integer> getOrders() {
        HashMap<String, Integer> orders = new HashMap<>();
        ArrayList<OrderItem> orderList = getCustomerOrders();
        for (OrderItem item : orderList) {
            orders.put(item.getName(), orders.getOrDefault(item.getName(), 0) + 1);
        }
        return orders;
    }

    /*  getOrdersPaymentSize Function gets  the size of OrderPayment */
    public int getOrderPaymentSize() {
        HashMap<Integer, ArrayList<OrderPayment>> orderPayments = new HashMap<Integer, ArrayList<OrderPayment>>();
        try {
            orderPayments = MySqlDataStoreUtilities.selectOrder();
        } catch (Exception ignored) {

        }
        int size = 0;
        for (Map.Entry<Integer, ArrayList<OrderPayment>> entry : orderPayments.entrySet()) {
            size = size + 1;

        }
        return size;
    }

    /*  CartCount Function gets the size of User Orders*/
    public int CartCount() {
        if (isLoggedin())
            return getCustomerOrders().size();
        return 0;
    }


    public void removeItemFromCart(String itemName) {
        ArrayList<OrderItem> orderItems = OrdersHashMap.orders.get(username());
        int index = 0;

        //遍历所有orderItem，找到需要删除的item的index。
        for (OrderItem oi : orderItems) {
            if (oi.getName().equals(itemName)) {
                break;
            } else index++;
        }
        orderItems.remove(index);
    }

    /* StoreProduct Function stores the Purchased product in Orders HashMap according to the User Names.*/

    //todo
    public void storeProduct(String name, String type, String maker, String acc) {
        if (!OrdersHashMap.orders.containsKey(username())) {
            ArrayList<OrderItem> arr = new ArrayList<OrderItem>();
            OrdersHashMap.orders.put(username(), arr);
        }

        ArrayList<OrderItem> orderItems = OrdersHashMap.orders.get(username());
        HashMap<String, FitnessWatch> allfitnesses = new HashMap<String, FitnessWatch>();
        HashMap<String, SmartWatch> allsmarts = new HashMap<String, SmartWatch>();
        HashMap<String, Headphone> allheadphones = new HashMap<String, Headphone>();
        HashMap<String, VirtualReality> allvirtuals = new HashMap<String, VirtualReality>();
        HashMap<String, PetTracker> allpets = new HashMap<String, PetTracker>();
        HashMap<String, TV> alltvs = new HashMap<String, TV>();
        HashMap<String, SoundSystem> allsounds = new HashMap<String, SoundSystem>();
        HashMap<String, Phone> allphones = new HashMap<String, Phone>();
        HashMap<String, Laptop> alllaptops = new HashMap<String, Laptop>();
        HashMap<String, VoiceAssistant> allvoices = new HashMap<String, VoiceAssistant>();
        HashMap<String, Accessory> allaccessories = new HashMap<String, Accessory>();

        if (type.equals("FitnessWatch")) {
            FitnessWatch fitnessWatch;
            try {
                allfitnesses = MySqlDataStoreUtilities.getFitnessWatch();

            } catch (Exception e) {
                e.printStackTrace();
            }

            fitnessWatch = allfitnesses.get(name);
            OrderItem orderitem = new OrderItem(fitnessWatch.getName(), fitnessWatch.getPrice(), fitnessWatch.getImage(), fitnessWatch.getRetailer(), fitnessWatch.getDiscount(), fitnessWatch.getProductType());
            orderItems.add(orderitem);
        }

        if (type.equals("SmartWatch")) {
            SmartWatch smartWatch;
            try {
                allsmarts = MySqlDataStoreUtilities.getSmartWatch();

            } catch (Exception e) {
                e.printStackTrace();
            }

            smartWatch = allsmarts.get(name);
            OrderItem orderitem = new OrderItem(smartWatch.getName(), smartWatch.getPrice(), smartWatch.getImage(), smartWatch.getRetailer(), smartWatch.getDiscount(), smartWatch.getProductType());
            orderItems.add(orderitem);
        }

        if (type.equals("Headphone")) {
            Headphone headphone;
            try {
                allheadphones = MySqlDataStoreUtilities.getHeadphone();

            } catch (Exception e) {
                e.printStackTrace();
            }

            headphone = allheadphones.get(name);
            OrderItem orderitem = new OrderItem(headphone.getName(), headphone.getPrice(), headphone.getImage(), headphone.getRetailer(), headphone.getDiscount(), headphone.getProductType());
            orderItems.add(orderitem);
        }

        if (type.equals("VirtualReality")) {
            VirtualReality virtualReality;
            try {
                allvirtuals = MySqlDataStoreUtilities.getVirtualReality();

            } catch (Exception e) {
                e.printStackTrace();
            }

            virtualReality = allvirtuals.get(name);
            OrderItem orderitem = new OrderItem(virtualReality.getName(), virtualReality.getPrice(), virtualReality.getImage(), virtualReality.getRetailer(), virtualReality.getDiscount(), virtualReality.getProductType());
            orderItems.add(orderitem);
        }

        if (type.equals("PetTracker")) {
            PetTracker petTracker;
            try {
                allpets = MySqlDataStoreUtilities.getPetTracker();

            } catch (Exception e) {
                e.printStackTrace();
            }

            petTracker = allpets.get(name);
            OrderItem orderitem = new OrderItem(petTracker.getName(), petTracker.getPrice(), petTracker.getImage(), petTracker.getRetailer(), petTracker.getDiscount(), petTracker.getProductType());
            orderItems.add(orderitem);
        }

        if (type.equals("TV")) {
            TV tv;
            try {
                alltvs = MySqlDataStoreUtilities.getTV();

            } catch (Exception e) {
                e.printStackTrace();
            }

            tv = alltvs.get(name);
            // OrderItem orderitem = new OrderItem(phone.getName(), phone.getPrice(), phone.getImage(), phone.getRetailer());
            OrderItem orderitem = new OrderItem(tv.getId(), tv.getPrice(), tv.getImage(), tv.getRetailer(), tv.getDiscount(), tv.getProductType());
            orderItems.add(orderitem);
        }

        if (type.equals("SoundSystem")) {
            SoundSystem soundSystem;
            try {
                allsounds = MySqlDataStoreUtilities.getSoundSystem();

            } catch (Exception e) {
                e.printStackTrace();
            }

            soundSystem = allsounds.get(name);
            // OrderItem orderitem = new OrderItem(phone.getName(), phone.getPrice(), phone.getImage(), phone.getRetailer());
            OrderItem orderitem = new OrderItem(soundSystem.getId(), soundSystem.getPrice(), soundSystem.getImage(), soundSystem.getRetailer(), soundSystem.getDiscount(), soundSystem.getProductType());
            orderItems.add(orderitem);
        }

        if (type.equals("Phone")) {
            Phone phone;
            try {
                allphones = MySqlDataStoreUtilities.getPhoneAcc();

            } catch (Exception e) {
                e.printStackTrace();
            }

            phone = allphones.get(name);
            // OrderItem orderitem = new OrderItem(phone.getName(), phone.getPrice(), phone.getImage(), phone.getRetailer());
            OrderItem orderitem = new OrderItem(phone.getId(), phone.getPrice(), phone.getImage(), phone.getRetailer(), phone.getDiscount(), phone.getProductType());
            orderItems.add(orderitem);
        }
        if (type.equals("Laptop")) {
            Laptop laptop;
            try {
                alllaptops = MySqlDataStoreUtilities.getLaptop();

            } catch (Exception e) {
                e.printStackTrace();
            }

            laptop = alllaptops.get(name);
            OrderItem orderitem = new OrderItem(laptop.getName(), laptop.getPrice(), laptop.getImage(), laptop.getRetailer(), laptop.getDiscount(), laptop.getProductType());
            orderItems.add(orderitem);
        }
        if (type.equals("VoiceAssistant")) {
            VoiceAssistant voiceAssistant;
            try {
                allvoices = MySqlDataStoreUtilities.getVoiceAssistant();

            } catch (Exception e) {
                e.printStackTrace();
            }

            voiceAssistant = allvoices.get(name);
            OrderItem orderitem = new OrderItem(voiceAssistant.getName(), voiceAssistant.getPrice(), voiceAssistant.getImage(), voiceAssistant.getRetailer(), voiceAssistant.getDiscount(), voiceAssistant.getProductType());
            orderItems.add(orderitem);
        }

        if (type.equals("Accessory")) {
            Accessory accessory;
            try {
                allaccessories = MySqlDataStoreUtilities.getAccessory();

            } catch (Exception e) {
                e.printStackTrace();
            }

            accessory = allaccessories.get(name);
            OrderItem orderitem = new OrderItem(accessory.getName(), accessory.getPrice(), accessory.getImage(), accessory.getRetailer(), accessory.getDiscount(), accessory.getProductType());
            orderItems.add(orderitem);
        }
    }


    public String getUsername() {
        return (String) session.getAttribute("username");
    }

    public void removeOldOrder(int orderId, String productName, String customerName) {
        MySqlDataStoreUtilities.deleteOrder(orderId, productName);
    }


    public HashMap<String, SoundSystem> getSoundSystems() {
        HashMap<String, SoundSystem> hm = new HashMap<String, SoundSystem>();
        hm.putAll(SaxParserDataStore.sounds);
        return hm;
    }

    /* getGames Functions returns the  Hashmap with all Phone in the store.*/

    public HashMap<String, Phone> getPhones() {
        HashMap<String, Phone> hm = new HashMap<String, Phone>();
        hm.putAll(SaxParserDataStore.phones);
        return hm;
    }

    /* getTablets Functions returns the Hashmap with all laptops in the store.*/

    public HashMap<String, Laptop> getLaptops() {
        HashMap<String, Laptop> hm = new HashMap<String, Laptop>();
        hm.putAll(SaxParserDataStore.laptops);
        return hm;
    }


    /* getVoiceAssistants Functions returns the Hashmap with all VoiceAssistants in the store.*/
    public HashMap<String, VoiceAssistant> getVoiceAssistants() {
        HashMap<String, VoiceAssistant> hm = new HashMap<String, VoiceAssistant>();
        hm.putAll(SaxParserDataStore.voices);
        return hm;
    }


    /* getProducts Functions returns the Arraylist of games in the store.*/

    public ArrayList<String> getProductsPhone() {
        ArrayList<String> ar = new ArrayList<String>();
        for (Map.Entry<String, Phone> entry : getPhones().entrySet()) {
            ar.add(entry.getValue().getName());
        }
        return ar;
    }

    /* getProducts Functions returns the Arraylist of Tablets in the store.*/

    public ArrayList<String> getProductsLaptops() {
        ArrayList<String> ar = new ArrayList<String>();
        for (Map.Entry<String, Laptop> entry : getLaptops().entrySet()) {
            ar.add(entry.getValue().getName());
        }
        return ar;
    }

    // store the payment details for orders
    public void storePayment(int user_id, String userName, String ShippingAddress, String creditCardNo, int orderId, String purchaseDay, String shippingDay, String name, String category, Integer quantity, double price, double shippingCost, double discount, double totalsales, String s, String storeLocation) {
        //转换Date
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
        Date d1 = null;
        Date d2 = null;
        try {
            d1 = formatter.parse(purchaseDay);
            d2 = formatter.parse(shippingDay);
        } catch (ParseException e) {
            e.printStackTrace();
        }

        //insert
        MySqlDataStoreUtilities.insertOrder(user_id, userName, ShippingAddress, creditCardNo, orderId, d1, d2, name, category, quantity, price, shippingCost, discount, totalsales, s, storeLocation);
    }


    public String storeReview(String productName, String productType, String productPrice, String storeID, String storeZip, String storeCity, String storeState, String productOnSale, String productMaker, String rebate,
                              String userName, String userAge, String userGender, String userOccupation, String reviewRating, String reviewDate, String reviewText) {
        ArrayList<TransactionPayment> transactions = new ArrayList<TransactionPayment>();
        String status = "Unknown";
        String returnedOrder = "Unknown";
        try{
            transactions = MySqlDataStoreUtilities.selectTransactions();
            for(TransactionPayment t:transactions){
                if(t.getProductId().equals(productName)&&t.getLoginId().equals(userName)&&t.getCustomerOccupation().equals(userOccupation)&&t.getCustomerAge()==Integer.parseInt(userAge)){
                    status = t.getTransactionStatus();
                    returnedOrder = t.getOrderReturned();
                }
            }
        }catch (Exception e){
            e.printStackTrace();
        }
        String message = MongoDBDataStoreUtilities.insertReview(productName, productType, productPrice, storeID, storeZip, storeCity, storeState, productOnSale, productMaker, rebate, userName, userAge, userGender, userOccupation, reviewRating, reviewDate, reviewText,status, returnedOrder);
        if (!message.equals("Successful")) {
            return "UnSuccessful";
        } else {
            HashMap<String, ArrayList<Review>> reviews = new HashMap<String, ArrayList<Review>>();

            try {
                reviews = MongoDBDataStoreUtilities.selectReview();
            } catch (Exception e) {

            }
            if (reviews == null) {
                reviews = new HashMap<String, ArrayList<Review>>();
            }
            // if there exist product review already add it into same list for productname or create a new record with product name

            if (!reviews.containsKey(productName)) {
                ArrayList<Review> arr = new ArrayList<Review>();
                reviews.put(productName, arr);
            }

            ArrayList<Review> listReview = reviews.get(productName);
            Review review = new Review(productName, productType, productPrice, storeID, storeZip, storeCity, storeState, productOnSale, productMaker, rebate, userName, userAge, userGender, userOccupation, reviewRating, reviewDate, reviewText);
            listReview.add(review);

            // add Reviews into database

            return "Successful";
        }
    }

    public void storeTransactions(String login_id, String customerName, String customerAge, String customerOccupation, String creditCardNo, int orderId, String productID, String name, String category, String retailer, String deliveryType, String zipCode) {
        //转换Date
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
        Date d = getRandOrderDate();
        System.out.println("order date:" + format.format(d));
        //预期到达时间
        Date expectedDate = arriveDate(d, 5);
        System.out.println("预期到达:" + format.format(expectedDate));
        //实际到达时间
        Date actualDate = arriveDate(expectedDate, randInt());
        System.out.println("实际到达:" + format.format(actualDate));
        String onTime = "";
        if (expectedDate.getTime() >= actualDate.getTime()) {
            onTime = "Yes";
        } else {
            onTime = "No";
        }
        //review
        int review = randReview();
        String status = "";
        String orderReturn = "";
        if (flag() == 1) {
            status = "Approved";
        } else {
            status = "Disputed";
        }
        if (flag() == 1) {
            orderReturn = "No";
        } else {
            orderReturn = "Yes";
        }
        String delivery_tracking_id = delivery_tracking_id();
        MySqlDataStoreUtilities.insertTransactions(login_id, customerName, customerAge, customerOccupation, creditCardNo, orderId, d, expectedDate, actualDate, productID, name, category, retailer, review, delivery_tracking_id, deliveryType, zipCode, status, orderReturn, onTime);

    }

    public Date getRandOrderDate() {
        Random rand = new Random();
        Calendar cal = Calendar.getInstance();
        cal.set(2020, 0, 1);
        long start = cal.getTimeInMillis();
        cal.set(2020, 10, 1);
        long end = cal.getTimeInMillis();

        Date d = new Date(start + (long) (rand.nextDouble() * (end - start)));
        return d;
    }

    public int randInt() {
        //准时
        int min1 = -2;
        int max1 = 0;
        //不准时
        int min2 = 1;
        int max2 = 3;
        Random rand = new Random();
        int n5 = rand.nextInt(10);
        int randomNum; //结果数字
        if (n5 < 6) { //55个数字的区间，55%的几率
            randomNum = rand.nextInt((max1 - min1) + 1) + min1;
        } else {
            randomNum = rand.nextInt((max2 - min2) + 1) + min2;
        }
        return randomNum;
    }

    public Date arriveDate(Date d, int addDay) {
        Calendar cal = Calendar.getInstance();
        cal.setTime(d);
        cal.add(Calendar.DAY_OF_MONTH, addDay);
        return cal.getTime();
    }

    public int randReview() {
        int min = 1;
        int max = 3;
        Random rand = new Random();
        int n5 = rand.nextInt(100);
        int randomNum; //结果数字
        if (n5 < 55) { //55个数字的区间，55%的几率
            randomNum = 5;
        } else if (n5 < 70) {
            randomNum = 4;
        } else {
            randomNum = rand.nextInt((max - min) + 1) + min;
        }
        return randomNum;
    }

    public int flag() {
        Random rand = new Random();
        int n5 = rand.nextInt(100);
        int flag; //结果数字
        if (n5 < 60) { //55个数字的区间，55%的几率
            flag = 1;
        } else {
            flag = 0;
        }
        return flag;
    }

    public String delivery_tracking_id() {
        StringBuilder str = new StringBuilder();
        Random random = new Random();
        for (int i = 0; i < 6; i++) {
            str.append(random.nextInt(10));
        }
        return str.toString();
    }
}
