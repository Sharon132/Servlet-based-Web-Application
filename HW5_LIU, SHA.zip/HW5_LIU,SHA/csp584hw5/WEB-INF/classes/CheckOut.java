import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import java.sql.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;

@WebServlet("/CheckOut")

//once the user clicks buy now button page is redirected to checkout page where user has to give checkout information

public class CheckOut extends HttpServlet {
    HashMap<String, Integer> quantities = new HashMap<>();
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter pw = response.getWriter();
        Utilities Utility = new Utilities(request, pw);
        storeOrders(request, response);
    }

    protected void storeOrders(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try {
            response.setContentType("text/html");
            PrintWriter pw = response.getWriter();
            Utilities utility = new Utilities(request, pw);
            if (!utility.isLoggedin()) {
                HttpSession session = request.getSession(true);
                session.setAttribute("login_msg", "Please Login to add items to cart");
                response.sendRedirect("Login");
                return;
            }
            HttpSession session = request.getSession();

            //get the order product details	on clicking submit the form will be passed to submitorder page

            String userName = session.getAttribute("username").toString();
            String orderTotal = request.getParameter("orderTotal");
            utility.printHtml("Header.html");
            utility.printHtml("LeftNavigationBar.html");
            pw.print("<form  name ='CheckOut' action='Payment' method='post'>");
            pw.print("<div id='content'><div class='post'><h2 class='title meta'>");
            pw.print("<a style='font-size: 24px;'>Order</a>");
            pw.print("</h2><div class='entry'>");
            pw.print("<table  class='gridtable'>");

            HashSet<String> set = new HashSet<>();
            HashMap<String, Integer> orders = utility.getOrders();

            HashMap<String, CustomerAddress> hm = MySqlDataStoreUtilities.getStoreLocation();

            //声明quantity
            int quantity = 0;

            // for each order iterate and display the order name price
            for (OrderItem oi : utility.getCustomerOrders()) {
                String name = oi.getName();
                if (set.contains(name)) {
                    continue;
                } else {
                    set.add(name);
                }
                pw.print("<tr><td> Product Type:</td><td>");
                pw.print(oi.getProductType() + "</td></tr>");
                pw.print("<tr><td> Product Purchased:</td><td>");
                pw.print(oi.getName() + "</td></tr>");
                pw.print("<tr><td> Manufacturer:</td><td>");
                pw.print(oi.getRetailer() + "</td></tr><tr><td>");
                pw.print("<input type='hidden' name='orderPrice' value='" + oi.getPrice() + "'>");
                pw.print("<input type='hidden' name='orderName' value='" + oi.getName() + "'>");
                pw.print("Product Price:</td><td>" + oi.getPrice());
                pw.print("</td></tr>");
                pw.print("<tr><td>");
                quantity = orders.get(oi.getName());
                pw.print("Quantity</td><td>" + quantity+"</td></tr>");
                pw.print("<tr><td> totalDisc.:</td><td>");
                pw.print(oi.getDiscount()*quantity + "</td></tr>");
                pw.print("<input type='hidden' name='quantity' value='" + quantity + "'>");
                pw.print("<input type='hidden' name='category' value='" + oi.getRetailer() + "'>");
                quantities.put(oi.getName(),orders.get(oi.getName()));
            }
            session.setAttribute("qtyMap",quantities);
            pw.print("<tr><td>");
            pw.print("Total Order Cost</td><td>" + orderTotal);
            pw.print("<input type='hidden' name='orderTotal' value='" + orderTotal + "'>");
            pw.print("</td></tr></table><table><tr><td><h3>Customer Info</h3><td></tr>");
            //测试
            pw.print("<tr><td>");
            pw.print("Name</td>");
            pw.print("<td><input type='text' name='customer_name'>");
            pw.print("</td></tr>");

            pw.print("<tr><td>");
            pw.print("Age</td>");
            pw.print("<td><input type='text' name='customer_age'>");
            pw.print("</td></tr>");

            pw.print("<tr><td>");
            pw.print("Occupation</td>");
            pw.print("<td><input type='text' name='customer_occupation'>");
            pw.print("</td></tr>");
            pw.print("<tr><td><h3>Payment Info</h3><td></tr>");

            pw.print("<tr><td>");
            pw.print("Street</td>");
            pw.print("<td><input type='text' name='street'>");
            pw.print("</td></tr>");
            pw.print("<tr><td>");
            pw.print("City</td>");
            pw.print("<td><input type='text' name='city'>");
            pw.print("</td></tr>");
            pw.print("<tr><td>");
            pw.print("State</td>");
            pw.print("<td><input type='text' name='state'>");
            pw.print("</td></tr>");
            pw.print("<tr><td>");
            pw.print("ZipCode</td>");
            pw.print("<td><input type='text' name='zipCode'>");
            pw.print("</td></tr>");
            pw.print("<tr><td>");
            pw.print("Credit Card</td>");
            pw.print("<td><input type='text' name='creditCardNo'>");
            pw.print("</td></tr>");
            pw.print("<br/>");

            //
            pw.print("<tr><td>");

            pw.print("Delivery Method:</td>");
            pw.print("<td><input  type='radio' name='deliveryMethod' value='pickup' onclick='displayPickup()'>" +
                    "<label value='pickup'>Store Pickup</label></td>");
            pw.print("<td><input  type='radio' name='deliveryMethod' value='delivery' onclick='displayDelivery()'>" +
                    "<label value='delivery'>Home Delivery</label>");
            pw.print("</td></tr>");

            //pickup
            pw.print("<tr id='pickupLocation' hidden='true'><td>");
            pw.print("Pickup Location</td>");
            pw.print("<td><select class='input' name='storeLocation' >");
            pw.print("<option value='' >- select location - </option>");
            for (CustomerAddress loc : hm.values()) {
                String location = loc.getStreet() + ", " + loc.getCity() + ", " + loc.getState() + ", " + loc.getZipCode();
                pw.print("<option value='" + location + "'>" + location +
                        "</option>");
            }
            pw.print("</select>");

            //
            pw.print("<tr><td colspan='2'>");


            pw.print("<input type='submit' name='submit' class='btnbuy'>");
            pw.print("</td></tr></table></form>");
            pw.print("</div></div></div>");
            utility.printHtml("Footer.html");
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }
}
