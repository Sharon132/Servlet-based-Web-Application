import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

@WebServlet("/UpdateOrder")
public class UpdateOrder extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        response.setContentType("text/html");
        PrintWriter pw = response.getWriter();

        Utilities utility = new Utilities(request, pw);

        int orderId = Integer.parseInt(request.getParameter("orderId"));
        String username = request.getParameter("username");
        String productName = request.getParameter("productName");
        int quantity = Integer.parseInt(request.getParameter("quantity"));
        double totalSales = Double.parseDouble(request.getParameter("totalSales"));
        String address = request.getParameter("address");
        String creditCard = request.getParameter("creditCard");

        HashMap<String, Integer> ids = MySqlDataStoreUtilities.getUser_id();
        int user_id = ids.get(username);


        //Create a new order id
        SimpleDateFormat df = new SimpleDateFormat("HHmmss");//设置日期格式
        int newOrderId = Integer.parseInt(df.format(new Date()));  //设置订单号为当前下单时间的时分秒

        //遍历map,可以直接update  或者删除再添加
        HashMap<Integer, ArrayList<OrderPayment>> orderPayments = new HashMap<Integer, ArrayList<OrderPayment>>();
        try {
            orderPayments = MySqlDataStoreUtilities.selectOrder();
        } catch (Exception e) {
            e.printStackTrace();
        }
        for (Map.Entry<Integer, ArrayList<OrderPayment>> entry : orderPayments.entrySet()) {
            for (OrderPayment od : entry.getValue()) {
                if (orderId == od.getOrderId() && productName.equals(od.getProductId())) {
                    MySqlDataStoreUtilities.deleteOrder(orderId, productName);
                    MySqlDataStoreUtilities.insertOrder(od.getUser_id(), od.getUserName(), address, creditCard, od.getOrderId(), new java.sql.Date(od.getPurchaseDay().getTime()), new java.sql.Date(od.getShippingDay().getTime()), od.getProductId(), od.getCategory(), od.getOrderQuantity(), od.getOrderPrice(), od.getShippingCost(), od.getDiscount(), od.getTotalSales(), od.getStoreId(), od.getLocation());
                }
            }
        }
//        response.sendRedirect("SalesmanHome");
        pw.print("<script>alert('Update successfully!');</script>");
        pw.print("<script>location='SalesmanHome';</script>");
        pw.flush();
    }
}
