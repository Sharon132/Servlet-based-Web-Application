

import java.io.IOException;
import java.io.PrintWriter;

import com.mongodb.MongoClient;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.BasicDBObject;
import com.mongodb.DBObject;
import com.mongodb.DBCursor;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.util.*;

@WebServlet("/ViewReview")

public class ViewReview extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        response.setContentType("text/html");
        PrintWriter pw = response.getWriter();
        Utilities utility = new Utilities(request, pw);
        review(request, response);
    }

    protected void review(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try {
            response.setContentType("text/html");
            PrintWriter pw = response.getWriter();
            HttpSession session = request.getSession(true);
            Utilities utility = new Utilities(request, pw);
            if (!utility.isLoggedin()) {
                session.setAttribute("login_msg", "Please Login to view Review");
                response.sendRedirect("Login");
                return;
            }
            String productname = request.getParameter("name");
            String producttype = request.getParameter("type");
            String productmaker = request.getParameter("maker");
            String productprice = request.getParameter("price");
//            String username = (String) session.getAttribute("username");
            double discount = Double.parseDouble(request.getParameter("discount"));
            HashMap<String, ArrayList<Review>> hm = MongoDBDataStoreUtilities.selectReview();

            String userName = "";
            String reviewRating = "";
            String reviewDate;
            String reviewText = "";
//            String price = "";
//            String city = "";
//            String userAge = "";
//            String userGender = "";
//            String userOccupation = "";

            utility.printHtml("Header.html");
            utility.printHtml("LeftNavigationBar.html");

            pw.print("<div id='content'><div class='post'><h2 class='title meta'>");
            pw.print("<a style='font-size: 24px;'>Review</a>");
            pw.print("</h2><div class='entry'>");

            //if there are no reviews for product print no review else iterate over all the reviews using cursor and print the reviews in a table
            if (hm == null) {
                pw.println("<h2>Mongo Db server is not up and running</h2>");
            } else {
                if (!hm.containsKey(productname)) {
                    pw.println("<h2>There are no reviews for this product.</h2>");
                } else {
                    for (Review r : hm.get(productname)) {
                        pw.print("<table class='gridtable'>");
                        pw.print("<tr>");
                        pw.print("<td> 1. Product Name: </td>");
                        productname = r.getProductName().replace("_", " ");
                        pw.print("<td>" + productname + "</td>");
                        pw.print("</tr>");

                        pw.print("<tr><td> 2. Product Type:</td><td>");
                        pw.print(producttype);
                        pw.print("<input type='hidden' name='producttype' value='" + producttype + "'>");
                        pw.print("</td></tr>");

                        pw.print("<tr><td width=\"30%\"> 3. Product Price:</td><td width=\"70%\">");
                        pw.print(productprice);
                        pw.print("<input type='hidden' name='productprice' value='" + productprice + "'>");
                        pw.print("</td></tr>");

                        pw.print("<tr><td> 4. Store ID:</td><td>");
                        pw.print("BestDeal Mall");
                        pw.print("<input type='hidden' name='storeID' value='BestDeal'>");
                        pw.print("</td></tr>");

                        pw.print("<tr>");
                        pw.print("<td> 5. Store Zip: </td>");
                        pw.print("<td>" + r.getStoreZip() + "</td>");
                        pw.print("</tr>");

                        pw.print("<tr><td> 6. Store City:</td><td>");
                        pw.print("Chicago");
                        pw.print("<input type='hidden' name='storeCity' value='Chicago'>");
                        pw.print("</td></tr>");

                        pw.print("<tr><td> 7. Store State:</td><td>");
                        pw.print("IL");
                        pw.print("<input type='hidden' name='storeState' value='IL'>");
                        pw.print("</td></tr>");

                        pw.print("<tr>");
                        pw.print("<td> 8. Product On Sale: </td><td>");
                        pw.print(r.getProductOnSale());
                        pw.print("<input type='hidden' name='productOnSale' value='" + r.getProductOnSale() + "'>");
                        pw.print("</td></tr>");

                        pw.print("<tr><td> 9. Manufacturer Name:</td><td>");
                        pw.print(productmaker);
                        pw.print("<input type='hidden' name='productmaker' value='" + productmaker + "'>");
                        pw.print("</td></tr>");

                        pw.print("<tr><td> 10. Manufacturer Rebate:</td><td>");
                        pw.print("Yes");
                        pw.print("<input type='hidden' name='rebate' value='Yes'>");
                        pw.print("</td></tr>");

                        pw.print("<tr>");
                        pw.print("<td> 11. User ID: </td>");
                        pw.print("<td>" + r.getUsername() + "</td>");
                        pw.print("</tr>");

                        pw.print("<tr>");
                        pw.print("<td> 12. User Age: </td>");
//                        userAge = r.getUserAge();
                        pw.print("<td>" + r.getUserAge() + "</td>");
                        pw.print("</tr>");

                        pw.print("<tr>");
                        pw.print("<td> 13. User Gender: </td>");
//                        userGender = r.getUserGender();
                        pw.print("<td>" + r.getUserGender() + "</td>");
                        pw.print("</tr>");

                        pw.print("<tr>");
                        pw.print("<td> 14. User Occupation: </td>");
//                        userOccupation = r.getUserOccupation();
                        pw.print("<td>" + r.getUserOccupation() + "</td>");
                        pw.print("</tr>");

                        pw.println("<tr>");
                        pw.println("<td> 15. Review Rating: </td>");
                        reviewRating = r.getReviewRating().toString();
                        pw.print("<td>" + reviewRating + "</td>");
                        pw.print("</tr>");

                        pw.print("<tr>");
                        pw.print("<td> 16. Review Date: </td>");
                        reviewDate = r.getReviewDate().toString();
                        pw.print("<td>" + reviewDate + "</td>");
                        pw.print("</tr>");

                        pw.print("<tr>");
                        pw.print("<td> 17. Review Text: </td>");
                        reviewText = r.getReviewText();
                        pw.print("<td>" + reviewText + "</td>");
                        pw.print("</tr>");
                        pw.print("</table>");
                        pw.print("<br/>");
                    }

                }
            }
            pw.print("</div></div></div>");
            utility.printHtml("Footer.html");

        } catch (Exception e) {
            System.out.println(e.getMessage());
        }


    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        response.setContentType("text/html");
        PrintWriter pw = response.getWriter();

    }
}
