import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

@WebServlet("/SalesmanHome")
public class SalesmanHome extends HttpServlet {
    private String error_msg;

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        PrintWriter pw = response.getWriter();
        displaySalesmanHome(request, response, pw, "");
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter pw = response.getWriter();
        Utilities utility = new Utilities(request, pw);
        HttpSession session = request.getSession(true);

        //创建customer的表格
        String username = request.getParameter("username");
        String password = request.getParameter("password");
        String repassword = request.getParameter("repassword");

        //创建order的表格
        String customerName = request.getParameter("customerName");
        String itemName = request.getParameter("itemName");
        String itemType = request.getParameter("itemType");
        String creditCardNo = request.getParameter("creditCardNo");
        String customerAddress = request.getParameter("customerAddress");

        String quantity = request.getParameter("quantity");
        String discount = request.getParameter("discount");
//        String unitPrice = request.getParameter("unitPrice");

        //getuser_id
        User user1 = utility.getUser();
        HashMap<String, Integer> ids = MySqlDataStoreUtilities.getUser_id();
        int user_id = ids.get(user1.getName());

        HashMap<String, User> hm = new HashMap<String, User>();

        //get the user details from file
        try {
            hm = MySqlDataStoreUtilities.selectUser();
        } catch (Exception e) {
            e.printStackTrace();
        }

        if (request.getParameter("Customer") != null && request.getParameter("Customer").equals("Create Customer")) {
            //提交的是创建Customer的表格
            if (!password.equals(repassword)) {
                error_msg = "Passwords doesn't match!";  //已完成测试
                displaySalesmanHome(request, response, pw, "Customer");
            } else {

                // if the user already exist show error that already exist
                if (hm.containsKey(username)) {
                    error_msg = "Username already exist."; //已完成测试
                    displaySalesmanHome(request, response, pw, "Customer");
                } else {
                    User user = new User(username, password, "Customer");
                    hm.put(username, user);
                    if (MySqlDataStoreUtilities.insertUser(username, password, repassword, "Customer")) {
                        session.setAttribute("login_msg", "The customer account created successfully.");
                    }

                    //创建customer成功
                    error_msg = "The customer account created successfully.";
                    displaySalesmanHome(request, response, pw, "Customer");  //已完成测试
                }

            }
        } else if (request.getParameter("order") != null && request.getParameter("order").equals("Create Order")) {
            //提交的是创建order的表格
            if (!hm.containsKey(customerName)) { //已完成测试
                error_msg = "Cannot found this customer.";
                displaySalesmanHome(request, response, pw, "order");
            } else {
                double unitPrice;
                if (utility.isContainsStr(request.getParameter("unitPrice"))) {
                    //含有字母，报错
                    error_msg = "Please type in number!";  //已完成测试
                    displaySalesmanHome(request, response, pw, "order");
                    return;
                } else {
                    unitPrice = Double.parseDouble(request.getParameter("unitPrice"));
                }
                double totalPrice = Integer.parseInt(quantity)*unitPrice-Double.parseDouble(discount);

                if (utility.isItemExist(itemType, itemName)) { //已完成测试  // 判断商品是否存在的功能没有完成
                    SimpleDateFormat deliveryDateFormat = new SimpleDateFormat("yyyy-MM-dd");//设置日期格式
                    String day = deliveryDateFormat.format(new Date());
                    String purchaseDay = day;
                    Calendar c = Calendar.getInstance();
                    try {
                        c.setTime(deliveryDateFormat.parse(day));
                    } catch (ParseException e) {
                        e.printStackTrace();
                    }
                    c.add(Calendar.DATE, 14);  // number of days to add
                    day = deliveryDateFormat.format(c.getTime());

                    java.util.Date d1 = null;
                    java.util.Date d2 = null;
                    try {
                        d1 = deliveryDateFormat.parse(purchaseDay);
                        d2 = deliveryDateFormat.parse(day);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }

                    SimpleDateFormat df = new SimpleDateFormat("HHmmss");//设置日期格式
                    int orderId = Integer.parseInt(df.format(new Date()));  //设置订单号为当前下单时间的时分秒
                    MySqlDataStoreUtilities.insertOrder(user_id, customerName, customerAddress, creditCardNo, orderId, d1, d2, itemName, itemType, Integer.parseInt(quantity), unitPrice, 5.0, Double.parseDouble(discount), totalPrice, "none", "none");
                    //创建order成功
                    error_msg = "The order created successfully.";
                    displaySalesmanHome(request, response, pw, "order");
                } else { //已完成测试
                    error_msg = "Cannot found this item.";
                    displaySalesmanHome(request, response, pw, "order");
                }
            }
        }
    }

    protected void displaySalesmanHome(HttpServletRequest request,
                                       HttpServletResponse response, PrintWriter pw, String flag)  //error: true代表有错误，false代表没有错误
            throws ServletException, IOException {

        Utilities utility = new Utilities(request, pw);
        utility.printHtml("Header.html");
        utility.printHtml("LeftNavigationBar.html");

        pw.print("<div id='content'>");
        pw.print("<div class='post'>");
        pw.print("<h3 class='title'>");
        pw.print("Create New Customer");
        pw.print("</h3>");
        pw.print("<div class='entry'>");

        if (flag.equals("Customer"))
            pw.print("<h4 style='color:red'>" + error_msg + "</h4>");
        //显示创建customer的表格
        pw.print("<form action='SalesmanHome' method='post'>");
        pw.print("<table style='width:100%'><tr><td>");
        pw.print("<h4>Username</h4></td><td><input type='text' name='username' value='' class='input' required></input>");
        pw.print("</td></tr><tr><td>");
        pw.print("<h4>Password</h4></td><td><input type='password' name='password' value='' class='input' required></input>");
        pw.print("</td></tr><tr><td>");
        pw.print("<h4>Re-Password</h4></td><td><input type='password' name='repassword' value='' class='input' required></input>");
        pw.print("</td></tr><tr><td>");
        pw.print("<input type='submit' class='btnbuy' value='Create Customer' name='customer' style='float: right;height: 20px margin: 20px; margin-right: 10px;'></input>");
        pw.print("</td></tr><tr><td></td><td>");
        pw.print("</td></tr></table>");
        pw.print("</form></div></div>");


        //显示创建订单的表格
        pw.print("<div class='post'>");
        pw.print("<h3 class='title'>");
        pw.print("Create New Order");
        pw.print("</h3>");
        pw.print("<div class='entry'>");
        if (flag.equals("order"))
            pw.print("<h4 style='color:red'>" + error_msg + "</h4>");
        pw.print("<form action='SalesmanHome' method='post'>");
        pw.print("<table style='width:100%'><tr><td>");
        pw.print("<h4>Customer name</h4></td><td><input type='text' name='customerName' value='' class='input' required></input>");
        pw.print("</td></tr><tr><td>");
        pw.print("<h4>Item name</h4></td><td><input type='text' name='itemName' value='' class='input' required></input>");
        pw.print("</td></tr><tr><td>");

        pw.print("<h4>Item type</h4><td><select name='itemType' class='input'>" +
                "<option value='FitnessWatch' selected>Fitness watch</option>" +
                "<option value='SmartWatch'>Smart watch</option>" +
                "<option value='Headphone'>Headphone</option>" +
                "<option value='VirtualReality'>Virtual reality</option>" +
                "<option value='PetTracker'>Pet tracker</option>" +
                "<option value='TV'>TV</option>" +
                "<option value='SoundSystem'>Sound System</option>" +
                "<option value='Phone'>Phone</option>" +
                "<option value='Laptop'>Laptop</option>" +
                "<option value='VoiceAssistant'>Voice assistant</option>" +
                "<option value='Accessory'>Accessory</option></select>");
        pw.print("</td></tr></td><tr><td>");
        pw.print("<h4>Price</h4></td><td><input type='text' name='unitPrice' value='' class='input' required></input>");
        pw.print("</td></tr><tr><td>");
        pw.print("<h4>Quantity</h4></td><td><input type='text' name='quantity' value='' class='input' required></input>");
        pw.print("</td></tr><tr><td>");
        pw.print("<h4>Discount</h4></td><td><input type='text' name='discount' value='' class='input' required></input>");

        pw.print("</td></tr><tr><td>");
        pw.print("<h4>Credit/accountNo</h4></td><td><input type='text' name='creditCardNo' value='' class='input' required></input>");
        pw.print("</td></tr><tr><td>");
        pw.print("<h4>Customer Address</h3></td><td><input type='text' name='customerAddress' value='' class='input' required></input>");
        pw.print("</td></tr><tr><td>");
        pw.print("<input type='submit' class='btnbuy' value='Create Order' name='order' style='float: right;height: 20px margin: 20px; margin-right: 10px;'></input>");
        pw.print("</td></tr><tr><td></td><td>");
        pw.print("</td></tr></table>");
        pw.print("</form></div></div>");


        //显示order的详细信息
        HashMap<Integer, ArrayList<OrderPayment>> orderPayments = new HashMap<Integer, ArrayList<OrderPayment>>();
        try {
            orderPayments = MySqlDataStoreUtilities.selectOrder();
        } catch (Exception ignored) {

        }

        pw.print("<div class='post'>");
        pw.print("<h2 class='title meta'>");
        pw.print("<a style='font-size: 24px;'>View Orders</a>");
        pw.print("</h2><div class='entry'>");

        pw.print("<table class='gridtable'>");

        for (Map.Entry<Integer, ArrayList<OrderPayment>> entry : orderPayments.entrySet()) {
            for (OrderPayment od : entry.getValue()) {

                pw.print("<form method='post' action='RemoveUpdateOrder'>");
                pw.print("<tr>");
//                od.getUser_id()

                pw.print("<td>Order Id: " + od.getOrderId() + "</td>" +
                        "<td>Username: " + od.getUserName() + "</td>" +
                        "<td>Product Name: " + od.getProductId() + "</td>" +
                        //quantity
                        "<td>Quantity:" + od.getOrderQuantity() + "</td>" +
                        //totalSales
                        "<td>Total Price: " + od.getTotalSales() + "</td></tr>" +
                        "<td>Address: " + od.getShippingAddress() + "</td>" +
                        "<td>Credit Card: " + od.getCreditCardNo() + "</td>");

                pw.print("<input type='hidden' name='orderId' value='" + od.getOrderId() + "'>");
                pw.print("<input type='hidden' name='username' value='" + od.getUserName() + "'>");
                pw.print("<input type='hidden' name='productName' value='" + od.getProductId() + "'>");
                pw.print("<input type='hidden' name='quantity' value='" + od.getOrderQuantity() + "'>");
                pw.print("<input type='hidden' name='totalSales' value='" + od.getTotalSales() + "'>");
                pw.print("<input type='hidden' name='address' value='" + od.getShippingAddress() + "'>");
                pw.print("<input type='hidden' name='creditCard' value='" + od.getCreditCardNo() + "'>");
                pw.print("<input type='hidden' name='userType' value='Salesman'>");
                pw.print("<td><input type='submit' name='Order' value='Cancel' class='btnbuy'></td>");
                pw.print("<td><input type='submit' name='Order' value='Update' class='btnbuy'></td>");
                pw.print("</tr>");
                pw.print("<tr></tr>");
                pw.print("</form>");
            }
        }
        pw.print("</table>");
        pw.print("</h2></div></div></div>");
        utility.printHtml("Footer.html");
    }
}
