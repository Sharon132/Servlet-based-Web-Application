1. Preparing 
Download all the needed Jar Files and Set up all the environmental variables 
mysql-connector-java-8.0.16  -----connect MySql
mongo-java-driver-3.2.2      -----connect MongoDB


2. Run the MySQL Server
First create database named csp584hw2. 
Then create tables: 
                    1. Productdetails table and Product_accessories table to store product information through reading xml file to insert data.
                    2. CustomerAddress table to store customers' shipping address.
                    3. Registration table to store customer login information.
                    4. StoreLocation table to store locations which are used to give customers if they choose to in-store pickup.
                    5. CustomerOrders table to store order information created by customers. 


3. Run the MongoDB Server 
First we should connect MongoDB Server, because we have setting environment, in the terminal we just input:
                    mongod
Then: 
                    Use CustomerReviews
And create collection  using below command:
                    db.createCollection("myReviews")
To see collection in the database you need to write command given below:
                    db.myReviews.find()

4. Compile all java programs--->javac *.java

5. Run the tomcat server 
First in order to start the tomcat server, we can input in the terminal:
                    startup.sh
Then in the browser:
                    http://localhost:80/csp584hw5

6. access Twitter and save key in credentials.txt

7. Use anaconda to run python cells to create files that deal matches feature and recommendation feature need

Now you are in the BestDeal application and do the operations.