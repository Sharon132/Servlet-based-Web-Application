/*
 Navicat Premium Data Transfer

 Source Server         : local_mysql
 Source Server Type    : MySQL
 Source Server Version : 80021
 Source Host           : localhost:3306
 Source Schema         : csp584hw2

 Target Server Type    : MySQL
 Target Server Version : 80021
 File Encoding         : 65001

 Date: 09/10/2020 23:25:28
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for CustomerAddress
-- ----------------------------
DROP TABLE IF EXISTS `CustomerAddress`;
CREATE TABLE `CustomerAddress` (
  `CustomerName` varchar(20) DEFAULT NULL,
  `street` varchar(100) DEFAULT NULL,
  `city` varchar(20) DEFAULT NULL,
  `state` varchar(20) DEFAULT NULL,
  `zipCode` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ----------------------------
-- Records of CustomerAddress
-- ----------------------------
BEGIN;
INSERT INTO `CustomerAddress` VALUES ('c1', '2801 S KING DRIVE, APT 1017', 'CHICAGO', 'ILLINOIS', '60616');
INSERT INTO `CustomerAddress` VALUES ('c1', '20 W Fulton St', 'Hollywood', 'CA', '95273');
INSERT INTO `CustomerAddress` VALUES ('c1', '1001 W Webster Ave', 'Chicago', 'IL', '60625');
INSERT INTO `CustomerAddress` VALUES ('c1', 'Shelly', 'Denver', 'CO', '21076');
INSERT INTO `CustomerAddress` VALUES ('c1', '10 S HongK St', 'Hollywood', 'CA', '98388');
INSERT INTO `CustomerAddress` VALUES ('c2', '2397 S Michigan Ave', 'Denver', 'UT', '82379');
INSERT INTO `CustomerAddress` VALUES ('c2', '108 N Madison Ave', 'Hollywood', 'CA', '91278');
INSERT INTO `CustomerAddress` VALUES ('c2', '2801 S King Drive', 'Chicago', 'IL', '60616');
INSERT INTO `CustomerAddress` VALUES ('c2', '2801 S KING DRIVE', 'Denver', 'UT', '60616');
INSERT INTO `CustomerAddress` VALUES ('c2', '108 N State St', 'Denver', 'CO', '27837');
INSERT INTO `CustomerAddress` VALUES ('c3', '2728 N Clark St', 'Denver', 'CO', '29478');
INSERT INTO `CustomerAddress` VALUES ('c3', '2728 N Clark St', 'Denver', 'CO', '29478');
INSERT INTO `CustomerAddress` VALUES ('c3', '2901 S Lake St', 'New York City', 'NY', '78762');
INSERT INTO `CustomerAddress` VALUES ('c3', '2801 S KING DRIVE', 'Denver', 'UT', '60616');
INSERT INTO `CustomerAddress` VALUES ('c3', 'Yelp oak St', 'Chicago', 'IL', '60616');
INSERT INTO `CustomerAddress` VALUES ('c4', 'K Pake Ave', 'Denver', 'UT', '60608');
INSERT INTO `CustomerAddress` VALUES ('c4', '1101 S Canal St', 'Denver', 'CO', '21076');
INSERT INTO `CustomerAddress` VALUES ('c4', '200 N Dearborn St', 'Denver', 'CO', '20987');
INSERT INTO `CustomerAddress` VALUES ('c4', '5118 S Lake Ave', 'Syracuse', 'NY', '51028');
INSERT INTO `CustomerAddress` VALUES ('c4', '2801 S KING DRIVE', 'Chicago', 'IL', '60616');
INSERT INTO `CustomerAddress` VALUES ('sa1', '750 S Halsted St', 'Chicago', 'IL', '60616');
INSERT INTO `CustomerAddress` VALUES ('c1', '20 W Fulton St', 'Hollywood', 'CA', '95273');
INSERT INTO `CustomerAddress` VALUES ('c1', '20 W Fulton St', 'Hollywood', 'CA', '95273');
INSERT INTO `CustomerAddress` VALUES ('c1', 'qwekjrnfkqwe', 'CHICAGO', 'ILLINOIS', '60616');
INSERT INTO `CustomerAddress` VALUES ('c1', '2728 N Clark St', 'Denver', 'CO', '29478');
INSERT INTO `CustomerAddress` VALUES ('c2', '1105 Pake ST', 'Hste', 'ID', '56788');
INSERT INTO `CustomerAddress` VALUES ('c7', '2801 S KING DRIVE, APT 1017', 'Chicago', 'IL', '60616');
INSERT INTO `CustomerAddress` VALUES ('c1', '108 N State St', 'Denver', 'CO', '27837');
INSERT INTO `CustomerAddress` VALUES ('c8', '108 N Madison Ave', 'Hollywood', 'CA', '91278');
INSERT INTO `CustomerAddress` VALUES ('c1', '2801 S KING DRIVE, APT 1017', 'Chicago', 'IL', '60616');
INSERT INTO `CustomerAddress` VALUES ('c10', '2801 S KING DRIVE, APT 1017', 'Chicago', 'IL', '60616');
INSERT INTO `CustomerAddress` VALUES ('c1', '108 N State St', 'Denver', 'CO', '27837');
COMMIT;

-- ----------------------------
-- Table structure for Product_accessories
-- ----------------------------
DROP TABLE IF EXISTS `Product_accessories`;
CREATE TABLE `Product_accessories` (
  `productName` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `accessoriesName` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  KEY `productName` (`productName`),
  KEY `accessoriesName` (`accessoriesName`),
  CONSTRAINT `product_accessories_ibfk_1` FOREIGN KEY (`productName`) REFERENCES `Productdetails` (`Id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `product_accessories_ibfk_2` FOREIGN KEY (`accessoriesName`) REFERENCES `Productdetails` (`Id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ----------------------------
-- Records of Product_accessories
-- ----------------------------
BEGIN;
INSERT INTO `Product_accessories` VALUES ('iphone 6s', 'AirpodsPro');
INSERT INTO `Product_accessories` VALUES ('iphone 6s', 'Earpods3.5');
INSERT INTO `Product_accessories` VALUES ('iphone 11', 'AirpodsPro');
INSERT INTO `Product_accessories` VALUES ('iphone 11', '11 ScreenProt');
INSERT INTO `Product_accessories` VALUES ('iphone pro11', 'AirpodsPro');
INSERT INTO `Product_accessories` VALUES ('iphone pro11', '11 ScreenProt');
INSERT INTO `Product_accessories` VALUES ('iphone pro11', '11Pro Case');
INSERT INTO `Product_accessories` VALUES ('iphone xr', 'Adapter');
INSERT INTO `Product_accessories` VALUES ('Honor8x', 'QuickCharger');
INSERT INTO `Product_accessories` VALUES ('Honor8x', 'WirelessCharger');
INSERT INTO `Product_accessories` VALUES ('Honor8x', 'MobilePower');
INSERT INTO `Product_accessories` VALUES ('Mate20', 'WirelessCharger');
INSERT INTO `Product_accessories` VALUES ('P30', 'P30_ScreenPro');
INSERT INTO `Product_accessories` VALUES ('P30', 'QuickCharger');
INSERT INTO `Product_accessories` VALUES ('Y9', 'QuickCharger');
INSERT INTO `Product_accessories` VALUES ('Y9', 'WirelessCharger');
COMMIT;

-- ----------------------------
-- Table structure for Productdetails
-- ----------------------------
DROP TABLE IF EXISTS `Productdetails`;
CREATE TABLE `Productdetails` (
  `ProductType` varchar(20) DEFAULT NULL,
  `Id` varchar(20) NOT NULL,
  `productName` varchar(40) DEFAULT NULL,
  `productPrice` double(10,2) DEFAULT NULL,
  `productImage` varchar(40) DEFAULT NULL,
  `productManufacturer` varchar(40) DEFAULT NULL,
  `productCondition` varchar(40) DEFAULT NULL,
  `productDiscount` double(10,2) DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ----------------------------
-- Records of Productdetails
-- ----------------------------
BEGIN;
INSERT INTO `Productdetails` VALUES ('Accessory', '11 ScreenProt', '11 ScreenProt', 15.00, 'acc_11ScreenP.jpg', 'Apple', 'New', 0.99);
INSERT INTO `Productdetails` VALUES ('Accessory', '11Pro Case', '11Pro Case', 20.00, 'acc_11ProCase.jpg', 'Apple', 'New', 0.00);
INSERT INTO `Productdetails` VALUES ('Laptop', '15.6HD', '15.6HD', 799.00, 'laptop_hp_15.6HD.jpg', 'HP', 'New', 15.00);
INSERT INTO `Productdetails` VALUES ('Laptop', '2019', '2019', 699.00, 'laptop_hp_2019.jpg', 'HP', 'New', 103.10);
INSERT INTO `Productdetails` VALUES ('Laptop', '2020', '2020', 749.00, 'laptop_hp_2020.jpg', 'HP', 'New', 10.00);
INSERT INTO `Productdetails` VALUES ('SoundSystem', '3.1 Channel', '3.1 Channel', 856.00, 'sound_dt_3.1 Channel.jpg', 'DefinitiveTechnology', 'New', 80.00);
INSERT INTO `Productdetails` VALUES ('VoiceAssistant', '3rd', '3rd', 49.99, 'voiceA_Alexa_3rd.jpg', 'Amazon', 'New', 3.00);
INSERT INTO `Productdetails` VALUES ('TV', '40S325', '40S325', 398.00, 'tv_TCL1080p.jpg', 'TCL', 'New', 100.00);
INSERT INTO `Productdetails` VALUES ('TV', '49NANO85UNA', '49NANO85UNA', 596.99, 'tv_LG1080p.jpg', 'LG', 'New', 12.00);
INSERT INTO `Productdetails` VALUES ('TV', '5-Series', '5-Series', 449.99, 'tv_TCL720p.jpg', 'TCL', 'New', 10.00);
INSERT INTO `Productdetails` VALUES ('SoundSystem', '5.1 set', '5.1 set', 480.07, 'sound_bose_5.1 set.jpg', 'Bose', 'New', 40.00);
INSERT INTO `Productdetails` VALUES ('TV', '50LF621U21', '50LF621U21', 429.99, 'tv_TCL4k.jpg', 'TCL', 'New', 50.00);
INSERT INTO `Productdetails` VALUES ('Phone', 'A10', 'A10', 168.99, 'phone_samsung_a10.jpg', 'Samsung', 'New', 19.00);
INSERT INTO `Productdetails` VALUES ('Phone', 'A20', 'A20', 453.50, 'phone_samsung_a20.jpg', 'Samsung', 'Used', 50.00);
INSERT INTO `Productdetails` VALUES ('Phone', 'A50', 'A50', 349.98, 'phone_samsung_a50.jpg', 'Samsung', 'New', 20.00);
INSERT INTO `Productdetails` VALUES ('Laptop', 'A6-9220e', 'A6-9220e', 749.00, 'laptop_dell_A6-9220e.jpg', 'Dell', 'New', 50.00);
INSERT INTO `Productdetails` VALUES ('Phone', 'A70', 'A70', 334.62, 'phone_samsung_a70.jpg', 'Samsung', 'New', 20.00);
INSERT INTO `Productdetails` VALUES ('Accessory', 'Adapter', 'Adapter', 120.00, 'acc_adapter.jpg', 'Apple', 'New', 0.00);
INSERT INTO `Productdetails` VALUES ('Accessory', 'AirpodsPro', 'AirpodsPro', 249.00, 'acc_airPro.jpg', 'Apple', 'New', 10.00);
INSERT INTO `Productdetails` VALUES ('SoundSystem', 'BP-9020', 'BP-9020', 699.00, 'sound_df_BP-9020.jpg', 'DefinitiveTechnology', 'New', 15.00);
INSERT INTO `Productdetails` VALUES ('TV', 'C9', 'C9', 249.99, 'tv_LG4k.jpg', 'LG', 'New', 10.00);
INSERT INTO `Productdetails` VALUES ('PetTracker', 'CUBE Bluetooth', 'CUBE Bluetooth', 24.95, 'pet_cube_Bluetooth.jpg', 'Cube', 'New', 2.99);
INSERT INTO `Productdetails` VALUES ('PetTracker', 'DYNOTAG QR', 'DYNOTAG QR', 19.95, 'pet_dynotag_QR.jpg', 'Dynotag', 'New', 0.99);
INSERT INTO `Productdetails` VALUES ('Accessory', 'Earpods3.5', 'Earpods3.5', 29.00, 'acc_earpods3.5.jpg', 'Apple', 'New', 3.00);
INSERT INTO `Productdetails` VALUES ('FitnessWatch', 'FITBIT Blaze', 'FITBIT Blaze', 229.95, 'fitness_fitbit_blaze.jpg', 'Fitbit', 'New', 10.00);
INSERT INTO `Productdetails` VALUES ('FitnessWatch', 'FITBIT Versa2', 'FITBIT Versa2', 179.00, 'fitness_fitbit_versa2.jpg', 'Fitbit', 'New', 15.00);
INSERT INTO `Productdetails` VALUES ('Laptop', 'Flex14', 'M4800', 658.00, 'laptop_L_Flex14.jpg', 'Lenovo', 'New', 18.00);
INSERT INTO `Productdetails` VALUES ('Laptop', 'G5', 'G5', 1249.00, 'laptop_dell_g5.jpg', 'Dell', 'New', 100.00);
INSERT INTO `Productdetails` VALUES ('FitnessWatch', 'GARMIN F235', 'GARMIN F235', 169.99, 'fitness_garmin_F235.jpg', 'Garmin', 'New', 12.99);
INSERT INTO `Productdetails` VALUES ('VoiceAssistant', 'Home Max', 'Home Max', 299.99, 'voiceA_google_Home_max.jpg', 'Google', 'New', 14.00);
INSERT INTO `Productdetails` VALUES ('VoiceAssistant', 'HomePod', 'HomePod', 299.99, 'voiceA_Apple_HomePod.jpg', 'Apple', 'New', 0.00);
INSERT INTO `Productdetails` VALUES ('Phone', 'Honor8x', 'Honor8x', 189.99, 'phone_huawei_honor8x.jpg', 'Huawei', 'New', 17.00);
INSERT INTO `Productdetails` VALUES ('Laptop', 'Ideapad3', 'Ideapad3', 549.00, 'laptop_L_Ideapad3.jpg', 'Lenovo', 'New', 39.00);
INSERT INTO `Productdetails` VALUES ('Phone', 'iphone 11', 'iphone 11', 699.00, 'phone_iphone_11.jpg', 'Apple', 'New', 0.00);
INSERT INTO `Productdetails` VALUES ('Phone', 'iphone 6s', 'iphone 6s', 399.99, 'phone_iphone_6s.jpg', 'Apple', 'Used', 25.00);
INSERT INTO `Productdetails` VALUES ('Phone', 'iphone pro11', 'iphone pro11', 999.00, 'phone_iphone_pro11.jpg', 'Apple', 'New', 0.00);
INSERT INTO `Productdetails` VALUES ('Phone', 'iphone xr', 'iphone xr', 599.00, 'phone_iphone_xr.jpg', 'Apple', 'New', 0.00);
INSERT INTO `Productdetails` VALUES ('Accessory', 'Keyboard', 'Keyboard', 125.00, 'acc_huawei_keyb.png', 'Huawei', 'New', 20.00);
INSERT INTO `Productdetails` VALUES ('Laptop', 'Latest Mac15', 'Latest Mac15', 2549.00, 'laptop_apple_latest_mac15.jpg', 'Apple', 'New', 0.00);
INSERT INTO `Productdetails` VALUES ('Laptop', 'M4800', 'M4800', 695.97, 'laptop_dell_m4800.jpg', 'Dell', 'New', 35.00);
INSERT INTO `Productdetails` VALUES ('Laptop', 'Mac13', 'Mac13', 1464.00, 'laptop_apple_mac13.jpg', 'Apple', 'New', 128.00);
INSERT INTO `Productdetails` VALUES ('Laptop', 'Mac15', 'Mac15', 1343.78, 'laptop_apple_mac15.jpg', 'Apple', 'Used', 400.00);
INSERT INTO `Productdetails` VALUES ('Phone', 'Mate20', 'Mate20', 779.99, 'phone_huawei_mate20.jpg', 'Huawei', 'New', 20.00);
INSERT INTO `Productdetails` VALUES ('Accessory', 'MobilePower', 'MobilePower', 100.00, 'acc_huawei_mobilePower.png', 'Huawei', 'New', 15.00);
INSERT INTO `Productdetails` VALUES ('Accessory', 'Mouse', 'Mouse', 89.99, 'acc_huawei_mouse.png', 'Huawei', 'New', 0.00);
INSERT INTO `Productdetails` VALUES ('VoiceAssistant', 'Nest Mini', 'Nest Mini', 39.99, 'voiceA_google_nest_mini.jpg', 'Google', 'New', 2.99);
INSERT INTO `Productdetails` VALUES ('Phone', 'Note 9s', 'Note 9s', 210.93, 'phone_xiaomi_Note 9s.jpg', 'Xiaomi', 'New', 8.00);
INSERT INTO `Productdetails` VALUES ('Phone', 'Note8', 'Note8', 172.99, 'phone_xiaomi_Note8.jpg', 'Xiaomi', 'New', 5.00);
INSERT INTO `Productdetails` VALUES ('VirtualReality', 'OCULUS Quest2', 'OCULUS Quest2', 299.00, 'virtual_oculus_quest2.jpg', 'Oculus', 'New', 10.00);
INSERT INTO `Productdetails` VALUES ('VirtualReality', 'OCULUS Rift_S', 'OCULUS Rift_S', 399.00, 'virtual_oculus_rift_s.jpg', 'Oculus', 'New', 16.00);
INSERT INTO `Productdetails` VALUES ('TV', 'OLED48CXPUB', 'OLED48CXPUB', 1496.99, 'tv_LG720p.jpg', 'LG', 'New', 26.00);
INSERT INTO `Productdetails` VALUES ('Phone', 'P30', 'P30', 172.00, 'phone_huawei_p30.jpg', 'Huawei', 'New', 28.05);
INSERT INTO `Productdetails` VALUES ('Accessory', 'P30_ScreenPro', 'P30_ScreenPro', 89.99, 'acc_p30_ScreenPro.jpg', 'Huawei', 'New', 18.00);
INSERT INTO `Productdetails` VALUES ('Headphone', 'PANASONIC 101', 'PANASONIC 101', 29.95, 'headphone_panasonic_101.jpg', 'Panasonic', 'New', 8.00);
INSERT INTO `Productdetails` VALUES ('Headphone', 'PANASONIC 21', 'PANASONIC 21', 63.00, 'headphone_panasonic_21.jpg', 'Panasonic', 'New', 10.00);
INSERT INTO `Productdetails` VALUES ('VirtualReality', 'PANSONITE Anti', 'PANSONITE Anti', 52.99, 'virtual_pansonite_Anti-Blue-Light.jpg', 'Pansonite', 'New', 10.00);
INSERT INTO `Productdetails` VALUES ('VirtualReality', 'PANSONITE UL', 'PANSONITE UL', 13.99, 'virtual_pansonite_UL.jpg', 'Pansonite', 'New', 0.00);
INSERT INTO `Productdetails` VALUES ('Accessory', 'Pencil', 'Pencil', 30.00, 'acc_huawei_pencil.png', 'Huawei', 'New', 5.00);
INSERT INTO `Productdetails` VALUES ('TV', 'QB65R', 'QB65R', 1125.00, 'tv_samsung8k.jpg', 'Samsung', 'New', 123.80);
INSERT INTO `Productdetails` VALUES ('TV', 'QN65Q7FN', 'QN65Q7FN', 124.00, 'tv_samsung_QN65Q7FN.jpg', 'Samsung', 'New', 1.00);
INSERT INTO `Productdetails` VALUES ('Accessory', 'QuickCharger', 'QuickCharger', 89.99, 'acc_huawei_quickCharger.png', 'Huawei', 'New', 40.00);
INSERT INTO `Productdetails` VALUES ('Phone', 'S9', 'S9', 367.00, 'phone_samsung_s9.jpg', 'Samsung', 'Used', 90.00);
INSERT INTO `Productdetails` VALUES ('SmartWatch', 'SAMSUNG S3', 'SAMSUNG S3', 239.00, 'smart_samsung_s3.jpg', 'Samsung', 'New', 40.00);
INSERT INTO `Productdetails` VALUES ('Accessory', 'SelfieStick', 'SelfieStick', 89.99, 'acc_huawei_selfieSti.jpg', 'Huawei', 'New', 15.00);
INSERT INTO `Productdetails` VALUES ('VoiceAssistant', 'Smart Alarm', 'Smart Alarm', 89.99, 'voiceA_Alexa_smart_alarm.jpg', 'Amazon', 'New', 10.00);
INSERT INTO `Productdetails` VALUES ('SoundSystem', 'solo 5', 'solo 5', 199.00, 'sound_bose_solo 5.jpg', 'Bose', 'New', 10.00);
INSERT INTO `Productdetails` VALUES ('Headphone', 'SONY 310', 'SONY 310', 59.95, 'headphone_sony_310.jpg', 'Sony', 'New', 12.99);
INSERT INTO `Productdetails` VALUES ('SmartWatch', 'SONY V1', 'SONY V1', 99.99, 'smart_sony_v1.jpg', 'Sony', 'New', 25.00);
INSERT INTO `Productdetails` VALUES ('Headphone', 'SONY ZX', 'SONY ZX', 9.99, 'headphone_sony_zx.jpg', 'Sony', 'New', 0.00);
INSERT INTO `Productdetails` VALUES ('TV', 'ST65Q6FN', 'ST65Q6FN', 612.30, 'tv_samsung_QN65Q6FN.jpg', 'Samsung', 'New', 13.00);
INSERT INTO `Productdetails` VALUES ('TV', 'TU-8000', 'TU-8000', 497.99, 'tv_samsung4k.jpg', 'Samsung', 'New', 10.00);
INSERT INTO `Productdetails` VALUES ('TV', 'UN32N', 'UN32N', 236.30, 'tv_samsung1080p.jpg', 'Samsung', 'New', 20.00);
INSERT INTO `Productdetails` VALUES ('TV', 'UN43NU7100F', 'UN43NU7100F', 351.40, 'tv_samsung_UN43NU7100FXZA.jpg', 'Samsung', 'New', 14.50);
INSERT INTO `Productdetails` VALUES ('TV', 'UN55RU71', 'UN55RU71', 982.00, 'tv_samsung_UN55RU7100FXZA.jpg', 'Samsung', 'New', 100.00);
INSERT INTO `Productdetails` VALUES ('SoundSystem', 'wave', 'wave', 408.00, 'sound_bose_wave.jpg', 'Bose', 'New', 13.00);
INSERT INTO `Productdetails` VALUES ('PetTracker', 'WHISTLE Blue_Combo', 'WHISTLE Blue_Combo', 129.90, 'pet_whistle_blue_combo.jpg', 'Whistle', 'New', 1.97);
INSERT INTO `Productdetails` VALUES ('Accessory', 'WirelessCharger', 'WirelessCharger', 259.00, 'acc_huawei_wirelessCharger.png', 'Huawei', 'New', 40.00);
INSERT INTO `Productdetails` VALUES ('TV', 'X800H', 'X800H', 598.00, 'tv_sony-X800H.jpg', 'Sony', 'New', 50.00);
INSERT INTO `Productdetails` VALUES ('TV', 'XBR-49X800G', 'XBR-49X800G', 696.92, 'tv_sony_XBR-49X800G.jpg', 'Sony', 'New', 10.00);
INSERT INTO `Productdetails` VALUES ('TV', 'XBR-65A8H', 'XBR-65A8H', 2498.00, 'tv_sony_XBR-65A8H.jpg', 'Sony', 'New', 108.40);
INSERT INTO `Productdetails` VALUES ('Phone', 'Y9', 'Y9', 571.00, 'phone_huawei_y9.jpg', 'Huawei', 'Used', 61.00);
INSERT INTO `Productdetails` VALUES ('Laptop', 'Yoga C740-14', 'Yoga C740-14', 688.88, 'laptop_L_Yoga_C740-14.jpg', 'Lenovo', 'New', 111.11);
INSERT INTO `Productdetails` VALUES ('SoundSystem', 'Z323', 'Z323', 189.99, 'ss_LogitechZ323.jpg', 'Logitech', 'New', 20.00);
INSERT INTO `Productdetails` VALUES ('SoundSystem', 'Z506', 'AZ506', 39.99, 'ss_LogitechZ506.jpg', 'Logitech', 'Used', 0.00);
INSERT INTO `Productdetails` VALUES ('SoundSystem', 'Z625', 'Z625', 259.99, 'ss_LogitechZ625.jpg', 'Logitech', 'New', 2.00);
INSERT INTO `Productdetails` VALUES ('SoundSystem', 'Z906', 'Z906', 129.99, 'ss_LogitechZ906.jpg', 'Logitech', 'New', 11.00);
COMMIT;

-- ----------------------------
-- Table structure for Registration
-- ----------------------------
DROP TABLE IF EXISTS `Registration`;
CREATE TABLE `Registration` (
  `username` varchar(40) DEFAULT NULL,
  `password` varchar(40) DEFAULT NULL,
  `repassword` varchar(40) DEFAULT NULL,
  `usertype` varchar(40) DEFAULT NULL,
  `user_id` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ----------------------------
-- Records of Registration
-- ----------------------------
BEGIN;
INSERT INTO `Registration` VALUES ('c1', '123', '123', 'Customer', 1);
INSERT INTO `Registration` VALUES ('c2', '123', '123', 'Customer', 2);
INSERT INTO `Registration` VALUES ('c3', '123', '123', 'Customer', 3);
INSERT INTO `Registration` VALUES ('c4', '123', '123', 'Customer', 4);
INSERT INTO `Registration` VALUES ('c5', '123', '123', 'Customer', 5);
INSERT INTO `Registration` VALUES ('st1', '123', '123', 'StoreManager', 6);
INSERT INTO `Registration` VALUES ('sa1', '123', '123', 'Salesman', 7);
INSERT INTO `Registration` VALUES ('c6', '123', '123', 'customer', 8);
INSERT INTO `Registration` VALUES ('liu', '123', '123', 'customer', 9);
INSERT INTO `Registration` VALUES ('sa2', '123', '123', 'Salesman', 10);
INSERT INTO `Registration` VALUES ('c7', '123', '123', 'customer', 11);
INSERT INTO `Registration` VALUES ('c8', '123', '123', 'customer', 12);
INSERT INTO `Registration` VALUES ('Sha', '123', '123', 'customer', 13);
INSERT INTO `Registration` VALUES ('c10', '123', '123', 'Customer', 14);
INSERT INTO `Registration` VALUES ('shaliu', '123', '123', 'customer', 15);
COMMIT;

-- ----------------------------
-- Table structure for StoreLocation
-- ----------------------------
DROP TABLE IF EXISTS `StoreLocation`;
CREATE TABLE `StoreLocation` (
  `StoreID` varchar(20) NOT NULL,
  `street` varchar(100) DEFAULT NULL,
  `city` varchar(20) DEFAULT NULL,
  `state` varchar(20) DEFAULT NULL,
  `zipCode` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`StoreID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ----------------------------
-- Records of StoreLocation
-- ----------------------------
BEGIN;
INSERT INTO `StoreLocation` VALUES ('Canal', '1101 S Canal St', 'Denver', 'CO', '21076');
INSERT INTO `StoreLocation` VALUES ('Clark', '2728 N Clark St', 'Denver', 'CO', '29478');
INSERT INTO `StoreLocation` VALUES ('Dearborn', '200 N Dearborn St', 'Denver', 'CO', '20987');
INSERT INTO `StoreLocation` VALUES ('Fulton', '20 W Fulton St', 'Hollywood', 'CA', '95273');
INSERT INTO `StoreLocation` VALUES ('Halsted', '750 S Halsted St', 'Chicago', 'IL', '60616');
INSERT INTO `StoreLocation` VALUES ('Hongk', '10 S HongK St', 'Hollywood', 'CA', '98388');
INSERT INTO `StoreLocation` VALUES ('Lake', '5118 S Lake Ave', 'Syracuse', 'NY', '51028');
INSERT INTO `StoreLocation` VALUES ('LaSalle', '203 N LaSalle St', 'Chicago', 'IL', '60608');
INSERT INTO `StoreLocation` VALUES ('Madison', '108 N Madison Ave', 'Hollywood', 'CA', '91278');
INSERT INTO `StoreLocation` VALUES ('Park', '181 S Park St', 'Syracuse', 'NY', '57298');
INSERT INTO `StoreLocation` VALUES ('Stated', '108 N State St', 'Denver', 'CO', '27837');
INSERT INTO `StoreLocation` VALUES ('Webster', '1001 W Webster Ave', 'Chicago', 'IL', '60625');
COMMIT;

-- ----------------------------
-- Table structure for Transactions
-- ----------------------------
DROP TABLE IF EXISTS `Transactions`;
CREATE TABLE `Transactions` (
  `t_id` int NOT NULL AUTO_INCREMENT,
  `OrderId` int DEFAULT NULL,
  `user_id` int DEFAULT NULL,
  `username` varchar(20) DEFAULT NULL,
  `ProductId` varchar(20) DEFAULT NULL,
  `Category` varchar(20) DEFAULT NULL,
  `OrderPrice` double DEFAULT NULL,
  `OrderQuantity` int DEFAULT NULL,
  `Discount` double DEFAULT NULL,
  `TotalSales` double DEFAULT NULL,
  `creditCardNo` varchar(40) DEFAULT NULL,
  `ShippingAddress` varchar(100) DEFAULT NULL,
  `ShippingCost` double DEFAULT NULL,
  `PurchaseDate` date DEFAULT NULL,
  `ShipDate` date DEFAULT NULL,
  `StoreID` varchar(20) DEFAULT NULL,
  `StoreLocation` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`t_id`),
  UNIQUE KEY `t_id_UNIQUE` (`t_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `transactions_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `Registration` (`user_id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=111 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ----------------------------
-- Records of Transactions
-- ----------------------------
BEGIN;
INSERT INTO `Transactions` VALUES (52, 133128, 1, 'c1', 'QN65Q7FN', 'TV', 124, 2, 2, 246, '23647128364891237', '2801 S KING DRIVE, APT 1017, CHICAGO, ILLINOIS, 60616', 18, '2020-10-08', '2020-10-22', 'none', 'none');
INSERT INTO `Transactions` VALUES (53, 133549, 1, 'c1', 'XBR-65A8H', 'TV', 2498, 2, 216.8, 4779.2, '12873468912374', '20 W Fulton St, Hollywood, CA, 95273', 0, '2020-10-08', '2020-10-22', 'Fulton', '20 W Fulton St, Hollywood, CA, 95273');
INSERT INTO `Transactions` VALUES (54, 133549, 1, 'c1', 'Z323', 'SoundSystem', 189.99, 1, 20, 169.99, '12873468912374', '20 W Fulton St, Hollywood, CA, 95273', 0, '2020-10-08', '2020-10-22', 'Fulton', '20 W Fulton St, Hollywood, CA, 95273');
INSERT INTO `Transactions` VALUES (55, 133721, 1, 'c1', 'iphone xr', 'Phone', 599, 1, 0, 599, '2137489217398', '1001 W Webster Ave, Chicago, IL, 60625', 0, '2020-10-08', '2020-10-22', 'Webster', '1001 W Webster Ave, Chicago, IL, 60625');
INSERT INTO `Transactions` VALUES (56, 133838, 1, 'c1', '3.1 Channel', 'SoundSystem', 856, 1, 80, 776, '32764982379239', 'Shelly, Denver, CO, 21076', 18, '2020-10-08', '2020-10-22', 'none', 'none');
INSERT INTO `Transactions` VALUES (57, 134020, 1, 'c1', 'P30_ScreenPro', 'Accessory', 89.99, 1, 18, 71.99, '1234293847891', '10 S HongK St, Hollywood, CA, 98388', 0, '2020-10-08', '2020-10-22', 'Hongk', '10 S HongK St, Hollywood, CA, 98388');
INSERT INTO `Transactions` VALUES (58, 134218, 2, 'c2', 'M4800', 'Laptop', 658, 1, 18, 640, '12983748219374', '2397 S Michigan Ave, Denver, UT, 82379', 18, '2020-10-08', '2020-10-22', 'none', 'none');
INSERT INTO `Transactions` VALUES (59, 134735, 2, 'c2', 'A10', 'Phone', 168.99, 2, 38, 299.98, '39845703948', '108 N Madison Ave, Hollywood, CA, 91278', 0, '2020-10-08', '2020-10-22', 'Madison', '108 N Madison Ave, Hollywood, CA, 91278');
INSERT INTO `Transactions` VALUES (60, 134905, 2, 'c2', 'Latest Mac15', 'Laptop', 2549, 1, 0, 2549, '9238746712364', '2801 S King Drive, Chicago, IL, 60616', 18, '2020-10-08', '2020-10-22', 'none', 'none');
INSERT INTO `Transactions` VALUES (61, 134905, 2, 'c2', 'iphone 6s', 'Phone', 399.99, 1, 25, 374.99, '9238746712364', '2801 S King Drive, Chicago, IL, 60616', 18, '2020-10-08', '2020-10-22', 'none', 'none');
INSERT INTO `Transactions` VALUES (62, 134905, 2, 'c2', 'AirpodsPro', 'Accessory', 249, 1, 10, 239, '9238746712364', '2801 S King Drive, Chicago, IL, 60616', 18, '2020-10-08', '2020-10-22', 'none', 'none');
INSERT INTO `Transactions` VALUES (63, 135029, 2, 'c2', 'Ideapad3', 'Laptop', 549, 1, 39, 510, '30497829161234', '2801 S KING DRIVE, Denver, UT, 60616', 18, '2020-10-08', '2020-10-22', 'none', 'none');
INSERT INTO `Transactions` VALUES (64, 135136, 2, 'c2', 'Nest Mini', 'VoiceAssistant', 39.99, 1, 2.99, 37, '324562394785012', '108 N State St, Denver, CO, 27837', 0, '2020-10-08', '2020-10-22', 'Stated', '108 N State St, Denver, CO, 27837');
INSERT INTO `Transactions` VALUES (65, 135303, 3, 'c3', 'Mouse', 'Accessory', 89.99, 1, 0, 89.99, '209348120934890', '2728 N Clark St, Denver, CO, 29478', 0, '2020-10-08', '2020-10-22', 'Clark', '2728 N Clark St, Denver, CO, 29478');
INSERT INTO `Transactions` VALUES (66, 135522, 3, 'c3', 'WHISTLE Blue_Combo', 'PetTracker', 129.9, 1, 1.97, 127.93, '212983742089374', '2728 N Clark St, Denver, CO, 29478', 0, '2020-10-08', '2020-10-22', 'Clark', '2728 N Clark St, Denver, CO, 29478');
INSERT INTO `Transactions` VALUES (67, 135522, 3, 'c3', 'GARMIN F235', 'FitnessWatch', 169.99, 1, 12.99, 157, '212983742089374', '2728 N Clark St, Denver, CO, 29478', 0, '2020-10-08', '2020-10-22', 'Clark', '2728 N Clark St, Denver, CO, 29478');
INSERT INTO `Transactions` VALUES (68, 135522, 3, 'c3', 'OCULUS Rift_S', 'VirtualReality', 399, 1, 16, 383, '212983742089374', '2728 N Clark St, Denver, CO, 29478', 0, '2020-10-08', '2020-10-22', 'Clark', '2728 N Clark St, Denver, CO, 29478');
INSERT INTO `Transactions` VALUES (69, 135646, 3, 'c3', 'Note 9s', 'Phone', 210.93, 1, 8, 202.93, '9230749302112309', '2901 S Lake St, New York City, NY, 78762', 18, '2020-10-08', '2020-10-22', 'none', 'none');
INSERT INTO `Transactions` VALUES (70, 135726, 3, 'c3', 'Z506', 'SoundSystem', 39.99, 1, 0, 39.99, '129384912038919023', '2801 S KING DRIVE, Denver, UT, 60616', 18, '2020-10-08', '2020-10-22', 'none', 'none');
INSERT INTO `Transactions` VALUES (71, 135821, 3, 'c3', 'PANSONITE Anti', 'Headphone', 52.99, 1, 10, 42.99, '92302398401892', 'Yelp oak St, Chicago, IL, 60616', 18, '2020-10-08', '2020-10-22', 'none', 'none');
INSERT INTO `Transactions` VALUES (72, 140031, 4, 'c4', 'Mac13', 'Laptop', 1464, 1, 128, 1336, '324562938472903', 'K Pake Ave, Denver, UT, 60608', 18, '2020-10-08', '2020-10-22', 'none', 'none');
INSERT INTO `Transactions` VALUES (73, 140031, 4, 'c4', 'FITBIT Versa2', 'FitnessWatch', 179, 1, 15, 164, '324562938472903', 'K Pake Ave, Denver, UT, 60608', 18, '2020-10-08', '2020-10-22', 'none', 'none');
INSERT INTO `Transactions` VALUES (74, 140104, 4, 'c4', 'Mouse', 'Accessory', 89.99, 1, 0, 89.99, 'qwef', '1101 S Canal St, Denver, CO, 21076', 0, '2020-10-08', '2020-10-22', 'Canal', '1101 S Canal St, Denver, CO, 21076');
INSERT INTO `Transactions` VALUES (75, 140201, 4, 'c4', '2020', 'Laptop', 749, 1, 10, 739, '293842130984', '200 N Dearborn St, Denver, CO, 20987', 0, '2020-10-08', '2020-10-22', 'Dearborn', '200 N Dearborn St, Denver, CO, 20987');
INSERT INTO `Transactions` VALUES (107, 204227, 1, 'c1', 'iphone 11', 'Phone', 699, 1, 0, 699, '123847120938419023', '108 N State St, Denver, CO, 27837', 0, '2020-10-09', '2020-10-23', 'Stated', '108 N State St, Denver, CO, 27837');
INSERT INTO `Transactions` VALUES (108, 204227, 1, 'c1', 'AirpodsPro', 'Accessory', 249, 1, 10, 239, '123847120938419023', '108 N State St, Denver, CO, 27837', 0, '2020-10-09', '2020-10-23', 'Stated', '108 N State St, Denver, CO, 27837');
COMMIT;

SET FOREIGN_KEY_CHECKS = 1;
