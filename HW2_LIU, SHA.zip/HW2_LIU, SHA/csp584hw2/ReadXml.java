import org.dom4j.Attribute;
import org.dom4j.Document;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;

import java.io.File;
import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.Iterator;
import java.util.List;

public class ReadXml {
    public static void main(String[] args) {
        //插入数据的sql语句
        String sql = "insert into Productdetails(ProductType, Id, productName, productPrice, productImage, productManufacturer, productCondition, productDiscount) values (?, ?, ?, ?, ?, ?, ?, ?)";
        Connection conn;
        PreparedStatement pstmt = null;

        try {
            MySqlDataStoreUtilities.getConnection();

            conn = MySqlDataStoreUtilities.conn;
            pstmt = conn.prepareStatement(sql);
            //读取xml文件
            Document doc = new SAXReader().read(new File("/Library/Tomcat7/webapps/csp584/ProductCatalog.xml"));
            //选择xml文件的节点
            List itemList = doc.selectNodes("ProductCatalog/FitnessCatalog/fitness");
            //遍历读出的xml中的节点
            for (Iterator iter = itemList.iterator(); iter.hasNext(); ) {
                Element el = (Element) iter.next();
                //读取节点内容
                Attribute idAttr = el.attribute("id");
                String id = "";
                if (idAttr != null) {
                    id = idAttr.getValue();
                }
                String name = el.elementText("name");
                String price = el.elementText("price");
//                System.out.println("-- ReadXml.main -- " + price);
                String image = el.elementText("image");
                String manufacturer = el.elementText("manufacturer");
                String condition = el.elementText("condition");
                String discount = el.elementText("discount");



                //为sql语句赋值
                pstmt.setString(1, "FitnessWatch");
                pstmt.setString(2, id);
                pstmt.setString(3, name);
                pstmt.setDouble(4, new BigDecimal(price).doubleValue() );
                pstmt.setString(5, image);
                pstmt.setString(6, manufacturer);
                pstmt.setString(7, condition);
                pstmt.setDouble(8, new BigDecimal(discount).doubleValue());
                pstmt.addBatch();
            }
            pstmt.executeBatch();
            System.out.print("将XML导入数据库成功");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}