import com.sun.tools.corba.se.idl.constExpr.Or;
import sun.util.resources.cldr.zh.CalendarData_zh_Hans_HK;

import java.math.BigDecimal;
import java.sql.*;
import java.util.*;

public class MySqlDataStoreUtilities {
    static Connection conn = null;

    public static void getConnection() {

        try {
            Class.forName("com.mysql.cj.jdbc.Driver").newInstance();
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/csp584hw2?serverTimezone=UTC&useSSL=false&allowPublicKeyRetrieval=true", "root", "12345678");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    public static void deleteOrder(int orderId, String orderName) {
        try {
            getConnection();
            String deleteOrderQuery = "Delete from Transactions where OrderId=? and ProductId=?";
            PreparedStatement pst = conn.prepareStatement(deleteOrderQuery);
            pst.setInt(1, orderId);
            pst.setString(2, orderName);
            pst.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void insertOrder(int user_id, String username, String ShippingAddress, String creditCardNo, int OrderId, java.util.Date d1, java.util.Date d2,
                                   String ProductId, String Category, int OrderQuantity, double OrderPrice, double ShippingCost, double Discount, double TotalSales, String StoreID, String StoreLocation) {
        try {
            java.sql.Date PurchaseDate = new java.sql.Date(d1.getTime());
            java.sql.Date ShipDate = new java.sql.Date(d2.getTime());

            getConnection();
            String insertIntoCustomerOrderQuery = "INSERT INTO Transactions(user_id,username, ShippingAddress, " +
                    "creditCardNo,OrderId,PurchaseDate,ShipDate,ProductId,Category,OrderQuantity, " +
                    "OrderPrice, ShippingCost, Discount, TotalSales, StoreID, StoreLocation) "
                    + "VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?);";
            PreparedStatement pst = conn.prepareStatement(insertIntoCustomerOrderQuery);
            //set the parameter for each column and execute the prepared statement
            pst.setInt(1, user_id);
            pst.setString(2, username);
            pst.setString(3, ShippingAddress);
            pst.setString(4, creditCardNo);
            pst.setInt(5, OrderId);
            pst.setDate(6, PurchaseDate);
            pst.setDate(7, ShipDate);
            pst.setString(8, ProductId);
            pst.setString(9, Category);
            pst.setInt(10, OrderQuantity);
            pst.setDouble(11, OrderPrice);
            pst.setDouble(12, ShippingCost);
            pst.setDouble(13, Discount);
            pst.setDouble(14, (int)TotalSales);
            pst.setString(15, StoreID);
            pst.setString(16, StoreLocation);
            pst.execute();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static HashMap<Integer, ArrayList<OrderPayment>> selectOrder() {

        HashMap<Integer, ArrayList<OrderPayment>> orderPayments = new HashMap<Integer, ArrayList<OrderPayment>>();

        try {

            getConnection();
            //select the table
            String selectOrderQuery = "select * from Transactions";
            PreparedStatement pst = conn.prepareStatement(selectOrderQuery);
            ResultSet rs = pst.executeQuery();
            ArrayList<OrderPayment> orderList = new ArrayList<OrderPayment>();
            while (rs.next()) {
                if (!orderPayments.containsKey(rs.getInt("OrderId"))) {
                    ArrayList<OrderPayment> arr = new ArrayList<OrderPayment>();
                    orderPayments.put(rs.getInt("OrderId"), arr);
                }
                ArrayList<OrderPayment> listOrderPayment = orderPayments.get(rs.getInt("OrderId"));
                System.out.println("data is" + rs.getInt("user_id")+rs.getString("userName")+ rs.getString("ShippingAddress")+ rs.getString("creditCardNo") + rs.getInt("OrderId")+ rs.getDate("PurchaseDate")+rs.getDate("ShipDate")+rs.getString("ProductId")+rs.getString("Category")+rs.getInt("OrderQuantity")+rs.getDouble("OrderPrice")+rs.getDouble("ShippingCost")+rs.getDouble("Discount")+rs.getDouble("TotalSales")+rs.getString("StoreID")+rs.getString("StoreLocation"));

                //add to orderpayment hashmap
                OrderPayment order = new OrderPayment(rs.getInt("user_id"), rs.getString("userName"), rs.getString("ShippingAddress"), rs.getString("creditCardNo"),rs.getInt("OrderId"), rs.getDate("PurchaseDate"),rs.getDate("ShipDate"),rs.getString("ProductId"),rs.getString("Category"),rs.getInt("OrderQuantity"),rs.getDouble("OrderPrice"),rs.getDouble("ShippingCost"),rs.getDouble("Discount"),rs.getDouble("TotalSales"),rs.getString("StoreID"),rs.getString("StoreLocation"));
                listOrderPayment.add(order);

            }


        } catch (Exception e) {
            e.printStackTrace();
        }
        return orderPayments;
    }

    public static void updateOrder(String address,String creditCard){
        try{
            getConnection();

            String sql = "update Transactions set ShippingAddress=?,creditCardNo=? ";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setString(1,address);
            pstmt.setString(2,creditCard);
        }catch (Exception e){
            e.printStackTrace();
        }
    }

    public static void insertCustomerAddress(String userName, String street, String city, String state, String zipCode) {
        try {

            getConnection();
            String insertIntoCustomeAddressQuery = "INSERT INTO CustomerAddress(CustomerName,street,city,state,zipCode) "
                    + "VALUES (?,?,?,?,?);";

            PreparedStatement pst = conn.prepareStatement(insertIntoCustomeAddressQuery);
            //set the parameter for each column and execute the prepared statement
            pst.setString(1, userName);
            pst.setString(2, street);
            pst.setString(3, city);
            pst.setString(4, state);
            pst.setString(5, zipCode);
            pst.execute();
        } catch (Exception e) {

        }
    }


    public static boolean insertUser(String username, String password, String repassword, String usertype) {
        try {

            getConnection();
            String insertIntoCustomerRegisterQuery = "INSERT INTO Registration(username,password,repassword,usertype) "
                    + "VALUES (?,?,?,?);";

            PreparedStatement pst = conn.prepareStatement(insertIntoCustomerRegisterQuery);
            pst.setString(1, username);
            pst.setString(2, password);
            pst.setString(3, repassword);
            pst.setString(4, usertype);
            pst.execute();
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
        return true;
    }

    public static HashMap<String, User> selectUser() {
        HashMap<String, User> hm = new HashMap<String, User>();
        try {
            getConnection();
            Statement stmt = conn.createStatement();
            String selectCustomerQuery = "select * from  Registration";
            ResultSet rs = stmt.executeQuery(selectCustomerQuery);
            while (rs.next()) {
                User user = new User(rs.getString("username"), rs.getString("password"), rs.getString("usertype"));
                hm.put(rs.getString("username"), user);
            }
        } catch (Exception e) {
        }
        return hm;
    }


    public static HashMap<String, TV> getTV() {
        HashMap<String, TV> hm = new HashMap<String, TV>();
        try {
            getConnection();

            String selectTV = "select * from  Productdetails where ProductType=?";
            PreparedStatement pstmt = conn.prepareStatement(selectTV);
            pstmt.setString(1, "TV");
            ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
                TV tv = new TV(rs.getString("productName"), rs.getDouble("productPrice"), rs.getString("productImage"), rs.getString("productManufacturer"), rs.getString("productCondition"), rs.getDouble("productDiscount"), rs.getString("ProductType"));
                hm.put(rs.getString("Id"), tv);
                tv.setId(rs.getString("Id"));
            }
        } catch (Exception e) {
        }
        return hm;
    }

    public static HashMap<String, SoundSystem> getSoundSystem() {
        HashMap<String, SoundSystem> hm = new HashMap<String, SoundSystem>();
        try {
            getConnection();

            String selectSoundSystem = "select * from Productdetails where ProductType=?";
            PreparedStatement pstmt = conn.prepareStatement(selectSoundSystem);
            pstmt.setString(1, "SoundSystem");
            ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
                SoundSystem soundSystem = new SoundSystem(rs.getString("productName"), rs.getDouble("productPrice"), rs.getString("productImage"), rs.getString("productManufacturer"), rs.getString("productCondition"), rs.getDouble("productDiscount"), rs.getString("ProductType"));
                hm.put(rs.getString("Id"), soundSystem);
                soundSystem.setId(rs.getString("Id"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return hm;
    }

    public static HashMap<String, Phone> getPhoneAcc() {
        HashMap<String, Phone> hm = new HashMap<String, Phone>();
        try {
            getConnection();

            String selectPhone = "select * from Productdetails where ProductType=?";
            PreparedStatement pstmt = conn.prepareStatement(selectPhone);
            pstmt.setString(1, "Phone");
            ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
                Phone phone = new Phone(rs.getString("productName"), rs.getDouble("productPrice"), rs.getString("productImage"), rs.getString("productManufacturer"), rs.getString("productCondition"), rs.getDouble("productDiscount"),rs.getString("ProductType"));
                hm.put(rs.getString("Id"), phone);
                phone.setId(rs.getString("Id"));
                try {
                    String selectAcc = "select * from Product_accessories where productName=?";
                    PreparedStatement pstmtAcc = conn.prepareStatement(selectAcc);
                    pstmtAcc.setString(1, rs.getString("Id"));
                    ResultSet rsAcc = pstmtAcc.executeQuery();
                    IdentityHashMap<String, String> accHashmap = new IdentityHashMap<String, String>();
                    while (rsAcc.next()) {
                        if (rsAcc.getString("accessoriesName") != null) {
                            accHashmap.put(rsAcc.getString("productName"), rsAcc.getString("accessoriesName"));
                            phone.setAccessories(accHashmap);
                        }
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return hm;
    }

    public static HashMap<String, Laptop> getLaptop() {
        HashMap<String, Laptop> hm = new HashMap<String, Laptop>();
        try {
            getConnection();

            String selectLaptop = "select * from Productdetails where ProductType=?";
            PreparedStatement pstmt = conn.prepareStatement(selectLaptop);
            pstmt.setString(1, "Laptop");
            ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
                Laptop laptop = new Laptop(rs.getString("productName"), rs.getDouble("productPrice"), rs.getString("productImage"), rs.getString("productManufacturer"), rs.getString("productCondition"), rs.getDouble("productDiscount"),rs.getString("ProductType"));
                hm.put(rs.getString("Id"), laptop);
                laptop.setId(rs.getString("Id"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return hm;
    }

    public static HashMap<String, VoiceAssistant> getVoiceAssistant() {
        HashMap<String, VoiceAssistant> hm = new HashMap<String, VoiceAssistant>();
        try {
            getConnection();

            String selectVoiceAssistant = "select * from Productdetails where ProductType=?";
            PreparedStatement pstmt = conn.prepareStatement(selectVoiceAssistant);
            pstmt.setString(1, "VoiceAssistant");
            ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
                VoiceAssistant voiceAssistant = new VoiceAssistant(rs.getString("productName"), rs.getDouble("productPrice"), rs.getString("productImage"), rs.getString("productManufacturer"), rs.getString("productCondition"), rs.getDouble("productDiscount"),rs.getString("ProductType"));
                hm.put(rs.getString("Id"), voiceAssistant);
                voiceAssistant.setId(rs.getString("Id"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return hm;
    }

    public static HashMap<String, FitnessWatch> getFitnessWatch() {
        HashMap<String, FitnessWatch> hm = new HashMap<String, FitnessWatch>();
        try {
            getConnection();

            String selectFitnessWatch = "select * from  Productdetails where ProductType=?";
            PreparedStatement pstmt = conn.prepareStatement(selectFitnessWatch);
            pstmt.setString(1, "FitnessWatch");
            ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
                FitnessWatch fitnessWatch = new FitnessWatch(rs.getString("productName"), rs.getDouble("productPrice"), rs.getString("productImage"), rs.getString("productManufacturer"), rs.getString("productCondition"), rs.getDouble("productDiscount"),rs.getString("ProductType"));
                hm.put(rs.getString("Id"), fitnessWatch);
                fitnessWatch.setId(rs.getString("Id"));
            }
        } catch (Exception e) {
        }
        return hm;
    }

    public static HashMap<String, SmartWatch> getSmartWatch() {
        HashMap<String, SmartWatch> hm = new HashMap<String, SmartWatch>();
        try {
            getConnection();

            String selectSmartWatch = "select * from  Productdetails where ProductType=?";
            PreparedStatement pstmt = conn.prepareStatement(selectSmartWatch);
            pstmt.setString(1, "SmartWatch");
            ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
                SmartWatch smartWatch = new SmartWatch(rs.getString("productName"), rs.getDouble("productPrice"), rs.getString("productImage"), rs.getString("productManufacturer"), rs.getString("productCondition"), rs.getDouble("productDiscount"),rs.getString("ProductType"));
                hm.put(rs.getString("Id"), smartWatch);
                smartWatch.setId(rs.getString("Id"));
            }
        } catch (Exception e) {
        }
        return hm;
    }

    public static HashMap<String, Headphone> getHeadphone() {
        HashMap<String, Headphone> hm = new HashMap<String, Headphone>();
        try {
            getConnection();

            String selectHeadphone = "select * from  Productdetails where ProductType=?";
            PreparedStatement pst = conn.prepareStatement(selectHeadphone);
            pst.setString(1, "Headphone");
            ResultSet rs = pst.executeQuery();

            while (rs.next()) {
                Headphone headphone = new Headphone(rs.getString("productName"), rs.getDouble("productPrice"), rs.getString("productImage"), rs.getString("productManufacturer"), rs.getString("productCondition"), rs.getDouble("productDiscount"),rs.getString("ProductType"));
                hm.put(rs.getString("Id"), headphone);
                headphone.setId(rs.getString("Id"));
            }
        } catch (Exception e) {
        }
        return hm;
    }

    public static HashMap<String, VirtualReality> getVirtualReality() {
        HashMap<String, VirtualReality> hm = new HashMap<String, VirtualReality>();
        try {
            getConnection();

            String selectVirtualReality = "select * from  Productdetails where ProductType=?";
            PreparedStatement pstmt = conn.prepareStatement(selectVirtualReality);
            pstmt.setString(1, "VirtualReality");
            ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
                VirtualReality virtualReality = new VirtualReality(rs.getString("productName"), rs.getDouble("productPrice"), rs.getString("productImage"), rs.getString("productManufacturer"), rs.getString("productCondition"), rs.getDouble("productDiscount"),rs.getString("ProductType"));
                hm.put(rs.getString("Id"), virtualReality);
                virtualReality.setId(rs.getString("Id"));
            }
        } catch (Exception e) {
        }
        return hm;
    }

    public static HashMap<String, PetTracker> getPetTracker() {
        HashMap<String, PetTracker> hm = new HashMap<String, PetTracker>();
        try {
            getConnection();

            String selectPetTracker = "select * from  Productdetails where ProductType=?";
            PreparedStatement pstmt = conn.prepareStatement(selectPetTracker);
            pstmt.setString(1, "PetTracker");
            ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
                PetTracker petTracker = new PetTracker(rs.getString("productName"), rs.getDouble("productPrice"), rs.getString("productImage"), rs.getString("productManufacturer"), rs.getString("productCondition"), rs.getDouble("productDiscount"),rs.getString("ProductType"));
                hm.put(rs.getString("Id"), petTracker);
                petTracker.setId(rs.getString("Id"));
            }
        } catch (Exception e) {
        }
        return hm;
    }

    public static HashMap<String, Accessory> getAccessory() {
        HashMap<String, Accessory> hm = new HashMap<String, Accessory>();
        try {
            getConnection();

            String selectAcc = "select * from  Productdetails where ProductType=?";
            PreparedStatement pstmt = conn.prepareStatement(selectAcc);
            pstmt.setString(1, "Accessory");
            ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
                Accessory acc = new Accessory(rs.getString("productName"), rs.getDouble("productPrice"), rs.getString("productImage"), rs.getString("productManufacturer"), rs.getString("productCondition"), rs.getDouble("productDiscount"),rs.getString("ProductType"));
                hm.put(rs.getString("Id"), acc);
                acc.setId(rs.getString("Id"));
                //		System.out.println(rs.getString("Id"));
            }
        } catch (Exception e) {
        }
        return hm;
    }

    public static HashMap<String, CustomerAddress> getStoreLocation() {
        HashMap<String, CustomerAddress> hm = new HashMap<String, CustomerAddress>();
        try {
            getConnection();

            String selectLoc = "select * from  StoreLocation";
            PreparedStatement pstmt = conn.prepareStatement(selectLoc);
            ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
                CustomerAddress customerAddress = new CustomerAddress(rs.getString("street"),rs.getString("city"),rs.getString("state"),rs.getString("zipCode"));
                hm.put(rs.getString("StoreID"), customerAddress);
            }
        } catch (Exception e) {
        }
        return hm;
    }

    public static HashMap<String, Integer> getUser_id() {
        HashMap<String, Integer> hm = new HashMap();
        try {
            getConnection();

            String selectAcc = "select * from  Registration";
            PreparedStatement pstmt = conn.prepareStatement(selectAcc);
            ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
                hm.put(rs.getString("username"),rs.getInt("user_id"));
            }
        } catch (Exception e) {
        }
        return hm;
    }
}	