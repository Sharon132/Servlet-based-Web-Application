import java.io.IOException;
import java.io.*;
import java.util.Date;


/* 
	OrderPayment class contains class variables username,ordername,price,image,address,creditcardno.

	OrderPayment  class has a constructor with Arguments username,ordername,price,image,address,creditcardno
	  
	OrderPayment  class contains getters and setters for username,ordername,price,image,address,creditcardno
*/

public class OrderPayment implements Serializable {
    private int orderId;
    private String userName;
    private String orderName;
    private double orderPrice;
    private String userAddress;
    private String creditCardNo;

    private int user_id;
    private String ShippingAddress;
    private java.util.Date purchaseDay;
    private java.util.Date shippingDay;
    private String ProductId;
    private String Category;
    private int OrderQuantity;
    private double ShippingCost;
    private double discount;
    private double totalSales;
    private String storeId;
    private String location;

    public OrderPayment(int orderId, String userName, String orderName, double orderPrice, String userAddress, String creditCardNo) {
        this.orderId = orderId;
        this.userName = userName;
        this.orderName = orderName;
        this.orderPrice = orderPrice;
        this.userAddress = userAddress;
        this.creditCardNo = creditCardNo;
    }

    public OrderPayment(int user_id, String username, String ShippingAddress, String creditCardNo, int OrderId, java.util.Date d1, java.util.Date d2,
                        String ProductId, String Category, int OrderQuantity, double OrderPrice, double ShippingCost, double Discount, double TotalSales, String StoreID, String StoreLocation){
        this.user_id = user_id;
        this.userName = username;
        this.ShippingAddress = ShippingAddress;
        this.creditCardNo = creditCardNo;
        this.orderId = OrderId;
        this.purchaseDay = d1;
        this.shippingDay = d2;
        this.ProductId = ProductId;
        this.Category = Category;
        this.OrderQuantity = OrderQuantity;
        this.orderPrice = OrderPrice;
        this.ShippingCost = ShippingCost;
        this.discount = Discount;
        this.totalSales = TotalSales;
        this.storeId = StoreID;
        this.location = StoreLocation;
    }

    public String getUserAddress() {
        return userAddress;
    }

    public void setUserAddress(String userAddress) {
        this.userAddress = userAddress;
    }

    public String getCreditCardNo() {
        return creditCardNo;
    }

    public void setCreditCardNo(String creditCardNo) {
        this.creditCardNo = creditCardNo;
    }

    public String getOrderName() {
        return orderName;
    }

    public void setOrderName(String orderName) {
        this.orderName = orderName;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public int getOrderId() {
        return orderId;
    }

    public void setOrderId(int orderId) {
        this.orderId = orderId;
    }


    public double getOrderPrice() {
        return orderPrice;
    }

    public void setOrderPrice(double orderPrice) {
        this.orderPrice = orderPrice;
    }

    public int getUser_id() {
        return user_id;
    }

    public void setUser_id(int user_id) {
        this.user_id = user_id;
    }

    public String getShippingAddress() {
        return ShippingAddress;
    }

    public void setShippingAddress(String shippingAddress) {
        ShippingAddress = shippingAddress;
    }

    public Date getPurchaseDay() {
        return purchaseDay;
    }

    public void setPurchaseDay(Date purchaseDay) {
        this.purchaseDay = purchaseDay;
    }

    public Date getShippingDay() {
        return shippingDay;
    }

    public void setShippingDay(Date shippingDay) {
        this.shippingDay = shippingDay;
    }

    public String getProductId() {
        return ProductId;
    }

    public void setProductId(String productId) {
        ProductId = productId;
    }

    public String getCategory() {
        return Category;
    }

    public void setCategory(String category) {
        Category = category;
    }

    public int getOrderQuantity() {
        return OrderQuantity;
    }

    public void setOrderQuantity(int orderQuantity) {
        OrderQuantity = orderQuantity;
    }

    public double getShippingCost() {
        return ShippingCost;
    }

    public void setShippingCost(double shippingCost) {
        ShippingCost = shippingCost;
    }

    public double getDiscount() {
        return discount;
    }

    public void setDiscount(double discount) {
        this.discount = discount;
    }

    public double getTotalSales() {
        return totalSales;
    }

    public void setTotalSales(double totalSales) {
        this.totalSales = totalSales;
    }

    public String getStoreId() {
        return storeId;
    }

    public void setStoreId(String storeId) {
        this.storeId = storeId;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }
}
