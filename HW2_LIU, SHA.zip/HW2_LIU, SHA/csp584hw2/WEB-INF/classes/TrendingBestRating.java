import java.io.*;
public class TrendingBestRating
{
String productname ;
String rating;


public TrendingBestRating(String productname, String rating)
{
	
	this.productname = productname ;
    this.rating = rating;
}


public String getProductname(){
 return productname;
}

public String getRating () {
 return rating;
}
}