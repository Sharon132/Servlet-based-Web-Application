import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Random;

@WebServlet("/Payment")

public class Payment extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        response.setContentType("text/html");
        PrintWriter pw = response.getWriter();


        Utilities utility = new Utilities(request, pw);
        if (!utility.isLoggedin()) {
            HttpSession session = request.getSession(true);
            session.setAttribute("login_msg", "Please Login to Pay");
            response.sendRedirect("Login");
            return;
        }
        // get the payment details like credit card no address processed from cart servlet

        String state = request.getParameter("state");
        String city = request.getParameter("city");
        String creditCardNo = request.getParameter("creditCardNo");
        String zipCode_d = request.getParameter("zipCode_d");
        String zipCode_p = request.getParameter("zipCode_p");

        String userAddress = request.getParameter("userAddress");
        String location = request.getParameter("location");
        if (!state.isEmpty() && !city.isEmpty() && !creditCardNo.isEmpty()) {
            int orderId = utility.getOrderPaymentSize() + 1;

            if (!zipCode_d.isEmpty() && !userAddress.isEmpty()) {
                for (OrderItem oi : utility.getCustomerOrders()) {

                    utility.storePayment(orderId, oi.getName(), oi.getPrice(), creditCardNo, zipCode_d, userAddress, city, state);
                }
            } else if (!zipCode_p.isEmpty() && !location.isEmpty()) {
                for (OrderItem oi : utility.getCustomerOrders()) {

                    utility.storePayment(orderId, oi.getName(), oi.getPrice(), creditCardNo, zipCode_p, location, city, state);
                }
            } else {
                printError(utility, pw);
            }
            OrdersHashMap.orders.remove(utility.username());
            utility.printHtml("Header.html");
            utility.printHtml("LeftNavigationBar.html");
            pw.print("<div id='content'><div class='post'><h2 class='title meta'>");
            pw.print("<a style='font-size: 24px;'>Order</a>");
            pw.print("</h2><div class='entry'>");

            pw.print("<h2>Your Order");
            pw.print("&nbsp&nbsp");
            pw.print("is stored ");
            pw.print("<br>Your Order No is " + (orderId));
            if (userAddress.isEmpty())
                pw.print("<br/>Delivery Method: Pick up at " + location);
            else
                pw.print("<br/>Delivery Method: Home Delivery to  " + userAddress);

            //获得delivery date
            SimpleDateFormat deliveryDateFormat = new SimpleDateFormat("MM-dd");//设置日期格式
            String today = deliveryDateFormat.format(new Date());
            Calendar c = Calendar.getInstance();
            try {
                c.setTime(deliveryDateFormat.parse(today));
            } catch (ParseException e) {
                e.printStackTrace();
            }
            c.add(Calendar.DATE, 14);  // number of days to add
            today = deliveryDateFormat.format(c.getTime());
            pw.print("<br>Estimated delivery date: " + today);

            pw.print("</h2></div></div></div>");
            utility.printHtml("Footer.html");
        } else {
            printError(utility, pw);
        }

    }

    public void printError(Utilities utility, PrintWriter pw) {
        utility.printHtml("Header.html");
        utility.printHtml("LeftNavigationBar.html");
        pw.print("<div id='content'><div class='post'><h2 class='title meta'>");
        pw.print("<a style='font-size: 24px;'>Order</a>");
        pw.print("</h2><div class='entry'>");

        pw.print("<h4 style='color:red'>Please enter valid info</h4>");
        pw.print("</h2></div></div></div>");
        utility.printHtml("Footer.html");
    }
}
