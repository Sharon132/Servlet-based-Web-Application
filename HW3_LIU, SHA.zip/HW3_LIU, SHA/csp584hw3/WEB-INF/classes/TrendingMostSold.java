import java.io.*;
public class TrendingMostSold
{
String productname ;
String count;


public TrendingMostSold(String productname, String count)
{
	
	this.productname = productname;
    this.count = count;
}


public String getProductName(){
 return productname;
}


public String getCount () {
 return count;
}
}