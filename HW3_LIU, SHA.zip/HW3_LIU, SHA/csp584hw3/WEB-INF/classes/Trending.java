import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

@WebServlet("/Trending")

public class Trending extends HttpServlet {

    private String title;

    @Override
    protected void doGet(HttpServletRequest request,
                         HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter pw = response.getWriter();
        String dataType = "";
        ArrayList<TrendingBestRating> bestRatings = new ArrayList<>();
        ArrayList<TrendingMostsoldzip> mostsoldzip = new ArrayList<>();
        ArrayList<TrendingMostSold> mostSold = new ArrayList<>();

        dataType = request.getParameter("dataType");
        if (dataType != null) {
            if (dataType.equals("1")) {
                bestRatings = MongoDBDataStoreUtilities.topProducts();
                title = "Top five most liked products";
            }
            if (dataType.equals("2")) {
                mostsoldzip = MongoDBDataStoreUtilities.mostsoldZip();
                title = "Top five zip-codes where maximum number of products sold";
            }
            if (dataType.equals("3")) {
                mostSold = MongoDBDataStoreUtilities.mostsoldProducts();
                title = "Top five most sold products regardless of the rating";
            }
        }


        Utilities utility = new Utilities(request, pw);
        utility.printHtml("Header.html");
        utility.printHtml("LeftNavigationBar.html");
        pw.print("<div id='content'><div class='post'><h2 class='title meta'>");
        pw.print("<a style='font-size: 24px;'>" + title + "</a>");
        pw.print("</h2><div class='entry'><table id='bestseller'>");
        if (dataType.equals("1")) {
            pw.print("<tr><td></td><td>Product Name</td> <td>Rating</td></tr>");
            for (int i = 0; i < bestRatings.size(); i++) {
                pw.write("<tr>");
                pw.write("<td>" + (i + 1) + "</td>");
                pw.write("<td> " + bestRatings.get(i).getProductname() + "</td>");
                pw.write("<td>" + bestRatings.get(i).getRating() + "</td>");
                pw.write("</td></tr>");
            }
        }

        if (dataType.equals("2")) {
            pw.print("<tr><td></td><td>ZIP Code</td> <td>count</td></tr>");
            for (int i = 0; i < mostsoldzip.size(); i++) {
                pw.write("<tr>");
                pw.write("<td>" + (i + 1) + "</td>");
                pw.write("<td> " + mostsoldzip.get(i).getZipcode() + "</td>");
                pw.write("<td>" + mostsoldzip.get(i).getCount() + "</td>");
                pw.write("</td></tr>");
            }
        }

        if (dataType.equals("3")) {
            pw.print("<tr><td></td><td>Product Name</td> <td>count</td></tr>");
            for (int i = 0; i < mostSold.size(); i++) {
                pw.write("<tr>");
                pw.write("<td>" + (i + 1) + "</td>");
                pw.write("<td> " + mostSold.get(i).getProductName() + "</td>");
                pw.write("<td>" + mostSold.get(i).getCount() + "</td>");
                pw.write("</td></tr>");
            }
        }
        pw.print("</table></div></div></div>");
        utility.printHtml("Footer.html");
    }

    @Override
    protected void doPost(HttpServletRequest request,
                          HttpServletResponse response) throws ServletException, IOException {

    }

}
