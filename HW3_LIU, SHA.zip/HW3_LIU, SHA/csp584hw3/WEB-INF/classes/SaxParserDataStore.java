
/*********


 http://www.saxproject.org/

 SAX is the Simple API for XML, originally a Java-only API.
 SAX was the first widely adopted API for XML in Java, and is a �de facto� standard.
 The current version is SAX 2.0.1, and there are versions for several programming language environments other than Java.

 The following URL from Oracle is the JAVA documentation for the API

 https://docs.oracle.com/javase/7/docs/api/org/xml/sax/helpers/DefaultHandler.html
 *********/

import java.io.IOException;
import java.util.*;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;


////////////////////////////////////////////////////////////

/**************

 SAX parser use callback function  to notify client object of the XML document structure.
 You should extend DefaultHandler and override the method when parsin the XML document
 ***************/

////////////////////////////////////////////////////////////

public class SaxParserDataStore extends DefaultHandler {
    TV tv;
    SoundSystem sound;
    static Phone phone;
    Laptop laptop;
    VoiceAssistant voice;
    FitnessWatch fitness;
    SmartWatch smart;
    Headphone headphone;
    VirtualReality virtual;
    PetTracker pet;
    Accessory accessory;

    static HashMap<String, TV> tvs;
    static HashMap<String, SoundSystem> sounds;
    static HashMap<String, Phone> phones;
    static HashMap<String, Laptop> laptops;
    static HashMap<String, VoiceAssistant> voices;
    static HashMap<String, FitnessWatch> fitnesses;
    static HashMap<String, SmartWatch> smarts;
    static HashMap<String, Headphone> headphones;
    static HashMap<String, VirtualReality> virtuals;
    static HashMap<String, PetTracker> pets;
    static HashMap<String, Accessory> accessories;


    static IdentityHashMap<String, String> accessoryHashMap;

    public SaxParserDataStore() {
        tvs = new HashMap<String, TV>();
        sounds = new HashMap<String, SoundSystem>();
        phones = new HashMap<String, Phone>();
        laptops = new HashMap<String, Laptop>();
        voices = new HashMap<String, VoiceAssistant>();
        fitnesses = new HashMap<String, FitnessWatch>();
        smarts = new HashMap<String, SmartWatch>();
        headphones = new HashMap<String, Headphone>();
        virtuals = new HashMap<String, VirtualReality>();
        pets = new HashMap<String, PetTracker>();
        accessories = new HashMap<String, Accessory>();

        accessoryHashMap = new IdentityHashMap<String, String>();
    }

    //parse the xml using sax parser to get the data

////////////////////////////////////////////////////////////

    /*************

     There are a number of methods to override in SAX handler  when parsing your XML document :

     Group 1. startDocument() and endDocument() :  Methods that are called at the start and end of an XML document.
     Group 2. startElement() and endElement() :  Methods that are called  at the start and end of a document element.
     Group 3. characters() : Method that is called with the text content in between the start and end tags of an XML document element.


     There are few other methods that you could use for notification for different purposes, check the API at the following URL:

     https://docs.oracle.com/javase/7/docs/api/org/xml/sax/helpers/DefaultHandler.html
     ***************/

////////////////////////////////////////////////////////////



    /////////////////////////////////////////
    // 	     Kick-Start SAX in main       //
    ////////////////////////////////////////
//    }
    public static void addHashmap() {
       tvs = MySqlDataStoreUtilities.getTV();
       sounds= MySqlDataStoreUtilities.getSoundSystem();
       phones = MySqlDataStoreUtilities.getPhoneAcc();
       laptops=MySqlDataStoreUtilities.getLaptop();
       voices = MySqlDataStoreUtilities.getVoiceAssistant();
       fitnesses = MySqlDataStoreUtilities.getFitnessWatch();
       smarts = MySqlDataStoreUtilities.getSmartWatch();
       headphones = MySqlDataStoreUtilities.getHeadphone();
       virtuals = MySqlDataStoreUtilities.getVirtualReality();
       pets = MySqlDataStoreUtilities.getPetTracker();
       accessories = MySqlDataStoreUtilities.getAccessory();
       accessoryHashMap = phone.getAccessories();
    }
}
