import java.io.*;
public class TrendingMostsoldzip
{
String zipcode ;
String count;


public TrendingMostsoldzip(String zipcode, String count)
{
	
	this.zipcode = zipcode ;
    this.count = count;
}


public String getZipcode(){
 return zipcode;
}

public String getCount () {
 return count;
}
}