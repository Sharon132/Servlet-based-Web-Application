/*
 Navicat Premium Data Transfer

 Source Server         : local_mysql
 Source Server Type    : MySQL
 Source Server Version : 80021
 Source Host           : localhost:3306
 Source Schema         : csp584hw2

 Target Server Type    : MySQL
 Target Server Version : 80021
 File Encoding         : 65001

 Date: 15/11/2020 05:49:19
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for CustomerAddress
-- ----------------------------
DROP TABLE IF EXISTS `CustomerAddress`;
CREATE TABLE `CustomerAddress` (
  `CustomerName` varchar(20) DEFAULT NULL,
  `street` varchar(100) DEFAULT NULL,
  `city` varchar(20) DEFAULT NULL,
  `state` varchar(20) DEFAULT NULL,
  `zipCode` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ----------------------------
-- Records of CustomerAddress
-- ----------------------------
BEGIN;
INSERT INTO `CustomerAddress` VALUES ('c1', '2801 S KING DRIVE, APT 1017', 'CHICAGO', 'ILLINOIS', '60616');
INSERT INTO `CustomerAddress` VALUES ('c1', '20 W Fulton St', 'Hollywood', 'CA', '95273');
INSERT INTO `CustomerAddress` VALUES ('c1', '1001 W Webster Ave', 'Chicago', 'IL', '60625');
INSERT INTO `CustomerAddress` VALUES ('c1', 'Shelly', 'Denver', 'CO', '21076');
INSERT INTO `CustomerAddress` VALUES ('c1', '10 S HongK St', 'Hollywood', 'CA', '98388');
INSERT INTO `CustomerAddress` VALUES ('c2', '2397 S Michigan Ave', 'Denver', 'UT', '82379');
INSERT INTO `CustomerAddress` VALUES ('c2', '108 N Madison Ave', 'Hollywood', 'CA', '91278');
INSERT INTO `CustomerAddress` VALUES ('c2', '2801 S King Drive', 'Chicago', 'IL', '60616');
INSERT INTO `CustomerAddress` VALUES ('c2', '2801 S KING DRIVE', 'Denver', 'UT', '60616');
INSERT INTO `CustomerAddress` VALUES ('c2', '108 N State St', 'Denver', 'CO', '27837');
INSERT INTO `CustomerAddress` VALUES ('c3', '2728 N Clark St', 'Denver', 'CO', '29478');
INSERT INTO `CustomerAddress` VALUES ('c3', '2728 N Clark St', 'Denver', 'CO', '29478');
INSERT INTO `CustomerAddress` VALUES ('c3', '2901 S Lake St', 'New York City', 'NY', '78762');
INSERT INTO `CustomerAddress` VALUES ('c3', '2801 S KING DRIVE', 'Denver', 'UT', '60616');
INSERT INTO `CustomerAddress` VALUES ('c3', 'Yelp oak St', 'Chicago', 'IL', '60616');
INSERT INTO `CustomerAddress` VALUES ('c4', 'K Pake Ave', 'Denver', 'UT', '60608');
INSERT INTO `CustomerAddress` VALUES ('c4', '1101 S Canal St', 'Denver', 'CO', '21076');
INSERT INTO `CustomerAddress` VALUES ('c4', '200 N Dearborn St', 'Denver', 'CO', '20987');
INSERT INTO `CustomerAddress` VALUES ('c4', '5118 S Lake Ave', 'Syracuse', 'NY', '51028');
INSERT INTO `CustomerAddress` VALUES ('c4', '2801 S KING DRIVE', 'Chicago', 'IL', '60616');
INSERT INTO `CustomerAddress` VALUES ('sa1', '750 S Halsted St', 'Chicago', 'IL', '60616');
INSERT INTO `CustomerAddress` VALUES ('c1', '20 W Fulton St', 'Hollywood', 'CA', '95273');
INSERT INTO `CustomerAddress` VALUES ('c1', '20 W Fulton St', 'Hollywood', 'CA', '95273');
INSERT INTO `CustomerAddress` VALUES ('c1', 'qwekjrnfkqwe', 'CHICAGO', 'ILLINOIS', '60616');
INSERT INTO `CustomerAddress` VALUES ('c1', '2728 N Clark St', 'Denver', 'CO', '29478');
INSERT INTO `CustomerAddress` VALUES ('c2', '1105 Pake ST', 'Hste', 'ID', '56788');
INSERT INTO `CustomerAddress` VALUES ('c7', '2801 S KING DRIVE, APT 1017', 'Chicago', 'IL', '60616');
INSERT INTO `CustomerAddress` VALUES ('c1', '108 N State St', 'Denver', 'CO', '27837');
INSERT INTO `CustomerAddress` VALUES ('c8', '108 N Madison Ave', 'Hollywood', 'CA', '91278');
INSERT INTO `CustomerAddress` VALUES ('c1', '2801 S KING DRIVE, APT 1017', 'Chicago', 'IL', '60616');
INSERT INTO `CustomerAddress` VALUES ('c10', '2801 S KING DRIVE, APT 1017', 'Chicago', 'IL', '60616');
INSERT INTO `CustomerAddress` VALUES ('c1', '108 N State St', 'Denver', 'CO', '27837');
INSERT INTO `CustomerAddress` VALUES ('sa1', '10 S HongK St', 'Hollywood', 'CA', '98388');
INSERT INTO `CustomerAddress` VALUES ('c2', '181 S Park St', 'Syracuse', 'NY', '57298');
INSERT INTO `CustomerAddress` VALUES ('c4', '5118 S Lake Ave', 'Syracuse', 'NY', '51028');
INSERT INTO `CustomerAddress` VALUES ('c1', 'aesfdg', 'CHICAGO', 'ILLINOIS', 'asdf');
INSERT INTO `CustomerAddress` VALUES ('c1', '2801 S KING DRIVE', 'Denver', 'UT', '29087');
INSERT INTO `CustomerAddress` VALUES ('c1', '2801 S KING DRIVE, APT 1017', 'Chicago', 'IL', '60616');
INSERT INTO `CustomerAddress` VALUES ('c1', '2801 S KING DRIVE, APT 1017', 'Chicago', 'IL', '60616');
INSERT INTO `CustomerAddress` VALUES ('c1', '2801 S KING DRIVE, APT 1017', 'Chicago', 'IL', '60616');
INSERT INTO `CustomerAddress` VALUES ('c2', '2801 S KING DRIVE', 'Chicago', 'IL', '60616');
INSERT INTO `CustomerAddress` VALUES ('c3', '2801 S KING DRIVE', 'Chicago', 'IL', '60616');
INSERT INTO `CustomerAddress` VALUES ('c4', '2801 S KING DRIVE', 'Chicago', 'IL', '60616');
INSERT INTO `CustomerAddress` VALUES ('c4', '2801 S KING DRIVE, APT 1017', 'Chicago', 'IL', '60616');
INSERT INTO `CustomerAddress` VALUES ('c4', '2801 S KING DRIVE', 'Chicago', 'IL', '60616');
INSERT INTO `CustomerAddress` VALUES ('c4', '108 N Madison Ave', 'Hollywood', 'CA', '91278');
INSERT INTO `CustomerAddress` VALUES ('c4', '1101 S Canal St', 'Denver', 'CO', '21076');
INSERT INTO `CustomerAddress` VALUES ('c4', '20 W Fulton St', 'Hollywood', 'CA', '95273');
INSERT INTO `CustomerAddress` VALUES ('c4', '2801 S KING DRIVE, APT 1017', 'Chicago', 'IL', '60616');
INSERT INTO `CustomerAddress` VALUES ('c4', '2801 S KING DRIVE', 'Chicago', 'IL', '60616');
INSERT INTO `CustomerAddress` VALUES ('c4', '2801 S KING DRIVE', 'Chicago', 'IL', '60616');
INSERT INTO `CustomerAddress` VALUES ('c4', '2801 S KING DRIVE', 'Chicago', 'IL', '60616');
INSERT INTO `CustomerAddress` VALUES ('c4', '1001 W Webster Ave', 'Chicago', 'IL', '60625');
INSERT INTO `CustomerAddress` VALUES ('c4', '20 W Fulton St', 'Hollywood', 'CA', '95273');
INSERT INTO `CustomerAddress` VALUES ('c4', 'sdkjfhufwqe', 'Denver', 'CO', '21076');
INSERT INTO `CustomerAddress` VALUES ('c4', 'sdkjfhufwqe', 'Denver', 'CO', '21076');
INSERT INTO `CustomerAddress` VALUES ('c2', 'qwoieur', 'nvcmkn', 'wuehr', '60608');
INSERT INTO `CustomerAddress` VALUES ('c2', 'aesfdg', 'CHICAGO', 'ILLINOIS', '60608');
INSERT INTO `CustomerAddress` VALUES ('c2', 'qwoieur', 'nvcmkn', 'wuehr', '60608');
INSERT INTO `CustomerAddress` VALUES ('c2', 'qwoieur', 'nvcmkn', 'wuehr', '60608');
INSERT INTO `CustomerAddress` VALUES ('c2', 'qwoieur', 'nvcmkn', 'wuehr', '60608');
INSERT INTO `CustomerAddress` VALUES ('c2', '20 W Fulton St', 'Hollywood', 'CA', '95273');
INSERT INTO `CustomerAddress` VALUES ('c2', 'qwoieur', 'nvcmkn', 'wuehr', '60608');
INSERT INTO `CustomerAddress` VALUES ('c3', '20 W Fulton St', 'Hollywood', 'CA', '95273');
INSERT INTO `CustomerAddress` VALUES ('c3', '20 W Fulton St', 'Hollywood', 'CA', '95273');
INSERT INTO `CustomerAddress` VALUES ('c3', '20 W Fulton St', 'Hollywood', 'CA', '95273');
INSERT INTO `CustomerAddress` VALUES ('c3', '108 N Madison Ave', 'Hollywood', 'CA', '91278');
INSERT INTO `CustomerAddress` VALUES ('c1', '28 S Madison Ave', 'Denver', 'CO', '21076');
INSERT INTO `CustomerAddress` VALUES ('c1', '28 S Madison Ave', 'Denver', 'CO', '21076');
INSERT INTO `CustomerAddress` VALUES ('c1', '108 N Madison Ave', 'Hollywood', 'CA', '91278');
INSERT INTO `CustomerAddress` VALUES ('c5', '2801 S KING DRIVE', 'Denver', 'UT', '29087');
INSERT INTO `CustomerAddress` VALUES ('c5', '2801 S KING DRIVE', 'Denver', 'UT', '29087');
INSERT INTO `CustomerAddress` VALUES ('c5', '2801 S KING DRIVE', 'Denver', 'UT', '29088');
INSERT INTO `CustomerAddress` VALUES ('c7', '108 N State St', 'Denver', 'CO', '27837');
INSERT INTO `CustomerAddress` VALUES ('c1', '2801 S KING DRIVE', 'Chicago', 'IL', '60616');
INSERT INTO `CustomerAddress` VALUES ('c1', '2801 S KING DRIVE', 'Chicago', 'IL', '60616');
INSERT INTO `CustomerAddress` VALUES ('c1', '2801 S KING DRIVE', 'Chicago', 'IL', '60616');
INSERT INTO `CustomerAddress` VALUES ('c1', '2801 S KING DRIVE', 'Chicago', 'IL', '60616');
INSERT INTO `CustomerAddress` VALUES ('c1', '2801 S KING DRIVE', 'Chicago', 'IL', '60616');
INSERT INTO `CustomerAddress` VALUES ('Monica', '20 W Fulton St', 'Hollywood', 'CA', '95273');
INSERT INTO `CustomerAddress` VALUES ('Monica', '20 W Fulton St', 'Hollywood', 'CA', '95273');
INSERT INTO `CustomerAddress` VALUES ('Monica', '20 W Fulton St', 'Hollywood', 'CA', '95273');
INSERT INTO `CustomerAddress` VALUES ('Monica', '20 W Fulton St', 'Hollywood', 'CA', '95273');
INSERT INTO `CustomerAddress` VALUES ('Ben', '1001 W Webster Ave', 'Chicago', 'IL', '60625');
INSERT INTO `CustomerAddress` VALUES ('Ben', '1001 W Webster Ave', 'Chicago', 'IL', '60625');
INSERT INTO `CustomerAddress` VALUES ('Ben', '1001 W Webster Ave', 'Chicago', 'IL', '60625');
INSERT INTO `CustomerAddress` VALUES ('Ben', '1001 W Webster Ave', 'Chicago', 'IL', '60625');
INSERT INTO `CustomerAddress` VALUES ('Jerry', '203 N LaSalle St', 'Chicago', 'IL', '60608');
INSERT INTO `CustomerAddress` VALUES ('Jerry', '203 N LaSalle St', 'Chicago', 'IL', '60608');
INSERT INTO `CustomerAddress` VALUES ('Jerry', '203 N LaSalle St', 'Chicago', 'IL', '60608');
INSERT INTO `CustomerAddress` VALUES ('c1', '1001 W Webster Ave', 'Chicago', 'IL', '60625');
INSERT INTO `CustomerAddress` VALUES ('c1', '10 S HongK St', 'Hollywood', 'CA', '98388');
INSERT INTO `CustomerAddress` VALUES ('c1', '108 N State St', 'Denver', 'CO', '27837');
INSERT INTO `CustomerAddress` VALUES ('c1', '108 N State St', 'Denver', 'CO', '27837');
COMMIT;

SET FOREIGN_KEY_CHECKS = 1;
