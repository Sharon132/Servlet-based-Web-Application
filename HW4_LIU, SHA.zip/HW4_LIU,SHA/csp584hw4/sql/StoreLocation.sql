/*
 Navicat Premium Data Transfer

 Source Server         : local_mysql
 Source Server Type    : MySQL
 Source Server Version : 80021
 Source Host           : localhost:3306
 Source Schema         : csp584hw2

 Target Server Type    : MySQL
 Target Server Version : 80021
 File Encoding         : 65001

 Date: 15/11/2020 05:50:21
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for StoreLocation
-- ----------------------------
DROP TABLE IF EXISTS `StoreLocation`;
CREATE TABLE `StoreLocation` (
  `StoreID` varchar(20) NOT NULL,
  `street` varchar(100) DEFAULT NULL,
  `city` varchar(20) DEFAULT NULL,
  `state` varchar(20) DEFAULT NULL,
  `zipCode` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`StoreID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ----------------------------
-- Records of StoreLocation
-- ----------------------------
BEGIN;
INSERT INTO `StoreLocation` VALUES ('Canal', '1101 S Canal St', 'Denver', 'CO', '21076');
INSERT INTO `StoreLocation` VALUES ('Clark', '2728 N Clark St', 'Denver', 'CO', '29478');
INSERT INTO `StoreLocation` VALUES ('Dearborn', '200 N Dearborn St', 'Denver', 'CO', '20987');
INSERT INTO `StoreLocation` VALUES ('Fulton', '20 W Fulton St', 'Hollywood', 'CA', '95273');
INSERT INTO `StoreLocation` VALUES ('Halsted', '750 S Halsted St', 'Chicago', 'IL', '60616');
INSERT INTO `StoreLocation` VALUES ('Hongk', '10 S HongK St', 'Hollywood', 'CA', '98388');
INSERT INTO `StoreLocation` VALUES ('Lake', '5118 S Lake Ave', 'Syracuse', 'NY', '51028');
INSERT INTO `StoreLocation` VALUES ('LaSalle', '203 N LaSalle St', 'Chicago', 'IL', '60608');
INSERT INTO `StoreLocation` VALUES ('Madison', '108 N Madison Ave', 'Hollywood', 'CA', '91278');
INSERT INTO `StoreLocation` VALUES ('Park', '181 S Park St', 'Syracuse', 'NY', '57298');
INSERT INTO `StoreLocation` VALUES ('Stated', '108 N State St', 'Denver', 'CO', '27837');
INSERT INTO `StoreLocation` VALUES ('Webster', '1001 W Webster Ave', 'Chicago', 'IL', '60625');
COMMIT;

SET FOREIGN_KEY_CHECKS = 1;
