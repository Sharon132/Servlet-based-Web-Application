/*
 Navicat Premium Data Transfer

 Source Server         : local_mysql
 Source Server Type    : MySQL
 Source Server Version : 80021
 Source Host           : localhost:3306
 Source Schema         : csp584hw2

 Target Server Type    : MySQL
 Target Server Version : 80021
 File Encoding         : 65001

 Date: 15/11/2020 05:49:58
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for Productdetails
-- ----------------------------
DROP TABLE IF EXISTS `Productdetails`;
CREATE TABLE `Productdetails` (
  `ProductType` varchar(20) DEFAULT NULL,
  `Id` varchar(20) NOT NULL,
  `productName` varchar(40) DEFAULT NULL,
  `productPrice` double(10,2) DEFAULT NULL,
  `productImage` varchar(40) DEFAULT NULL,
  `productManufacturer` varchar(40) DEFAULT NULL,
  `productCondition` varchar(40) DEFAULT NULL,
  `productDiscount` double(10,2) DEFAULT NULL,
  `inventory` int DEFAULT NULL,
  `manufacturerRebates` double(255,0) DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ----------------------------
-- Records of Productdetails
-- ----------------------------
BEGIN;
INSERT INTO `Productdetails` VALUES ('Accessory', '11 ScreenProt', '11 ScreenProt', 15.00, 'acc_11ScreenP.jpg', 'Apple', 'New', 0.99, 466, 19);
INSERT INTO `Productdetails` VALUES ('Accessory', '11Pro Case', '11Pro Case', 20.00, 'acc_11ProCase.jpg', 'Apple', 'New', 0.00, 992, 17);
INSERT INTO `Productdetails` VALUES ('Laptop', '15.6HD', '15.6HD', 799.00, 'laptop_hp_15.6HD.jpg', 'HP', 'New', 15.00, 763, 6);
INSERT INTO `Productdetails` VALUES ('Laptop', '2019', '2019', 699.00, 'laptop_hp_2019.jpg', 'HP', 'New', 103.10, 439, 3);
INSERT INTO `Productdetails` VALUES ('Laptop', '2020', '2020', 749.00, 'laptop_hp_2020.jpg', 'HP', 'New', 10.00, 707, 16);
INSERT INTO `Productdetails` VALUES ('SoundSystem', '3.1 Channel', '3.1 Channel', 856.00, 'sound_dt_3.1 Channel.jpg', 'DefinitiveTechnology', 'New', 80.00, 618, 11);
INSERT INTO `Productdetails` VALUES ('VoiceAssistant', '3rd', '3rd', 49.99, 'voiceA_Alexa_3rd.jpg', 'Amazon', 'New', 3.00, 571, 6);
INSERT INTO `Productdetails` VALUES ('TV', '40S325', '40S325', 398.00, 'tv_TCL1080p.jpg', 'TCL', 'New', 100.00, 599, 20);
INSERT INTO `Productdetails` VALUES ('TV', '49NANO85UNA', '49NANO85UNA', 596.99, 'tv_LG1080p.jpg', 'LG', 'New', 12.00, 885, 0);
INSERT INTO `Productdetails` VALUES ('TV', '5-Series', '5-Series', 449.99, 'tv_TCL720p.jpg', 'TCL', 'New', 10.00, 427, 1);
INSERT INTO `Productdetails` VALUES ('SoundSystem', '5.1 set', '5.1 set', 480.07, 'sound_bose_5.1 set.jpg', 'Bose', 'New', 40.00, 882, 5);
INSERT INTO `Productdetails` VALUES ('TV', '50LF621U21', '50LF621U21', 429.99, 'tv_TCL4k.jpg', 'TCL', 'New', 50.00, 927, 2);
INSERT INTO `Productdetails` VALUES ('Phone', 'A10', 'A10', 168.99, 'phone_samsung_a10.jpg', 'Samsung', 'New', 19.00, 989, 18);
INSERT INTO `Productdetails` VALUES ('Phone', 'A20', 'A20', 453.50, 'phone_samsung_a20.jpg', 'Samsung', 'Used', 50.00, 566, 2);
INSERT INTO `Productdetails` VALUES ('Phone', 'A50', 'A50', 349.98, 'phone_samsung_a50.jpg', 'Samsung', 'New', 20.00, 665, 16);
INSERT INTO `Productdetails` VALUES ('Laptop', 'A6-9220e', 'A6-9220e', 749.00, 'laptop_dell_A6-9220e.jpg', 'Dell', 'New', 50.00, 626, 14);
INSERT INTO `Productdetails` VALUES ('Phone', 'A70', 'A70', 334.62, 'phone_samsung_a70.jpg', 'Samsung', 'New', 20.00, 735, 3);
INSERT INTO `Productdetails` VALUES ('Accessory', 'Adapter', 'Adapter', 120.00, 'acc_adapter.jpg', 'Apple', 'New', 0.00, 797, 13);
INSERT INTO `Productdetails` VALUES ('Accessory', 'AirpodsPro', 'AirpodsPro', 249.00, 'acc_airPro.jpg', 'Apple', 'New', 10.00, 782, 15);
INSERT INTO `Productdetails` VALUES ('SoundSystem', 'BP-9020', 'BP-9020', 699.00, 'sound_df_BP-9020.jpg', 'DefinitiveTechnology', 'New', 15.00, 520, 14);
INSERT INTO `Productdetails` VALUES ('TV', 'C9', 'C9', 249.99, 'tv_LG4k.jpg', 'LG', 'New', 10.00, 453, 6);
INSERT INTO `Productdetails` VALUES ('PetTracker', 'CUBE Bluetooth', 'CUBE Bluetooth', 24.95, 'pet_cube_Bluetooth.jpg', 'Cube', 'New', 2.99, 906, 11);
INSERT INTO `Productdetails` VALUES ('PetTracker', 'DYNOTAG QR', 'DYNOTAG QR', 19.95, 'pet_dynotag_QR.jpg', 'Dynotag', 'New', 0.99, 972, 16);
INSERT INTO `Productdetails` VALUES ('Accessory', 'Earpods3.5', 'Earpods3.5', 29.00, 'acc_earpods3.5.jpg', 'Apple', 'New', 3.00, 544, 3);
INSERT INTO `Productdetails` VALUES ('FitnessWatch', 'FITBIT Blaze', 'FITBIT Blaze', 229.95, 'fitness_fitbit_blaze.jpg', 'Fitbit', 'New', 10.00, 603, 11);
INSERT INTO `Productdetails` VALUES ('FitnessWatch', 'FITBIT Versa2', 'FITBIT Versa2', 179.00, 'fitness_fitbit_versa2.jpg', 'Fitbit', 'New', 15.00, 984, 4);
INSERT INTO `Productdetails` VALUES ('Laptop', 'Flex14', 'M4800', 658.00, 'laptop_L_Flex14.jpg', 'Lenovo', 'New', 18.00, 912, 11);
INSERT INTO `Productdetails` VALUES ('Laptop', 'G5', 'G5', 1249.00, 'laptop_dell_g5.jpg', 'Dell', 'New', 100.00, 608, 20);
INSERT INTO `Productdetails` VALUES ('FitnessWatch', 'GARMIN F235', 'GARMIN F235', 169.99, 'fitness_garmin_F235.jpg', 'Garmin', 'New', 12.99, 504, 6);
INSERT INTO `Productdetails` VALUES ('FitnessWatch', 'GARMIN F35', 'GARMIN F35', 239.00, 'fitness_garmin_F35.jpg', 'Garmin', 'New', 5.00, 351, 3);
INSERT INTO `Productdetails` VALUES ('FitnessWatch', 'GARMIN V3', 'GARMIN V3', 70.00, 'fitness_garmin_v3.jpg', 'Garmin', 'Used', 0.00, 200, 0);
INSERT INTO `Productdetails` VALUES ('VoiceAssistant', 'Home Max', 'Home Max', 299.99, 'voiceA_google_Home_max.jpg', 'Google', 'New', 14.00, 896, 13);
INSERT INTO `Productdetails` VALUES ('VoiceAssistant', 'HomePod', 'HomePod', 299.99, 'voiceA_Apple_HomePod.jpg', 'Apple', 'New', 0.00, 768, 6);
INSERT INTO `Productdetails` VALUES ('Phone', 'Honor8x', 'Honor8x', 189.99, 'phone_huawei_honor8x.jpg', 'Huawei', 'New', 17.00, 753, 11);
INSERT INTO `Productdetails` VALUES ('VirtualReality', 'HTC Vive', 'HTC Vive', 899.00, 'virtual_HTC_vive.jpg', 'HTC', 'New', 0.00, 345, 19);
INSERT INTO `Productdetails` VALUES ('Laptop', 'Ideapad3', 'Ideapad3', 549.00, 'laptop_L_Ideapad3.jpg', 'Lenovo', 'New', 39.00, 463, 17);
INSERT INTO `Productdetails` VALUES ('Phone', 'iphone 11', 'iphone 11', 699.00, 'phone_iphone_11.jpg', 'Apple', 'New', 0.00, 858, 9);
INSERT INTO `Productdetails` VALUES ('Phone', 'iphone 6s', 'iphone 6s', 399.99, 'phone_iphone_6s.jpg', 'Apple', 'Used', 25.00, 698, 16);
INSERT INTO `Productdetails` VALUES ('Phone', 'iphone pro11', 'iphone pro11', 999.00, 'phone_iphone_pro11.jpg', 'Apple', 'New', 0.00, 518, 10);
INSERT INTO `Productdetails` VALUES ('Phone', 'iphone xr', 'iphone xr', 599.00, 'phone_iphone_xr.jpg', 'Apple', 'New', 0.00, 698, 5);
INSERT INTO `Productdetails` VALUES ('Accessory', 'Keyboard', 'Keyboard', 125.00, 'acc_huawei_keyb.png', 'Huawei', 'New', 20.00, 937, 16);
INSERT INTO `Productdetails` VALUES ('Laptop', 'Latest Mac15', 'Latest Mac15', 2549.00, 'laptop_apple_latest_mac15.jpg', 'Apple', 'New', 0.00, 990, 3);
INSERT INTO `Productdetails` VALUES ('Laptop', 'M4800', 'M4800', 695.97, 'laptop_dell_m4800.jpg', 'Dell', 'New', 35.00, 540, 10);
INSERT INTO `Productdetails` VALUES ('Laptop', 'Mac13', 'Mac13', 1464.00, 'laptop_apple_mac13.jpg', 'Apple', 'New', 128.00, 529, 19);
INSERT INTO `Productdetails` VALUES ('Laptop', 'Mac15', 'Mac15', 1343.78, 'laptop_apple_mac15.jpg', 'Apple', 'Used', 400.00, 625, 2);
INSERT INTO `Productdetails` VALUES ('Phone', 'Mate20', 'Mate20', 779.99, 'phone_huawei_mate20.jpg', 'Huawei', 'New', 20.00, 541, 16);
INSERT INTO `Productdetails` VALUES ('Accessory', 'MobilePower', 'MobilePower', 100.00, 'acc_huawei_mobilePower.png', 'Huawei', 'New', 15.00, 431, 11);
INSERT INTO `Productdetails` VALUES ('Accessory', 'Mouse', 'Mouse', 89.99, 'acc_huawei_mouse.png', 'Huawei', 'New', 0.00, 731, 9);
INSERT INTO `Productdetails` VALUES ('VoiceAssistant', 'Nest Mini', 'Nest Mini', 39.99, 'voiceA_google_nest_mini.jpg', 'Google', 'New', 2.99, 765, 13);
INSERT INTO `Productdetails` VALUES ('Phone', 'Note 9s', 'Note 9s', 210.93, 'phone_xiaomi_Note 9s.jpg', 'Xiaomi', 'New', 8.00, 630, 16);
INSERT INTO `Productdetails` VALUES ('Phone', 'Note8', 'Note8', 172.99, 'phone_xiaomi_Note8.jpg', 'Xiaomi', 'New', 5.00, 458, 0);
INSERT INTO `Productdetails` VALUES ('VirtualReality', 'OCULUS Quest2', 'OCULUS Quest2', 299.00, 'virtual_oculus_quest2.jpg', 'Oculus', 'New', 10.00, 599, 16);
INSERT INTO `Productdetails` VALUES ('VirtualReality', 'OCULUS Rift_S', 'OCULUS Rift_S', 399.00, 'virtual_oculus_rift_s.jpg', 'Oculus', 'New', 16.00, 622, 19);
INSERT INTO `Productdetails` VALUES ('TV', 'OLED48CXPUB', 'OLED48CXPUB', 1496.99, 'tv_LG720p.jpg', 'LG', 'New', 26.00, 915, 5);
INSERT INTO `Productdetails` VALUES ('Phone', 'P30', 'P30', 172.00, 'phone_huawei_p30.jpg', 'Huawei', 'New', 28.05, 506, 8);
INSERT INTO `Productdetails` VALUES ('Accessory', 'P30_ScreenPro', 'P30_ScreenPro', 89.99, 'acc_p30_ScreenPro.jpg', 'Huawei', 'New', 18.00, 589, 6);
INSERT INTO `Productdetails` VALUES ('Headphone', 'PANASONIC 101', 'PANASONIC 101', 29.95, 'headphone_panasonic_101.jpg', 'Panasonic', 'New', 8.00, 427, 8);
INSERT INTO `Productdetails` VALUES ('Headphone', 'PANASONIC 161', 'PANASONIC 161', 159.00, 'headphone_panasonic_161.jpg', 'Panasonic', 'New', 8.00, 528, 5);
INSERT INTO `Productdetails` VALUES ('Headphone', 'PANASONIC 21', 'PANASONIC 21', 63.00, 'headphone_panasonic_21.jpg', 'Panasonic', 'New', 10.00, 566, 20);
INSERT INTO `Productdetails` VALUES ('VirtualReality', 'PANSONITE Anti', 'PANSONITE Anti', 52.99, 'virtual_pansonite_Anti-Blue-Light.jpg', 'Pansonite', 'New', 10.00, 551, 15);
INSERT INTO `Productdetails` VALUES ('VirtualReality', 'PANSONITE UL', 'PANSONITE UL', 13.99, 'virtual_pansonite_UL.jpg', 'Pansonite', 'New', 0.00, 658, 16);
INSERT INTO `Productdetails` VALUES ('Accessory', 'Pencil', 'Pencil', 30.00, 'acc_huawei_pencil.png', 'Huawei', 'New', 5.00, 638, 14);
INSERT INTO `Productdetails` VALUES ('PetTracker', 'PetFon GPS', 'PetFon GPS', 189.99, 'pet_petFon_GPS.jpg', 'PetFon', 'New', 10.00, 361, 10);
INSERT INTO `Productdetails` VALUES ('TV', 'QB65R', 'QB65R', 1125.00, 'tv_samsung8k.jpg', 'Samsung', 'New', 123.80, 814, 1);
INSERT INTO `Productdetails` VALUES ('TV', 'QN65Q7FN', 'QN65Q7FN', 124.00, 'tv_samsung_QN65Q7FN.jpg', 'Samsung', 'New', 1.00, 559, 5);
INSERT INTO `Productdetails` VALUES ('Accessory', 'QuickCharger', 'QuickCharger', 89.99, 'acc_huawei_quickCharger.png', 'Huawei', 'New', 40.00, 554, 2);
INSERT INTO `Productdetails` VALUES ('Phone', 'S9', 'S9', 367.00, 'phone_samsung_s9.jpg', 'Samsung', 'Used', 90.00, 693, 15);
INSERT INTO `Productdetails` VALUES ('SmartWatch', 'SAMSUNG Galaxy', 'SAMSUNG Galaxy', 562.00, 'smart_samsung_Galaxy.jpg', 'Samsung', 'New', 24.00, 381, 10);
INSERT INTO `Productdetails` VALUES ('SmartWatch', 'SAMSUNG R800', 'SAMSUNG R800', 275.00, 'smart_samsung_SM-R800NZSAXAR.jpg', 'Samsung', 'New', 15.00, 123, 5);
INSERT INTO `Productdetails` VALUES ('SmartWatch', 'SAMSUNG S3', 'SAMSUNG S3', 239.00, 'smart_samsung_s3.jpg', 'Samsung', 'New', 40.00, 804, 7);
INSERT INTO `Productdetails` VALUES ('Accessory', 'SelfieStick', 'SelfieStick', 89.99, 'acc_huawei_selfieSti.jpg', 'Huawei', 'New', 15.00, 942, 13);
INSERT INTO `Productdetails` VALUES ('VoiceAssistant', 'Smart Alarm', 'Smart Alarm', 89.99, 'voiceA_Alexa_smart_alarm.jpg', 'Amazon', 'New', 10.00, 700, 4);
INSERT INTO `Productdetails` VALUES ('SoundSystem', 'solo 5', 'solo 5', 199.00, 'sound_bose_solo 5.jpg', 'Bose', 'New', 10.00, 872, 0);
INSERT INTO `Productdetails` VALUES ('Headphone', 'SONY 310', 'SONY 310', 59.95, 'headphone_sony_310.jpg', 'Sony', 'New', 12.99, 661, 10);
INSERT INTO `Productdetails` VALUES ('SmartWatch', 'SONY Dial3', 'SONY Dial3', 25.00, 'smart_sony_dial3.jpg', 'Sony', 'Used', 0.00, 100, 6);
INSERT INTO `Productdetails` VALUES ('SmartWatch', 'SONY V1', 'SONY V1', 99.99, 'smart_sony_v1.jpg', 'Sony', 'New', 25.00, 892, 11);
INSERT INTO `Productdetails` VALUES ('Headphone', 'SONY ZX', 'SONY ZX', 9.99, 'headphone_sony_zx.jpg', 'Sony', 'New', 0.00, 874, 1);
INSERT INTO `Productdetails` VALUES ('TV', 'ST65Q6FN', 'ST65Q6FN', 612.30, 'tv_samsung_QN65Q6FN.jpg', 'Samsung', 'New', 13.00, 696, 16);
INSERT INTO `Productdetails` VALUES ('TV', 'TU-8000', 'TU-8000', 497.99, 'tv_samsung4k.jpg', 'Samsung', 'New', 10.00, 460, 13);
INSERT INTO `Productdetails` VALUES ('TV', 'UN32N', 'UN32N', 236.30, 'tv_samsung1080p.jpg', 'Samsung', 'New', 20.00, 410, 17);
INSERT INTO `Productdetails` VALUES ('TV', 'UN43NU7100F', 'UN43NU7100F', 351.40, 'tv_samsung_UN43NU7100FXZA.jpg', 'Samsung', 'New', 14.50, 869, 6);
INSERT INTO `Productdetails` VALUES ('TV', 'UN55RU71', 'UN55RU71', 982.00, 'tv_samsung_UN55RU7100FXZA.jpg', 'Samsung', 'New', 100.00, 919, 20);
INSERT INTO `Productdetails` VALUES ('SoundSystem', 'wave', 'wave', 408.00, 'sound_bose_wave.jpg', 'Bose', 'New', 13.00, 988, 19);
INSERT INTO `Productdetails` VALUES ('PetTracker', 'WHISTLE Blue_Combo', 'WHISTLE Blue_Combo', 129.90, 'pet_whistle_blue_combo.jpg', 'Whistle', 'New', 1.97, 584, 13);
INSERT INTO `Productdetails` VALUES ('PetTracker', 'WHISTLE Go_Explore', 'WHISTLE Go_Explore', 29.95, 'pet_whistle_go explore.jpg', 'Whistle', 'New', 1.00, 261, 0);
INSERT INTO `Productdetails` VALUES ('Accessory', 'WirelessCharger', 'WirelessCharger', 259.00, 'acc_huawei_wirelessCharger.png', 'Huawei', 'New', 40.00, 758, 11);
INSERT INTO `Productdetails` VALUES ('TV', 'X800H', 'X800H', 598.00, 'tv_sony-X800H.jpg', 'Sony', 'New', 50.00, 435, 18);
INSERT INTO `Productdetails` VALUES ('TV', 'XBR-49X800G', 'XBR-49X800G', 696.92, 'tv_sony_XBR-49X800G.jpg', 'Sony', 'New', 10.00, 705, 14);
INSERT INTO `Productdetails` VALUES ('TV', 'XBR-65A8H', 'XBR-65A8H', 2498.00, 'tv_sony_XBR-65A8H.jpg', 'Sony', 'New', 108.40, 618, 18);
INSERT INTO `Productdetails` VALUES ('Phone', 'Y9', 'Y9', 571.00, 'phone_huawei_y9.jpg', 'Huawei', 'Used', 61.00, 574, 5);
INSERT INTO `Productdetails` VALUES ('Laptop', 'Yoga C740-14', 'Yoga C740-14', 688.88, 'laptop_L_Yoga_C740-14.jpg', 'Lenovo', 'New', 111.11, 618, 13);
INSERT INTO `Productdetails` VALUES ('SoundSystem', 'Z323', 'Z323', 189.99, 'ss_LogitechZ323.jpg', 'Logitech', 'New', 20.00, 970, 7);
INSERT INTO `Productdetails` VALUES ('SoundSystem', 'Z506', 'AZ506', 39.99, 'ss_LogitechZ506.jpg', 'Logitech', 'Used', 0.00, 795, 20);
INSERT INTO `Productdetails` VALUES ('SoundSystem', 'Z625', 'Z625', 259.99, 'ss_LogitechZ625.jpg', 'Logitech', 'New', 2.00, 667, 18);
INSERT INTO `Productdetails` VALUES ('SoundSystem', 'Z906', 'Z906', 129.99, 'ss_LogitechZ906.jpg', 'Logitech', 'New', 11.00, 549, 7);
COMMIT;

SET FOREIGN_KEY_CHECKS = 1;
