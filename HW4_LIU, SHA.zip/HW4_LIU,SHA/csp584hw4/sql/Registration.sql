/*
 Navicat Premium Data Transfer

 Source Server         : local_mysql
 Source Server Type    : MySQL
 Source Server Version : 80021
 Source Host           : localhost:3306
 Source Schema         : csp584hw2

 Target Server Type    : MySQL
 Target Server Version : 80021
 File Encoding         : 65001

 Date: 15/11/2020 05:50:09
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for Registration
-- ----------------------------
DROP TABLE IF EXISTS `Registration`;
CREATE TABLE `Registration` (
  `username` varchar(40) DEFAULT NULL,
  `password` varchar(40) DEFAULT NULL,
  `repassword` varchar(40) DEFAULT NULL,
  `usertype` varchar(40) DEFAULT NULL,
  `user_id` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ----------------------------
-- Records of Registration
-- ----------------------------
BEGIN;
INSERT INTO `Registration` VALUES ('c1', '123', '123', 'Customer', 1);
INSERT INTO `Registration` VALUES ('c2', '123', '123', 'Customer', 2);
INSERT INTO `Registration` VALUES ('c3', '123', '123', 'Customer', 3);
INSERT INTO `Registration` VALUES ('c4', '123', '123', 'Customer', 4);
INSERT INTO `Registration` VALUES ('c5', '123', '123', 'Customer', 5);
INSERT INTO `Registration` VALUES ('st1', '123', '123', 'StoreManager', 6);
INSERT INTO `Registration` VALUES ('sa1', '123', '123', 'Salesman', 7);
INSERT INTO `Registration` VALUES ('c6', '123', '123', 'Customer', 8);
INSERT INTO `Registration` VALUES ('liu', '123', '123', 'Customer', 9);
INSERT INTO `Registration` VALUES ('sa2', '123', '123', 'Salesman', 10);
INSERT INTO `Registration` VALUES ('c7', '123', '123', 'Customer', 11);
INSERT INTO `Registration` VALUES ('c8', '123', '123', 'Customer', 12);
INSERT INTO `Registration` VALUES ('Sha', '123', '123', 'Customer', 13);
INSERT INTO `Registration` VALUES ('c10', '123', '123', 'Customer', 14);
INSERT INTO `Registration` VALUES ('shaliu', '123', '123', 'Customer', 15);
INSERT INTO `Registration` VALUES ('c9', '123', '123', 'Customer', 17);
INSERT INTO `Registration` VALUES ('xueluping', '123', '123', 'Customer', 18);
INSERT INTO `Registration` VALUES ('xue', '123', '123', 'Customer', 19);
INSERT INTO `Registration` VALUES ('12345', '12345', '12345', 'Customer', 20);
INSERT INTO `Registration` VALUES ('xlpliusha', '123', '123', 'Customer', 21);
INSERT INTO `Registration` VALUES ('123456', '123456', '123456', 'Customer', 22);
INSERT INTO `Registration` VALUES ('liusha123', '123', '123', 'Customer', 23);
INSERT INTO `Registration` VALUES ('xlp123', '123', '123', 'Customer', 24);
INSERT INTO `Registration` VALUES ('yyy', '555', '555', 'Customer', 25);
INSERT INTO `Registration` VALUES ('123', '123', '123', 'Customer', 26);
INSERT INTO `Registration` VALUES ('Monica', '123', '123', 'Customer', 27);
INSERT INTO `Registration` VALUES ('Lili', '123', '123', 'Customer', 28);
INSERT INTO `Registration` VALUES ('Ben', '123', '123', 'Customer', 29);
INSERT INTO `Registration` VALUES ('Jerry', '123', '123', 'Customer', 30);
COMMIT;

SET FOREIGN_KEY_CHECKS = 1;
