/*
 Navicat Premium Data Transfer

 Source Server         : local_mysql
 Source Server Type    : MySQL
 Source Server Version : 80021
 Source Host           : localhost:3306
 Source Schema         : csp584hw2

 Target Server Type    : MySQL
 Target Server Version : 80021
 File Encoding         : 65001

 Date: 14/11/2020 10:21:28
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for Transactions
-- ----------------------------
DROP TABLE IF EXISTS `Transactions`;
CREATE TABLE `Transactions` (
  `Order_ID` int NOT NULL,
  `login_ID` varchar(40) DEFAULT NULL,
  `Customer_Name` varchar(40) DEFAULT NULL,
  `Customer_Age` int DEFAULT NULL,
  `Customer_Occupation` varchar(40) DEFAULT NULL,
  `Credit_card` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `Order_Date` date DEFAULT NULL,
  `Expected_Date` date DEFAULT NULL,
  `Actual_Date` date DEFAULT NULL,
  `Product_ID` varchar(40) DEFAULT NULL,
  `Product_Name` varchar(40) DEFAULT NULL,
  `Category` varchar(40) DEFAULT NULL,
  `Manufacturer` varchar(40) DEFAULT NULL,
  `Review_Rating` int DEFAULT NULL,
  `Delivery_Tracking_ID` varchar(40) DEFAULT NULL,
  `Delivery_Type` varchar(40) DEFAULT NULL,
  `Delivery_Zip` varchar(40) DEFAULT NULL,
  `Transactions_Status` varchar(40) DEFAULT NULL,
  `Order_Returned` varchar(40) DEFAULT NULL,
  `Delivery_on_Time` varchar(40) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ----------------------------
-- Records of Transactions
-- ----------------------------
BEGIN;
INSERT INTO `Transactions` VALUES (51505, 'c2', 'Judy', 19, 'Hair dresser', '3245-7192-8192', '2020-02-08', '2020-02-13', '2020-02-15', 'QuickCharger', 'QuickCharger', 'Accessory', 'Huawei', 5, 'c2', 'Home Delivery', '60608', 'Approved', 'No', 'No');
INSERT INTO `Transactions` VALUES (52736, 'c4', 'Norma', 18, 'Student', '6182-1829-9182', '2020-08-26', '2020-08-31', '2020-08-31', 'Ideapad3', 'Ideapad3', 'Laptop', 'Lenovo', 5, 'c4', 'Home Delivery', '60616', 'Approved', 'No', 'Yes');
INSERT INTO `Transactions` VALUES (53055, 'c4', 'Cloris', 25, 'Salesperson', '8291-9281-8291', '2020-04-11', '2020-04-16', '2020-04-16', 'XBR-65A8H', 'XBR-65A8H', 'TV', 'Sony', 2, 'c4', 'Store pickup', '21076', 'Disputed', 'Yes', 'Yes');
INSERT INTO `Transactions` VALUES (53256, 'c4', 'Smith', 56, 'CEO', '0974-3573-9736', '2020-05-25', '2020-05-30', '2020-05-30', 'iphone 11', 'iphone 11', 'Phone', 'Apple', 5, 'c4', 'Store pickup', '95273', 'Approved', 'No', 'Yes');
INSERT INTO `Transactions` VALUES (53447, 'c4', 'John', 10, 'Student', '7291-2918-8192', '2020-07-26', '2020-07-31', '2020-07-30', 'WHISTLE Blue_Combo', 'WHISTLE Blue_Combo', 'PetTracker', 'Whistle', 5, 'c4', 'Home Delivery', '60616', 'Approved', 'Yes', 'Yes');
INSERT INTO `Transactions` VALUES (54150, 'c4', 'Chandler', 30, 'Actor', '7291-9201-9023', '2020-10-28', '2020-11-02', '2020-11-01', 'Mouse', 'Mouse', 'Accessory', 'Huawei', 5, 'c4', 'Home Delivery', '60616', 'Approved', 'No', 'Yes');
INSERT INTO `Transactions` VALUES (54827, 'c4', 'Joey', 30, 'Dentist', '8291-9281-8291', '2020-01-03', '2020-01-08', '2020-01-08', 'SONY 310', 'SONY 310', 'Headphone', 'Sony', 5, 'c4', 'Home Delivery', '21076', 'Approved', 'No', 'Yes');
INSERT INTO `Transactions` VALUES (55006, 'c2', 'Sha', 24, 'Blogger', '7192-9217-8391', '2020-03-05', '2020-03-10', '2020-03-08', 'GARMIN V3', 'GARMIN V3', 'FitnessWatch', 'Garmin', 5, 'c2', 'Home Delivery', '60608', 'Approved', 'No', 'Yes');
INSERT INTO `Transactions` VALUES (55108, 'c2', 'Luping', 26, 'Programmer', '7921-8291-7219', '2020-06-29', '2020-07-04', '2020-07-06', 'M4800', 'M4800', 'Laptop', 'Lenovo', 1, 'c2', 'Home Delivery', '60608', 'Approved', 'No', 'No');
INSERT INTO `Transactions` VALUES (55206, 'c2', 'Yuhuan', 23, 'Accountant', '1231-8291-8301', '2020-04-20', '2020-04-25', '2020-04-23', 'Nest Mini', 'Nest Mini', 'VoiceAssistant', 'Google', 5, 'c2', 'Home Delivery', '60608', 'Disputed', 'No', 'Yes');
INSERT INTO `Transactions` VALUES (55505, 'c2', 'Judy', 19, 'Hair dresser', '3245-7192-8192', '2020-08-23', '2020-08-28', '2020-08-29', 'P30', 'P30', 'Phone', 'Huawei', 1, 'c2', 'Home Delivery', '60608', 'Approved', 'No', 'No');
INSERT INTO `Transactions` VALUES (55506, 'c2', 'Pheobe', 27, 'Massager', '7291-8291-7291', '2020-06-14', '2020-06-19', '2020-06-18', '5.1 set', '5.1 set', 'SoundSystem', 'Bose', 5, 'c2', 'Home Delivery', '60608', 'Approved', 'No', 'Yes');
INSERT INTO `Transactions` VALUES (55507, 'c2', 'Lao', 30, 'Auditor', '7281-7291-7281', '2020-09-01', '2020-09-06', '2020-09-07', 'Mac15', 'Mac15', 'Laptop', 'Apple', 2, 'c2', 'Store pickup', '95273', 'Approved', 'No', 'No');
INSERT INTO `Transactions` VALUES (55508, 'c2', 'Lao', 30, 'Auditor', '7281-7291-7281', '2020-08-13', '2020-08-18', '2020-08-19', 'AirpodsPro', 'AirpodsPro', 'Accessory', 'Apple', 3, 'c2', 'Store pickup', '95273', 'Approved', 'No', 'No');
INSERT INTO `Transactions` VALUES (55509, 'c2', 'Jashywa', 38, 'Designer', '7382-7392-1092', '2020-06-05', '2020-06-10', '2020-06-10', 'Z506', 'Z506', 'SoundSystem', 'Logitech', 4, 'c2', 'Home Delivery', '60608', 'Approved', 'No', 'Yes');
INSERT INTO `Transactions` VALUES (162726, 'c3', 'Rebecca', 21, 'Salesperson', '2819-2791-8921', '2020-05-13', '2020-05-18', '2020-05-17', 'GARMIN V3', 'GARMIN V3', 'FitnessWatch', 'Garmin', 5, 'c3', 'Store pickup', '95273', 'Disputed', 'Yes', 'Yes');
INSERT INTO `Transactions` VALUES (162904, 'c3', 'Rebecca', 21, 'Salesperson', '7391-2389-3891', '2020-04-20', '2020-04-25', '2020-04-23', 'SONY Dial3', 'SONY Dial3', 'SmartWatch', 'Sony', 2, 'c3', 'Store pickup', '95273', 'Approved', 'Yes', 'Yes');
INSERT INTO `Transactions` VALUES (163000, 'c3', 'Rebecca', 21, 'Student', '7312-2921-7391', '2020-04-04', '2020-04-09', '2020-04-11', 'WHISTLE Go_Explore', 'WHISTLE Go_Explore', 'PetTracker', 'Whistle', 5, 'c3', 'Store pickup', '95273', 'Approved', 'No', 'No');
INSERT INTO `Transactions` VALUES (163139, 'c3', 'Norma', 35, 'Teacher', '2628-3891-3719', '2020-05-13', '2020-05-18', '2020-05-16', 'AirpodsPro', 'AirpodsPro', 'Accessory', 'Apple', 2, 'c3', 'Store pickup', '91278', 'Disputed', 'No', 'Yes');
INSERT INTO `Transactions` VALUES (163356, 'c1', 'Lynn', 18, 'Architecture', '3721-3829-3891', '2020-01-27', '2020-02-01', '2020-01-30', '50LF621U21', '50LF621U21', 'TV', 'TCL', 1, 'c1', 'Home Delivery', '21076', 'Disputed', 'Yes', 'Yes');
INSERT INTO `Transactions` VALUES (163503, 'c1', 'Lynn', 18, 'Architecture', '7029-2891-7391', '2020-08-30', '2020-09-04', '2020-09-04', 'Latest Mac15', 'Latest Mac15', 'Laptop', 'Apple', 3, 'c1', 'Home Delivery', '21076', 'Approved', 'Yes', 'Yes');
INSERT INTO `Transactions` VALUES (163618, 'c1', 'Luping', 30, 'Electrical Engineer', '9201-2891-7381', '2020-02-01', '2020-02-06', '2020-02-07', 'X800H', 'X800H', 'TV', 'Sony', 5, 'c1', 'Store pickup', '91278', 'Approved', 'No', 'No');
INSERT INTO `Transactions` VALUES (163727, 'c5', 'Mike', 32, 'Electrical Engineer', '6281-9021-6720', '2020-04-17', '2020-04-22', '2020-04-22', 'Y9', 'Y9', 'Phone', 'Huawei', 5, 'c5', 'Home Delivery', '29087', 'Approved', 'No', 'Yes');
INSERT INTO `Transactions` VALUES (163728, 'c5', 'Mike', 32, 'Electrical Engineer', '6281-9021-6720', '2020-10-27', '2020-11-01', '2020-10-30', 'WirelessCharger', 'WirelessCharger', 'Accessory', 'Huawei', 5, 'c5', 'Home Delivery', '29087', 'Disputed', 'Yes', 'Yes');
INSERT INTO `Transactions` VALUES (164700, 'c5', 'Tom', 56, 'Professor', '9201-2791-7281', '2020-01-15', '2020-01-20', '2020-01-18', 'Y9', 'Y9', 'Phone', 'Huawei', 1, 'c5', 'Home Delivery', '29088', 'Approved', 'No', 'Yes');
INSERT INTO `Transactions` VALUES (164701, 'c5', 'Tom', 56, 'Professor', '9201-2791-7281', '2020-08-12', '2020-08-17', '2020-08-15', 'QuickCharger', 'QuickCharger', 'Accessory', 'Huawei', 3, 'c5', 'Home Delivery', '29087', 'Approved', 'Yes', 'Yes');
INSERT INTO `Transactions` VALUES (164919, 'c5', 'Lisa', 52, 'Business Woman', '8291-8291-3681', '2020-07-27', '2020-08-01', '2020-08-01', 'Latest Mac15', 'Latest Mac15', 'Laptop', 'Apple', 5, 'c5', 'Home Delivery', '29088', 'Disputed', 'Yes', 'Yes');
INSERT INTO `Transactions` VALUES (164920, 'c5', 'Lisa', 52, 'Business Woman', '8291-8291-3681', '2020-02-07', '2020-02-12', '2020-02-15', 'AirpodsPro', 'AirpodsPro', 'Accessory', 'Apple', 4, 'c5', 'Home Delivery', '29088', 'Approved', 'No', 'No');
INSERT INTO `Transactions` VALUES (165059, 'c11', 'Si', 23, 'Student', '9092-7291-8391', '2020-06-24', '2020-06-29', '2020-07-02', 'iphone xr', 'iphone xr', 'Phone', 'Apple', 5, 'c7', 'Store pickup', '27837', 'Approved', 'No', 'No');
INSERT INTO `Transactions` VALUES (165060, 'c11', 'Si', 23, 'Student', '9092-7291-8391', '2020-08-29', '2020-09-03', '2020-09-04', 'AirpodsPro', 'AirpodsPro', 'Accessory', 'Apple', 5, 'c7', 'Store pickup', '27837', 'Disputed', 'No', 'No');
INSERT INTO `Transactions` VALUES (165061, 'c4', 'Si', 23, 'Student', '9092-7291-8391', '2020-10-02', '2020-10-07', '2020-10-10', 'Earpods3.5', 'Earpods3.5', 'Accessory', 'Apple', 1, 'c7', 'Store pickup', '27837', 'Approved', 'No', 'No');
INSERT INTO `Transactions` VALUES (165062, 'c4', 'Cloris', 25, 'Salesperson', '7281-8291-3601', '2020-07-02', '2020-07-07', '2020-07-02', 'iphone 11', 'iphone 11', 'Phone', 'Apple', 1, 'c4', 'Home Delivery', '21076', 'Disputed', 'Yes', 'Yes');
INSERT INTO `Transactions` VALUES (163854, 'c1', 'Hjs Hsh', 18, 'Student', '6172-9012-8391', '2020-08-23', '2020-08-28', '2020-08-27', 'QN65Q7FN', 'QN65Q7FN', 'TV', 'Samsung', 5, 'c1', 'Home Delivery', '60616', 'Approved', 'No', 'Yes');
INSERT INTO `Transactions` VALUES (175132, 'c1', 'Norma', 21, 'Dentist', '7182-9201-7291', '2020-03-31', '2020-04-05', '2020-04-05', 'iphone 6s', 'iphone 6s', 'Phone', 'Apple', 1, 'c1', 'Home Delivery', '60616', 'Approved', 'No', 'Yes');
INSERT INTO `Transactions` VALUES (91634, 'Lili', 'Lili', 30, 'Accountant', '6271-8921-9201', '2020-07-17', '2020-07-22', '2020-07-21', 'X800H', 'X800H', 'TV', 'Sony', 4, '084408', 'Home Delivery', '60616', 'Approved', 'No', 'Yes');
INSERT INTO `Transactions` VALUES (91919, 'Lili', 'Lili', 30, 'Accountant', '8291-0001-8882', '2020-06-13', '2020-06-18', '2020-06-19', 'iphone 11', 'iphone 11', 'Phone', 'Apple', 5, '440023', 'Home Delivery', '60616', 'Approved', 'No', 'No');
INSERT INTO `Transactions` VALUES (92022, 'Lili', 'Lili', 30, 'Accountant', '0029-8291-7002', '2020-01-14', '2020-01-19', '2020-01-17', 'iphone pro11', 'iphone pro11', 'Phone', 'Apple', 3, '379995', 'Home Delivery', '60616', 'Approved', 'No', 'Yes');
INSERT INTO `Transactions` VALUES (92743, 'Monica', 'Monica', 23, 'Student', '8391-9000-7291', '2020-09-20', '2020-09-25', '2020-09-28', 'iphone 11', 'iphone 11', 'Phone', 'Apple', 5, '209102', 'Store pickup', '95273', 'Approved', 'No', 'No');
INSERT INTO `Transactions` VALUES (92827, 'Monica', 'Monica', 23, 'Student', '8291-0020-8890', '2020-08-09', '2020-08-14', '2020-08-14', 'AirpodsPro', 'AirpodsPro', 'Accessory', 'Apple', 2, '260870', 'Store pickup', '95273', 'Approved', 'No', 'Yes');
INSERT INTO `Transactions` VALUES (93509, 'Monica', 'Monica', 23, 'Student', '1233-8920-8102', '2020-02-11', '2020-02-16', '2020-02-14', 'SAMSUNG Galaxy', 'SAMSUNG Galaxy', 'SmartWatch', 'Samsung', 4, '337738', 'Store pickup', '95273', 'Approved', 'No', 'Yes');
INSERT INTO `Transactions` VALUES (93548, 'Monica', 'Monica', 23, 'Student', '8291-0010-0000', '2020-10-18', '2020-10-23', '2020-10-26', 'Smart Alarm', 'Smart Alarm', 'VoiceAssistant', 'Amazon', 4, '910542', 'Store pickup', '95273', 'Approved', 'No', 'No');
INSERT INTO `Transactions` VALUES (93900, 'Ben', 'Ben', 35, 'Dentist', '8900-6371-8219', '2020-01-19', '2020-01-24', '2020-01-23', 'X800H', 'X800H', 'TV', 'Sony', 2, '295656', 'Store pickup', '60625', 'Approved', 'No', 'Yes');
INSERT INTO `Transactions` VALUES (94828, 'Ben', 'Ben', 35, 'Dentist', '6372-1892-9201', '2020-10-17', '2020-10-22', '2020-10-25', 'iphone 11', 'iphone 11', 'Phone', 'Apple', 3, '056417', 'Store pickup', '60625', 'Approved', 'No', 'No');
INSERT INTO `Transactions` VALUES (94916, 'Ben', 'Ben', 35, 'Dentist', '5312-2931-4290', '2020-05-05', '2020-05-10', '2020-05-12', 'iphone pro11', 'iphone pro11', 'Phone', 'Apple', 3, '962982', 'Store pickup', '60625', 'Approved', 'Yes', 'No');
INSERT INTO `Transactions` VALUES (95117, 'Ben', 'Ben', 35, 'Dentist', '6281-9021-7432', '2020-01-08', '2020-01-13', '2020-01-12', 'G5', 'G5', 'Laptop', 'Dell', 2, '309851', 'Store pickup', '60625', 'Approved', 'No', 'Yes');
INSERT INTO `Transactions` VALUES (95835, 'Jerry', 'Jerry', 50, 'Manager', '5555-2893-0000', '2020-05-15', '2020-05-20', '2020-05-19', 'X800H', 'X800H', 'TV', 'Sony', 2, '193285', 'Store pickup', '60608', 'Approved', 'No', 'Yes');
INSERT INTO `Transactions` VALUES (95908, 'Jerry', 'Jerry', 50, 'Manager', '8392-1299-0210', '2020-04-10', '2020-04-15', '2020-04-16', 'AirpodsPro', 'AirpodsPro', 'Accessory', 'Apple', 5, '192756', 'Store pickup', '60608', 'Approved', 'No', 'No');
INSERT INTO `Transactions` VALUES (95959, 'Jerry', 'Jerry', 50, 'Manager', '3780-2912-2910', '2020-08-19', '2020-08-24', '2020-08-22', 'SAMSUNG Galaxy', 'SAMSUNG Galaxy', 'SmartWatch', 'Samsung', 5, '166973', 'Store pickup', '60608', 'Approved', 'No', 'Yes');
COMMIT;

SET FOREIGN_KEY_CHECKS = 1;
