/*
 Navicat Premium Data Transfer

 Source Server         : local_mysql
 Source Server Type    : MySQL
 Source Server Version : 80021
 Source Host           : localhost:3306
 Source Schema         : csp584hw2

 Target Server Type    : MySQL
 Target Server Version : 80021
 File Encoding         : 65001

 Date: 15/11/2020 05:49:42
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for Product_accessories
-- ----------------------------
DROP TABLE IF EXISTS `Product_accessories`;
CREATE TABLE `Product_accessories` (
  `productName` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `accessoriesName` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  KEY `productName` (`productName`),
  KEY `accessoriesName` (`accessoriesName`),
  CONSTRAINT `product_accessories_ibfk_1` FOREIGN KEY (`productName`) REFERENCES `Productdetails` (`Id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `product_accessories_ibfk_2` FOREIGN KEY (`accessoriesName`) REFERENCES `Productdetails` (`Id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ----------------------------
-- Records of Product_accessories
-- ----------------------------
BEGIN;
INSERT INTO `Product_accessories` VALUES ('A10', 'WirelessCharger');
INSERT INTO `Product_accessories` VALUES ('Y9', 'QuickCharger');
INSERT INTO `Product_accessories` VALUES ('Y9', 'WirelessCharger');
INSERT INTO `Product_accessories` VALUES ('Honor8x', 'Pencil');
INSERT INTO `Product_accessories` VALUES ('S9', 'QuickCharger');
INSERT INTO `Product_accessories` VALUES ('Note 9s', 'QuickCharger');
INSERT INTO `Product_accessories` VALUES ('iphone pro11', 'AirpodsPro');
INSERT INTO `Product_accessories` VALUES ('iphone pro11', '11 ScreenProt');
INSERT INTO `Product_accessories` VALUES ('iphone pro11', '11Pro Case');
INSERT INTO `Product_accessories` VALUES ('P30', 'P30_ScreenPro');
INSERT INTO `Product_accessories` VALUES ('P30', 'QuickCharger');
INSERT INTO `Product_accessories` VALUES ('Mate20', 'Pencil');
INSERT INTO `Product_accessories` VALUES ('iphone xr', 'Adapter');
INSERT INTO `Product_accessories` VALUES ('iphone 11', 'AirpodsPro');
INSERT INTO `Product_accessories` VALUES ('iphone 11', '11 ScreenProt');
INSERT INTO `Product_accessories` VALUES ('Note8', 'QuickCharger');
INSERT INTO `Product_accessories` VALUES ('Note8', 'MobilePower');
INSERT INTO `Product_accessories` VALUES ('Note8', 'WirelessCharger');
INSERT INTO `Product_accessories` VALUES ('A70', 'QuickCharger');
INSERT INTO `Product_accessories` VALUES ('iphone 6s', 'AirpodsPro');
INSERT INTO `Product_accessories` VALUES ('iphone 6s', 'Earpods3.5');
INSERT INTO `Product_accessories` VALUES ('A50', 'MobilePower');
INSERT INTO `Product_accessories` VALUES ('A20', 'QuickCharger');
COMMIT;

SET FOREIGN_KEY_CHECKS = 1;
