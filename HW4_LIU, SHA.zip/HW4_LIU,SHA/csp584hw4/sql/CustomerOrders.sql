/*
 Navicat Premium Data Transfer

 Source Server         : local_mysql
 Source Server Type    : MySQL
 Source Server Version : 80021
 Source Host           : localhost:3306
 Source Schema         : csp584hw2

 Target Server Type    : MySQL
 Target Server Version : 80021
 File Encoding         : 65001

 Date: 15/11/2020 05:49:32
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for CustomerOrders
-- ----------------------------
DROP TABLE IF EXISTS `CustomerOrders`;
CREATE TABLE `CustomerOrders` (
  `t_id` int NOT NULL AUTO_INCREMENT,
  `OrderId` int DEFAULT NULL,
  `user_id` int DEFAULT NULL,
  `username` varchar(20) DEFAULT NULL,
  `ProductId` varchar(20) DEFAULT NULL,
  `Category` varchar(20) DEFAULT NULL,
  `OrderPrice` double DEFAULT NULL,
  `OrderQuantity` int DEFAULT NULL,
  `Discount` double DEFAULT NULL,
  `TotalSales` double DEFAULT NULL,
  `creditCardNo` varchar(40) DEFAULT NULL,
  `ShippingAddress` varchar(100) DEFAULT NULL,
  `ShippingCost` double DEFAULT NULL,
  `PurchaseDate` date DEFAULT NULL,
  `ShipDate` date DEFAULT NULL,
  `StoreID` varchar(20) DEFAULT NULL,
  `StoreLocation` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`t_id`),
  UNIQUE KEY `t_id_UNIQUE` (`t_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `customerorders_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `Registration` (`user_id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=172 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ----------------------------
-- Records of CustomerOrders
-- ----------------------------
BEGIN;
INSERT INTO `CustomerOrders` VALUES (52, 133128, 1, 'c1', 'QN65Q7FN', 'TV', 124, 2, 2, 246, '23647128364891237', '2801 S KING DRIVE, APT 1017, CHICAGO, ILLINOIS, 60616', 18, '2020-10-08', '2020-10-22', 'none', 'none');
INSERT INTO `CustomerOrders` VALUES (53, 133549, 1, 'c1', 'XBR-65A8H', 'TV', 2498, 2, 216.8, 4779.2, '12873468912374', '20 W Fulton St, Hollywood, CA, 95273', 0, '2020-10-08', '2020-10-22', 'Fulton', '20 W Fulton St, Hollywood, CA, 95273');
INSERT INTO `CustomerOrders` VALUES (54, 133549, 1, 'c1', 'Z323', 'SoundSystem', 189.99, 1, 20, 169.99, '12873468912374', '20 W Fulton St, Hollywood, CA, 95273', 0, '2020-10-08', '2020-10-22', 'Fulton', '20 W Fulton St, Hollywood, CA, 95273');
INSERT INTO `CustomerOrders` VALUES (55, 133721, 1, 'c1', 'iphone xr', 'Phone', 599, 1, 0, 599, '2137489217398', '1001 W Webster Ave, Chicago, IL, 60625', 0, '2020-10-08', '2020-10-22', 'Webster', '1001 W Webster Ave, Chicago, IL, 60625');
INSERT INTO `CustomerOrders` VALUES (56, 133838, 1, 'c1', '3.1 Channel', 'SoundSystem', 856, 1, 80, 776, '32764982379239', 'Shelly, Denver, CO, 21076', 18, '2020-10-08', '2020-10-22', 'none', 'none');
INSERT INTO `CustomerOrders` VALUES (57, 134020, 1, 'c1', 'P30_ScreenPro', 'Accessory', 89.99, 1, 18, 71.99, '1234293847891', '10 S HongK St, Hollywood, CA, 98388', 0, '2020-10-08', '2020-10-22', 'Hongk', '10 S HongK St, Hollywood, CA, 98388');
INSERT INTO `CustomerOrders` VALUES (58, 134218, 2, 'c2', 'M4800', 'Laptop', 658, 1, 18, 640, '12983748219374', '2397 S Michigan Ave, Denver, UT, 82379', 18, '2020-10-08', '2020-10-22', 'none', 'none');
INSERT INTO `CustomerOrders` VALUES (59, 134735, 2, 'c2', 'A10', 'Phone', 168.99, 2, 38, 299.98, '39845703948', '108 N Madison Ave, Hollywood, CA, 91278', 0, '2020-10-08', '2020-10-22', 'Madison', '108 N Madison Ave, Hollywood, CA, 91278');
INSERT INTO `CustomerOrders` VALUES (60, 134905, 2, 'c2', 'Latest Mac15', 'Laptop', 2549, 1, 0, 2549, '9238746712364', '2801 S King Drive, Chicago, IL, 60616', 18, '2020-10-08', '2020-10-22', 'none', 'none');
INSERT INTO `CustomerOrders` VALUES (61, 134905, 2, 'c2', 'iphone 6s', 'Phone', 399.99, 1, 25, 374.99, '9238746712364', '2801 S King Drive, Chicago, IL, 60616', 18, '2020-10-08', '2020-10-22', 'none', 'none');
INSERT INTO `CustomerOrders` VALUES (62, 134905, 2, 'c2', 'AirpodsPro', 'Accessory', 249, 1, 10, 239, '9238746712364', '2801 S King Drive, Chicago, IL, 60616', 18, '2020-10-08', '2020-10-22', 'none', 'none');
INSERT INTO `CustomerOrders` VALUES (63, 135029, 2, 'c2', 'Ideapad3', 'Laptop', 549, 1, 39, 510, '30497829161234', '2801 S KING DRIVE, Denver, UT, 60616', 18, '2020-10-08', '2020-10-22', 'none', 'none');
INSERT INTO `CustomerOrders` VALUES (64, 135136, 2, 'c2', 'Nest Mini', 'VoiceAssistant', 39.99, 1, 2.99, 37, '324562394785012', '108 N State St, Denver, CO, 27837', 0, '2020-10-08', '2020-10-22', 'Stated', '108 N State St, Denver, CO, 27837');
INSERT INTO `CustomerOrders` VALUES (65, 135303, 3, 'c3', 'Mouse', 'Accessory', 89.99, 1, 0, 89.99, '209348120934890', '2728 N Clark St, Denver, CO, 29478', 0, '2020-10-08', '2020-10-22', 'Clark', '2728 N Clark St, Denver, CO, 29478');
INSERT INTO `CustomerOrders` VALUES (66, 135522, 3, 'c3', 'WHISTLE Blue_Combo', 'PetTracker', 129.9, 1, 1.97, 127.93, '212983742089374', '2728 N Clark St, Denver, CO, 29478', 0, '2020-10-08', '2020-10-22', 'Clark', '2728 N Clark St, Denver, CO, 29478');
INSERT INTO `CustomerOrders` VALUES (67, 135522, 3, 'c3', 'GARMIN F235', 'FitnessWatch', 169.99, 1, 12.99, 157, '212983742089374', '2728 N Clark St, Denver, CO, 29478', 0, '2020-10-08', '2020-10-22', 'Clark', '2728 N Clark St, Denver, CO, 29478');
INSERT INTO `CustomerOrders` VALUES (68, 135522, 3, 'c3', 'OCULUS Rift_S', 'VirtualReality', 399, 1, 16, 383, '212983742089374', '2728 N Clark St, Denver, CO, 29478', 0, '2020-10-08', '2020-10-22', 'Clark', '2728 N Clark St, Denver, CO, 29478');
INSERT INTO `CustomerOrders` VALUES (69, 135646, 3, 'c3', 'Note 9s', 'Phone', 210.93, 1, 8, 202.93, '9230749302112309', '2901 S Lake St, New York City, NY, 78762', 18, '2020-10-08', '2020-10-22', 'none', 'none');
INSERT INTO `CustomerOrders` VALUES (70, 135726, 3, 'c3', 'Z506', 'SoundSystem', 39.99, 1, 0, 39.99, '129384912038919023', '2801 S KING DRIVE, Denver, UT, 60616', 18, '2020-10-08', '2020-10-22', 'none', 'none');
INSERT INTO `CustomerOrders` VALUES (71, 135821, 3, 'c3', 'PANSONITE Anti', 'Headphone', 52.99, 1, 10, 42.99, '92302398401892', 'Yelp oak St, Chicago, IL, 60616', 18, '2020-10-08', '2020-10-22', 'none', 'none');
INSERT INTO `CustomerOrders` VALUES (72, 140031, 4, 'c4', 'Mac13', 'Laptop', 1464, 1, 128, 1336, '324562938472903', 'K Pake Ave, Denver, UT, 60608', 18, '2020-10-08', '2020-10-22', 'none', 'none');
INSERT INTO `CustomerOrders` VALUES (73, 140031, 4, 'c4', 'FITBIT Versa2', 'FitnessWatch', 179, 1, 15, 164, '324562938472903', 'K Pake Ave, Denver, UT, 60608', 18, '2020-10-08', '2020-10-22', 'none', 'none');
INSERT INTO `CustomerOrders` VALUES (74, 140104, 4, 'c4', 'Mouse', 'Accessory', 89.99, 1, 0, 89.99, 'qwef', '1101 S Canal St, Denver, CO, 21076', 0, '2020-10-08', '2020-10-22', 'Canal', '1101 S Canal St, Denver, CO, 21076');
INSERT INTO `CustomerOrders` VALUES (75, 140201, 4, 'c4', '2020', 'Laptop', 749, 1, 10, 739, '293842130984', '200 N Dearborn St, Denver, CO, 20987', 0, '2020-10-08', '2020-10-22', 'Dearborn', '200 N Dearborn St, Denver, CO, 20987');
INSERT INTO `CustomerOrders` VALUES (107, 204227, 1, 'c1', 'iphone 11', 'Phone', 699, 1, 0, 699, '123847120938419023', '108 N State St, Denver, CO, 27837', 0, '2020-10-09', '2020-10-23', 'Stated', '108 N State St, Denver, CO, 27837');
INSERT INTO `CustomerOrders` VALUES (108, 204227, 1, 'c1', 'AirpodsPro', 'Accessory', 249, 1, 10, 239, '123847120938419023', '108 N State St, Denver, CO, 27837', 0, '2020-10-09', '2020-10-23', 'Stated', '108 N State St, Denver, CO, 27837');
INSERT INTO `CustomerOrders` VALUES (111, 155014, 7, 'sa1', 'iphone 11', 'Phone', 699, 3, 0, 2097, '932187412938401928', '10 S HongK St, Hollywood, CA, 98388', 0, '2020-10-12', '2020-10-26', 'Hongk', '10 S HongK St, Hollywood, CA, 98388');
INSERT INTO `CustomerOrders` VALUES (112, 2706, 2, 'c2', 'TU-8000', 'TV', 497.99, 1, 10, 487, '12384712038901', '181 S Park St, Syracuse, NY, 57298', 0, '2020-10-22', '2020-11-05', 'Park', '181 S Park St, Syracuse, NY, 57298');
INSERT INTO `CustomerOrders` VALUES (113, 211926, 4, 'c4', 'iphone 11', 'Phone', 699, 1, 0, 699, '1287346129387489123', '5118 S Lake Ave, Syracuse, NY, 51028', 0, '2020-10-22', '2020-11-05', 'Lake', '5118 S Lake Ave, Syracuse, NY, 51028');
INSERT INTO `CustomerOrders` VALUES (114, 235901, 1, 'c1', 'QN65Q7FN', 'TV', 124, 1, 1, 123, '9821374012934', 'aesfdg, CHICAGO, ILLINOIS, asdf', 18, '2020-10-31', '2020-11-14', 'none', 'none');
INSERT INTO `CustomerOrders` VALUES (115, 161148, 1, 'c1', 'iphone 6s', 'Phone', 399.99, 1, 25, 374, '21943821903723987', '2801 S KING DRIVE, Denver, UT, 29087', 18, '2020-11-04', '2020-11-18', 'none', 'none');
INSERT INTO `CustomerOrders` VALUES (116, 44256, 1, 'c1', 'iphone xr', 'Phone', 599, 1, 0, 599, '1423-1726-1625', '2801 S KING DRIVE, APT 1017, Chicago, IL, 60616', 18, '2020-11-05', '2020-11-19', 'none', 'none');
INSERT INTO `CustomerOrders` VALUES (117, 44847, 2, 'c2', 'QN65Q7FN', 'TV', 124, 1, 1, 123, '7267-7187-2561', '2801 S KING DRIVE, Chicago, IL, 60616', 18, '2020-11-05', '2020-11-19', 'none', 'none');
INSERT INTO `CustomerOrders` VALUES (118, 45549, 3, 'c3', 'Z323', 'SoundSystem', 189.99, 1, 20, 169, '7186-2791-8291', '2801 S KING DRIVE, Chicago, IL, 60616', 18, '2020-11-05', '2020-11-19', 'none', 'none');
INSERT INTO `CustomerOrders` VALUES (119, 51220, 4, 'c4', 'iphone xr', 'Phone', 599, 1, 0, 599, '32456', '2801 S KING DRIVE, Chicago, IL, 60616', 18, '2020-11-05', '2020-11-19', 'none', 'none');
INSERT INTO `CustomerOrders` VALUES (120, 51745, 4, 'c4', 'XBR-65A8H', 'TV', 2498, 1, 108.4, 2389, '123t4', '2801 S KING DRIVE, APT 1017, Chicago, IL, 60616', 18, '2020-11-05', '2020-11-19', 'none', 'none');
INSERT INTO `CustomerOrders` VALUES (121, 52736, 4, 'c4', 'Ideapad3', 'Laptop', 549, 1, 39, 510, '32456', '2801 S KING DRIVE, Chicago, IL, 60616', 18, '2020-11-05', '2020-11-19', 'none', 'none');
INSERT INTO `CustomerOrders` VALUES (122, 53055, 4, 'c4', 'XBR-65A8H', 'TV', 2498, 1, 108.4, 2389, '8291-9281-8291', '1101 S Canal St, Denver, CO, 21076', 0, '2020-11-05', '2020-11-19', 'Canal', '1101 S Canal St, Denver, CO, 21076');
INSERT INTO `CustomerOrders` VALUES (123, 53256, 4, 'c4', 'iphone 11', 'Phone', 699, 1, 0, 699, '0974-3573-9736', '20 W Fulton St, Hollywood, CA, 95273', 0, '2020-11-05', '2020-11-19', 'Fulton', '20 W Fulton St, Hollywood, CA, 95273');
INSERT INTO `CustomerOrders` VALUES (124, 53447, 4, 'c4', 'WHISTLE Blue_Combo', 'PetTracker', 129.9, 1, 1.97, 127, '7291-2918-8192', '2801 S KING DRIVE, APT 1017, Chicago, IL, 60616', 18, '2020-11-05', '2020-11-19', 'none', 'none');
INSERT INTO `CustomerOrders` VALUES (125, 54150, 4, 'c4', 'Mouse', 'Accessory', 89.99, 1, 0, 89, '7291-9201-9023', '2801 S KING DRIVE, Chicago, IL, 60616', 18, '2020-11-05', '2020-11-19', 'none', 'none');
INSERT INTO `CustomerOrders` VALUES (126, 54827, 4, 'c4', 'SONY 310', 'Headphone', 59.95, 1, 12.99, 46, '8291-9281-8291', 'sdkjfhufwqe, Denver, CO, 21076', 18, '2020-11-05', '2020-11-19', 'none', 'none');
INSERT INTO `CustomerOrders` VALUES (127, 55006, 2, 'c2', 'GARMIN V3', 'FitnessWatch', 70, 1, 0, 70, '7192-9217-8391', 'qwoieur, nvcmkn, wuehr, 60608', 18, '2020-11-05', '2020-11-19', 'none', 'none');
INSERT INTO `CustomerOrders` VALUES (128, 55108, 2, 'c2', 'M4800', 'Laptop', 658, 1, 18, 640, '7921-8291-7219', 'aesfdg, CHICAGO, ILLINOIS, 60608', 18, '2020-11-05', '2020-11-19', 'none', 'none');
INSERT INTO `CustomerOrders` VALUES (129, 55206, 2, 'c2', 'Nest Mini', 'VoiceAssistant', 39.99, 1, 2.99, 37, '1231-8291-8301', 'qwoieur, nvcmkn, wuehr, 60608', 18, '2020-11-05', '2020-11-19', 'none', 'none');
INSERT INTO `CustomerOrders` VALUES (130, 55505, 2, 'c2', 'P30', 'Phone', 172, 1, 28.05, 143, '3245-7192-8192-8192', 'qwoieur, nvcmkn, wuehr, 60608', 18, '2020-11-05', '2020-11-19', 'none', 'none');
INSERT INTO `CustomerOrders` VALUES (131, 55505, 2, 'c2', 'QuickCharger', 'Accessory', 89.99, 1, 40, 49, '3245-7192-8192-8192', 'qwoieur, nvcmkn, wuehr, 60608', 18, '2020-11-05', '2020-11-19', 'none', 'none');
INSERT INTO `CustomerOrders` VALUES (132, 60624, 2, 'c2', '5.1 set', 'SoundSystem', 480.07, 1, 40, 440, '7291-8291-7291', 'qwoieur, nvcmkn, wuehr, 60608', 18, '2020-11-05', '2020-11-19', 'none', 'none');
INSERT INTO `CustomerOrders` VALUES (133, 60811, 2, 'c2', 'Mac15', 'Laptop', 1343.78, 1, 400, 943, '7281-7291-7281', '20 W Fulton St, Hollywood, CA, 95273', 0, '2020-11-05', '2020-11-19', 'Fulton', '20 W Fulton St, Hollywood, CA, 95273');
INSERT INTO `CustomerOrders` VALUES (134, 60811, 2, 'c2', 'AirpodsPro', 'Accessory', 249, 1, 10, 239, '7281-7291-7281', '20 W Fulton St, Hollywood, CA, 95273', 0, '2020-11-05', '2020-11-19', 'Fulton', '20 W Fulton St, Hollywood, CA, 95273');
INSERT INTO `CustomerOrders` VALUES (135, 61529, 2, 'c2', 'Z506', 'SoundSystem', 39.99, 1, 0, 39, '7382-7392-1092', 'qwoieur, nvcmkn, wuehr, 60608', 18, '2020-11-05', '2020-11-19', 'none', 'none');
INSERT INTO `CustomerOrders` VALUES (136, 162726, 3, 'c3', 'GARMIN V3', 'FitnessWatch', 70, 1, 0, 70, '2819-2791-8921', '20 W Fulton St, Hollywood, CA, 95273', 0, '2020-11-05', '2020-11-19', 'Fulton', '20 W Fulton St, Hollywood, CA, 95273');
INSERT INTO `CustomerOrders` VALUES (137, 162904, 3, 'c3', 'SONY Dial3', 'SmartWatch', 25, 1, 0, 25, '7391-2389-3891', '20 W Fulton St, Hollywood, CA, 95273', 0, '2020-11-05', '2020-11-19', 'Fulton', '20 W Fulton St, Hollywood, CA, 95273');
INSERT INTO `CustomerOrders` VALUES (138, 163000, 3, 'c3', 'WHISTLE Go_Explore', 'PetTracker', 29.95, 1, 1, 28, '7312-2921-7391', '20 W Fulton St, Hollywood, CA, 95273', 0, '2020-11-05', '2020-11-19', 'Fulton', '20 W Fulton St, Hollywood, CA, 95273');
INSERT INTO `CustomerOrders` VALUES (139, 163139, 3, 'c3', 'AirpodsPro', 'Accessory', 249, 1, 10, 239, '2628-3891-3719', '108 N Madison Ave, Hollywood, CA, 91278', 0, '2020-11-05', '2020-11-19', 'Madison', '108 N Madison Ave, Hollywood, CA, 91278');
INSERT INTO `CustomerOrders` VALUES (140, 163356, 1, 'c1', '50LF621U21', 'TV', 429.99, 1, 50, 379, '3721-3829-3891', '28 S Madison Ave, Denver, CO, 21076', 18, '2020-11-05', '2020-11-19', 'none', 'none');
INSERT INTO `CustomerOrders` VALUES (141, 163503, 1, 'c1', 'Latest Mac15', 'Laptop', 2549, 1, 0, 2549, '7029-2891-7391', '28 S Madison Ave, Denver, CO, 21076', 18, '2020-11-05', '2020-11-19', 'none', 'none');
INSERT INTO `CustomerOrders` VALUES (142, 163618, 1, 'c1', 'X800H', 'TV', 598, 1, 50, 548, '9201-2891-7381', '108 N Madison Ave, Hollywood, CA, 91278', 0, '2020-11-05', '2020-11-19', 'Madison', '108 N Madison Ave, Hollywood, CA, 91278');
INSERT INTO `CustomerOrders` VALUES (143, 163727, 5, 'c5', 'Y9', 'Phone', 571, 1, 61, 510, '6281-9021-6720', '2801 S KING DRIVE, Denver, UT, 29087', 18, '2020-11-05', '2020-11-19', 'none', 'none');
INSERT INTO `CustomerOrders` VALUES (144, 163727, 5, 'c5', 'WirelessCharger', 'Accessory', 259, 1, 40, 219, '6281-9021-6720', '2801 S KING DRIVE, Denver, UT, 29087', 18, '2020-11-05', '2020-11-19', 'none', 'none');
INSERT INTO `CustomerOrders` VALUES (145, 164700, 5, 'c5', 'Y9', 'Phone', 571, 1, 61, 510, '9201-2791-7281', '2801 S KING DRIVE, Denver, UT, 29087', 18, '2020-11-05', '2020-11-19', 'none', 'none');
INSERT INTO `CustomerOrders` VALUES (146, 164700, 5, 'c5', 'QuickCharger', 'Accessory', 89.99, 1, 40, 49, '9201-2791-7281', '2801 S KING DRIVE, Denver, UT, 29087', 18, '2020-11-05', '2020-11-19', 'none', 'none');
INSERT INTO `CustomerOrders` VALUES (147, 164919, 5, 'c5', 'Latest Mac15', 'Laptop', 2549, 1, 0, 2549, '8291-8291-3681', '2801 S KING DRIVE, Denver, UT, 29088', 18, '2020-11-05', '2020-11-19', 'none', 'none');
INSERT INTO `CustomerOrders` VALUES (148, 164919, 5, 'c5', 'AirpodsPro', 'Accessory', 249, 1, 10, 239, '8291-8291-3681', '2801 S KING DRIVE, Denver, UT, 29088', 18, '2020-11-05', '2020-11-19', 'none', 'none');
INSERT INTO `CustomerOrders` VALUES (149, 165059, 11, 'c7', 'iphone xr', 'Phone', 599, 1, 0, 599, '9092-7291-8391-2791', '108 N State St, Denver, CO, 27837', 0, '2020-11-05', '2020-11-19', 'Stated', '108 N State St, Denver, CO, 27837');
INSERT INTO `CustomerOrders` VALUES (150, 165059, 11, 'c7', 'AirpodsPro', 'Accessory', 249, 1, 10, 239, '9092-7291-8391-2791', '108 N State St, Denver, CO, 27837', 0, '2020-11-05', '2020-11-19', 'Stated', '108 N State St, Denver, CO, 27837');
INSERT INTO `CustomerOrders` VALUES (151, 165059, 11, 'c7', 'Earpods3.5', 'Accessory', 29, 1, 3, 26, '9092-7291-8391-2791', '108 N State St, Denver, CO, 27837', 0, '2020-11-05', '2020-11-19', 'Stated', '108 N State St, Denver, CO, 27837');
INSERT INTO `CustomerOrders` VALUES (152, 163854, 1, 'c1', 'QN65Q7FN', 'TV', 124, 1, 1, 123, '6172-9012-8391', '2801 S KING DRIVE, Chicago, IL, 60616', 18, '2020-11-08', '2020-11-22', 'none', 'none');
INSERT INTO `CustomerOrders` VALUES (153, 175132, 1, 'c1', 'iphone 6s', 'Phone', 399.99, 1, 25, 374, '7182-9201-7291', '2801 S KING DRIVE, Chicago, IL, 60616', 18, '2020-11-08', '2020-11-22', 'none', 'none');
INSERT INTO `CustomerOrders` VALUES (154, 91634, 1, 'Lili', 'X800H', 'TV', 598, 1, 50, 548, '6271-8921-9201', '2801 S KING DRIVE, Chicago, IL, 60616', 18, '2020-11-14', '2020-11-28', 'none', 'none');
INSERT INTO `CustomerOrders` VALUES (155, 91919, 1, 'Lili', 'iphone 11', 'Phone', 699, 1, 0, 699, '8291-0001-8882', '2801 S KING DRIVE, Chicago, IL, 60616', 18, '2020-11-14', '2020-11-28', 'none', 'none');
INSERT INTO `CustomerOrders` VALUES (156, 92022, 1, 'Lili', 'iphone pro11', 'Phone', 999, 1, 0, 999, '0029-8291-7002', '2801 S KING DRIVE, Chicago, IL, 60616', 18, '2020-11-14', '2020-11-28', 'none', 'none');
INSERT INTO `CustomerOrders` VALUES (157, 92743, 27, 'Monica', 'iphone 11', 'Phone', 699, 1, 0, 699, '8391-9000-7291', '20 W Fulton St, Hollywood, CA, 95273', 0, '2020-11-14', '2020-11-28', 'Fulton', '20 W Fulton St, Hollywood, CA, 95273');
INSERT INTO `CustomerOrders` VALUES (158, 92827, 27, 'Monica', 'AirpodsPro', 'Accessory', 249, 1, 10, 239, '8291-0020-8890', '20 W Fulton St, Hollywood, CA, 95273', 0, '2020-11-14', '2020-11-28', 'Fulton', '20 W Fulton St, Hollywood, CA, 95273');
INSERT INTO `CustomerOrders` VALUES (159, 93509, 27, 'Monica', 'SAMSUNG Galaxy', 'SmartWatch', 562, 1, 24, 538, '1233-8920-8102', '20 W Fulton St, Hollywood, CA, 95273', 0, '2020-11-14', '2020-11-28', 'Fulton', '20 W Fulton St, Hollywood, CA, 95273');
INSERT INTO `CustomerOrders` VALUES (160, 93548, 27, 'Monica', 'Smart Alarm', 'VoiceAssistant', 89.99, 1, 10, 79, '8291-0010-0000', '20 W Fulton St, Hollywood, CA, 95273', 0, '2020-11-14', '2020-11-28', 'Fulton', '20 W Fulton St, Hollywood, CA, 95273');
INSERT INTO `CustomerOrders` VALUES (161, 93900, 29, 'Ben', 'X800H', 'TV', 598, 1, 50, 548, '8900-6371-8219', '1001 W Webster Ave, Chicago, IL, 60625', 0, '2020-11-14', '2020-11-28', 'Webster', '1001 W Webster Ave, Chicago, IL, 60625');
INSERT INTO `CustomerOrders` VALUES (162, 94828, 29, 'Ben', 'iphone 11', 'Phone', 699, 1, 0, 699, '6372-1892-9201', '1001 W Webster Ave, Chicago, IL, 60625', 0, '2020-11-14', '2020-11-28', 'Webster', '1001 W Webster Ave, Chicago, IL, 60625');
INSERT INTO `CustomerOrders` VALUES (163, 94916, 29, 'Ben', 'iphone pro11', 'Phone', 999, 1, 0, 999, '5312-2931-4290', '1001 W Webster Ave, Chicago, IL, 60625', 0, '2020-11-14', '2020-11-28', 'Webster', '1001 W Webster Ave, Chicago, IL, 60625');
INSERT INTO `CustomerOrders` VALUES (164, 95117, 29, 'Ben', 'G5', 'Laptop', 1249, 1, 100, 1149, '6281-9021-7432', '1001 W Webster Ave, Chicago, IL, 60625', 0, '2020-11-14', '2020-11-28', 'Webster', '1001 W Webster Ave, Chicago, IL, 60625');
INSERT INTO `CustomerOrders` VALUES (165, 95835, 30, 'Jerry', 'X800H', 'TV', 598, 1, 50, 548, '5555-2893-0000', '203 N LaSalle St, Chicago, IL, 60608', 0, '2020-11-14', '2020-11-28', 'LaSalle', '203 N LaSalle St, Chicago, IL, 60608');
INSERT INTO `CustomerOrders` VALUES (166, 95908, 30, 'Jerry', 'AirpodsPro', 'Accessory', 249, 1, 10, 239, '8392-1299-0210', '203 N LaSalle St, Chicago, IL, 60608', 0, '2020-11-14', '2020-11-28', 'LaSalle', '203 N LaSalle St, Chicago, IL, 60608');
INSERT INTO `CustomerOrders` VALUES (167, 95959, 30, 'Jerry', 'SAMSUNG Galaxy', 'SmartWatch', 562, 1, 24, 538, '3780-2912-2910', '203 N LaSalle St, Chicago, IL, 60608', 0, '2020-11-14', '2020-11-28', 'LaSalle', '203 N LaSalle St, Chicago, IL, 60608');
INSERT INTO `CustomerOrders` VALUES (168, 160619, 1, 'c1', 'QN65Q7FN', 'TV', 124, 1, 1, 123, '192837123894710293', '1001 W Webster Ave, Chicago, IL, 60625', 0, '2020-11-14', '2020-11-28', 'Webster', '1001 W Webster Ave, Chicago, IL, 60625');
INSERT INTO `CustomerOrders` VALUES (169, 160807, 1, 'c1', 'QN65Q7FN', 'TV', 124, 1, 1, 123, '371298120938', '10 S HongK St, Hollywood, CA, 98388', 0, '2020-11-14', '2020-11-28', 'Hongk', '10 S HongK St, Hollywood, CA, 98388');
INSERT INTO `CustomerOrders` VALUES (170, 161144, 1, 'c1', 'QN65Q7FN', 'TV', 124, 1, 1, 123, '32456', '108 N State St, Denver, CO, 27837', 0, '2020-11-14', '2020-11-28', 'Stated', '108 N State St, Denver, CO, 27837');
INSERT INTO `CustomerOrders` VALUES (171, 164901, 1, 'c1', 'QN65Q7FN', 'TV', 124, 1, 1, 123, '32456', '108 N State St, Denver, CO, 27837', 0, '2020-11-14', '2020-11-28', 'Stated', '108 N State St, Denver, CO, 27837');
COMMIT;

SET FOREIGN_KEY_CHECKS = 1;
