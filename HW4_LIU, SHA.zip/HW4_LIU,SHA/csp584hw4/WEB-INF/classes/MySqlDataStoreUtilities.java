import com.sun.tools.corba.se.idl.constExpr.Or;
import sun.util.resources.cldr.zh.CalendarData_zh_Hans_HK;

import java.math.BigDecimal;
import java.sql.*;
import java.util.*;
import java.util.Date;

public class MySqlDataStoreUtilities {
    static Connection conn = null;

    public static void getConnection() {

        try {
            Class.forName("com.mysql.cj.jdbc.Driver").newInstance();
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/csp584hw2?serverTimezone=UTC&useSSL=false&allowPublicKeyRetrieval=true", "root", "12345678");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    public static void deleteOrder(int orderId, String orderName) {
        try {
            getConnection();
            String deleteOrderQuery = "Delete from CustomerOrders where OrderId=? and ProductId=?";
            PreparedStatement pst = conn.prepareStatement(deleteOrderQuery);
            pst.setInt(1, orderId);
            pst.setString(2, orderName);
            pst.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void insertOrder(int user_id, String username, String ShippingAddress, String creditCardNo, int OrderId, java.util.Date d1, java.util.Date d2,
                                   String ProductId, String Category, int OrderQuantity, double OrderPrice, double ShippingCost, double Discount, double TotalSales, String StoreID, String StoreLocation) {
        try {
            java.sql.Date PurchaseDate = new java.sql.Date(d1.getTime());
            java.sql.Date ShipDate = new java.sql.Date(d2.getTime());

            getConnection();
            String insertIntoCustomerOrderQuery = "INSERT INTO CustomerOrders(user_id,username, ShippingAddress, " +
                    "creditCardNo,OrderId,PurchaseDate,ShipDate,ProductId,Category,OrderQuantity, " +
                    "OrderPrice, ShippingCost, Discount, TotalSales, StoreID, StoreLocation) "
                    + "VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?);";
            PreparedStatement pst = conn.prepareStatement(insertIntoCustomerOrderQuery);
            //set the parameter for each column and execute the prepared statement
            pst.setInt(1, user_id);
            pst.setString(2, username);
            pst.setString(3, ShippingAddress);
            pst.setString(4, creditCardNo);
            pst.setInt(5, OrderId);
            pst.setDate(6, PurchaseDate);
            pst.setDate(7, ShipDate);
            pst.setString(8, ProductId);
            pst.setString(9, Category);
            pst.setInt(10, OrderQuantity);
            pst.setDouble(11, OrderPrice);
            pst.setDouble(12, ShippingCost);
            pst.setDouble(13, Discount);
            pst.setDouble(14, (int) TotalSales);
            pst.setString(15, StoreID);
            pst.setString(16, StoreLocation);
            pst.execute();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static HashMap<Integer, ArrayList<OrderPayment>> selectOrder() {

        HashMap<Integer, ArrayList<OrderPayment>> orderPayments = new HashMap<Integer, ArrayList<OrderPayment>>();

        try {

            getConnection();
            //select the table
            String selectOrderQuery = "select * from CustomerOrders";
            PreparedStatement pst = conn.prepareStatement(selectOrderQuery);
            ResultSet rs = pst.executeQuery();
            ArrayList<OrderPayment> orderList = new ArrayList<OrderPayment>();
            while (rs.next()) {
                if (!orderPayments.containsKey(rs.getInt("OrderId"))) {
                    ArrayList<OrderPayment> arr = new ArrayList<OrderPayment>();
                    orderPayments.put(rs.getInt("OrderId"), arr);
                }
                ArrayList<OrderPayment> listOrderPayment = orderPayments.get(rs.getInt("OrderId"));
                System.out.println("data is" + rs.getInt("user_id") + rs.getString("userName") + rs.getString("ShippingAddress") + rs.getString("creditCardNo") + rs.getInt("OrderId") + rs.getDate("PurchaseDate") + rs.getDate("ShipDate") + rs.getString("ProductId") + rs.getString("Category") + rs.getInt("OrderQuantity") + rs.getDouble("OrderPrice") + rs.getDouble("ShippingCost") + rs.getDouble("Discount") + rs.getDouble("TotalSales") + rs.getString("StoreID") + rs.getString("StoreLocation"));

                //add to orderpayment hashmap
                OrderPayment order = new OrderPayment(rs.getInt("user_id"), rs.getString("userName"), rs.getString("ShippingAddress"), rs.getString("creditCardNo"), rs.getInt("OrderId"), rs.getDate("PurchaseDate"), rs.getDate("ShipDate"), rs.getString("ProductId"), rs.getString("Category"), rs.getInt("OrderQuantity"), rs.getDouble("OrderPrice"), rs.getDouble("ShippingCost"), rs.getDouble("Discount"), rs.getDouble("TotalSales"), rs.getString("StoreID"), rs.getString("StoreLocation"));
                listOrderPayment.add(order);

            }


        } catch (Exception e) {
            e.printStackTrace();
        }
        return orderPayments;
    }

    public static void updateOrder(String address, String creditCard) {
        try {
            getConnection();

            String sql = "update CustomerOrders set ShippingAddress=?,creditCardNo=? ";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, address);
            pstmt.setString(2, creditCard);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void insertCustomerAddress(String userName, String street, String city, String state, String zipCode) {
        try {

            getConnection();
            String insertIntoCustomeAddressQuery = "INSERT INTO CustomerAddress(CustomerName,street,city,state,zipCode) "
                    + "VALUES (?,?,?,?,?);";

            PreparedStatement pst = conn.prepareStatement(insertIntoCustomeAddressQuery);
            //set the parameter for each column and execute the prepared statement
            pst.setString(1, userName);
            pst.setString(2, street);
            pst.setString(3, city);
            pst.setString(4, state);
            pst.setString(5, zipCode);
            pst.execute();
        } catch (Exception e) {

        }
    }


    public static boolean insertUser(String username, String password, String repassword, String usertype) {
        try {

            getConnection();
            String insertIntoCustomerRegisterQuery = "INSERT INTO Registration(username,password,repassword,usertype) "
                    + "VALUES (?,?,?,?);";

            PreparedStatement pst = conn.prepareStatement(insertIntoCustomerRegisterQuery);
            pst.setString(1, username);
            pst.setString(2, password);
            pst.setString(3, repassword);
            pst.setString(4, usertype);
            pst.execute();
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
        return true;
    }

    public static HashMap<String, User> selectUser() {
        HashMap<String, User> hm = new HashMap<String, User>();
        try {
            getConnection();
            Statement stmt = conn.createStatement();
            String selectCustomerQuery = "select * from  Registration";
            ResultSet rs = stmt.executeQuery(selectCustomerQuery);
            while (rs.next()) {
                User user = new User(rs.getString("username"), rs.getString("password"), rs.getString("usertype"));
                hm.put(rs.getString("username"), user);
            }
        } catch (Exception e) {
        }
        return hm;
    }


    public static HashMap<String, TV> getTV() {
        HashMap<String, TV> hm = new HashMap<String, TV>();
        try {
            getConnection();

            String selectTV = "select * from  Productdetails where ProductType=?";
            PreparedStatement pstmt = conn.prepareStatement(selectTV);
            pstmt.setString(1, "TV");
            ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
                TV tv = new TV(rs.getString("productName"), rs.getDouble("productPrice"), rs.getString("productImage"), rs.getString("productManufacturer"), rs.getString("productCondition"), rs.getDouble("productDiscount"), rs.getString("ProductType"), rs.getDouble("manufacturerRebates"), rs.getInt("inventory"));
                hm.put(rs.getString("Id"), tv);
                tv.setId(rs.getString("Id"));
            }
        } catch (Exception e) {
        }
        return hm;
    }

    public static HashMap<String, SoundSystem> getSoundSystem() {
        HashMap<String, SoundSystem> hm = new HashMap<String, SoundSystem>();
        try {
            getConnection();

            String selectSoundSystem = "select * from Productdetails where ProductType=?";
            PreparedStatement pstmt = conn.prepareStatement(selectSoundSystem);
            pstmt.setString(1, "SoundSystem");
            ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
                SoundSystem soundSystem = new SoundSystem(rs.getString("productName"), rs.getDouble("productPrice"), rs.getString("productImage"), rs.getString("productManufacturer"), rs.getString("productCondition"), rs.getDouble("productDiscount"), rs.getString("ProductType"), rs.getDouble("manufacturerRebates"), rs.getInt("inventory"));
                hm.put(rs.getString("Id"), soundSystem);
                soundSystem.setId(rs.getString("Id"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return hm;
    }

    public static HashMap<String, Phone> getPhoneAcc() {
        HashMap<String, Phone> hm = new HashMap<String, Phone>();
        try {
            getConnection();

            String selectPhone = "select * from Productdetails where ProductType=?";
            PreparedStatement pstmt = conn.prepareStatement(selectPhone);
            pstmt.setString(1, "Phone");
            ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
                Phone phone = new Phone(rs.getString("productName"), rs.getDouble("productPrice"), rs.getString("productImage"), rs.getString("productManufacturer"), rs.getString("productCondition"), rs.getDouble("productDiscount"), rs.getString("ProductType"), rs.getDouble("manufacturerRebates"), rs.getInt("inventory"));
                hm.put(rs.getString("Id"), phone);
                phone.setId(rs.getString("Id"));
                try {
                    String selectAcc = "select * from Product_accessories where productName=?";
                    PreparedStatement pstmtAcc = conn.prepareStatement(selectAcc);
                    pstmtAcc.setString(1, rs.getString("Id"));
                    ResultSet rsAcc = pstmtAcc.executeQuery();
                    HashMap<String, String> accHashmap = new HashMap<String, String>();
                    while (rsAcc.next()) {
                        if (rsAcc.getString("accessoriesName") != null) {
                            accHashmap.put(rsAcc.getString("productName"), rsAcc.getString("accessoriesName"));
                            phone.setAccessories(accHashmap);
                        }
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return hm;
    }

    public static HashMap<String, Laptop> getLaptop() {
        HashMap<String, Laptop> hm = new HashMap<String, Laptop>();
        try {
            getConnection();

            String selectLaptop = "select * from Productdetails where ProductType=?";
            PreparedStatement pstmt = conn.prepareStatement(selectLaptop);
            pstmt.setString(1, "Laptop");
            ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
                Laptop laptop = new Laptop(rs.getString("productName"), rs.getDouble("productPrice"), rs.getString("productImage"), rs.getString("productManufacturer"), rs.getString("productCondition"), rs.getDouble("productDiscount"), rs.getString("ProductType"), rs.getDouble("manufacturerRebates"), rs.getInt("inventory"));
                hm.put(rs.getString("Id"), laptop);
                laptop.setId(rs.getString("Id"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return hm;
    }

    public static HashMap<String, VoiceAssistant> getVoiceAssistant() {
        HashMap<String, VoiceAssistant> hm = new HashMap<String, VoiceAssistant>();
        try {
            getConnection();

            String selectVoiceAssistant = "select * from Productdetails where ProductType=?";
            PreparedStatement pstmt = conn.prepareStatement(selectVoiceAssistant);
            pstmt.setString(1, "VoiceAssistant");
            ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
                VoiceAssistant voiceAssistant = new VoiceAssistant(rs.getString("productName"), rs.getDouble("productPrice"), rs.getString("productImage"), rs.getString("productManufacturer"), rs.getString("productCondition"), rs.getDouble("productDiscount"), rs.getString("ProductType"), rs.getDouble("manufacturerRebates"), rs.getInt("inventory"));
                hm.put(rs.getString("Id"), voiceAssistant);
                voiceAssistant.setId(rs.getString("Id"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return hm;
    }

    public static HashMap<String, FitnessWatch> getFitnessWatch() {
        HashMap<String, FitnessWatch> hm = new HashMap<String, FitnessWatch>();
        try {
            getConnection();

            String selectFitnessWatch = "select * from  Productdetails where ProductType=?";
            PreparedStatement pstmt = conn.prepareStatement(selectFitnessWatch);
            pstmt.setString(1, "FitnessWatch");
            ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
                FitnessWatch fitnessWatch = new FitnessWatch(rs.getString("productName"), rs.getDouble("productPrice"), rs.getString("productImage"), rs.getString("productManufacturer"), rs.getString("productCondition"), rs.getDouble("productDiscount"), rs.getString("ProductType"), rs.getDouble("manufacturerRebates"), rs.getInt("inventory"));
                hm.put(rs.getString("Id"), fitnessWatch);
                fitnessWatch.setId(rs.getString("Id"));
            }
        } catch (Exception e) {
        }
        return hm;
    }

    public static HashMap<String, SmartWatch> getSmartWatch() {
        HashMap<String, SmartWatch> hm = new HashMap<String, SmartWatch>();
        try {
            getConnection();

            String selectSmartWatch = "select * from  Productdetails where ProductType=?";
            PreparedStatement pstmt = conn.prepareStatement(selectSmartWatch);
            pstmt.setString(1, "SmartWatch");
            ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
                SmartWatch smartWatch = new SmartWatch(rs.getString("productName"), rs.getDouble("productPrice"), rs.getString("productImage"), rs.getString("productManufacturer"), rs.getString("productCondition"), rs.getDouble("productDiscount"), rs.getString("ProductType"), rs.getDouble("manufacturerRebates"), rs.getInt("inventory"));
                hm.put(rs.getString("Id"), smartWatch);
                smartWatch.setId(rs.getString("Id"));
            }
        } catch (Exception e) {
        }
        return hm;
    }

    public static HashMap<String, Headphone> getHeadphone() {
        HashMap<String, Headphone> hm = new HashMap<String, Headphone>();
        try {
            getConnection();

            String selectHeadphone = "select * from  Productdetails where ProductType=?";
            PreparedStatement pst = conn.prepareStatement(selectHeadphone);
            pst.setString(1, "Headphone");
            ResultSet rs = pst.executeQuery();

            while (rs.next()) {
                Headphone headphone = new Headphone(rs.getString("productName"), rs.getDouble("productPrice"), rs.getString("productImage"), rs.getString("productManufacturer"), rs.getString("productCondition"), rs.getDouble("productDiscount"), rs.getString("ProductType"), rs.getDouble("manufacturerRebates"), rs.getInt("inventory"));
                hm.put(rs.getString("Id"), headphone);
                headphone.setId(rs.getString("Id"));
            }
        } catch (Exception e) {
        }
        return hm;
    }

    public static HashMap<String, VirtualReality> getVirtualReality() {
        HashMap<String, VirtualReality> hm = new HashMap<String, VirtualReality>();
        try {
            getConnection();

            String selectVirtualReality = "select * from  Productdetails where ProductType=?";
            PreparedStatement pstmt = conn.prepareStatement(selectVirtualReality);
            pstmt.setString(1, "VirtualReality");
            ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
                VirtualReality virtualReality = new VirtualReality(rs.getString("productName"), rs.getDouble("productPrice"), rs.getString("productImage"), rs.getString("productManufacturer"), rs.getString("productCondition"), rs.getDouble("productDiscount"), rs.getString("ProductType"), rs.getDouble("manufacturerRebates"), rs.getInt("inventory"));
                hm.put(rs.getString("Id"), virtualReality);
                virtualReality.setId(rs.getString("Id"));
            }
        } catch (Exception e) {
        }
        return hm;
    }

    public static HashMap<String, PetTracker> getPetTracker() {
        HashMap<String, PetTracker> hm = new HashMap<String, PetTracker>();
        try {
            getConnection();

            String selectPetTracker = "select * from  Productdetails where ProductType=?";
            PreparedStatement pstmt = conn.prepareStatement(selectPetTracker);
            pstmt.setString(1, "PetTracker");
            ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
                PetTracker petTracker = new PetTracker(rs.getString("productName"), rs.getDouble("productPrice"), rs.getString("productImage"), rs.getString("productManufacturer"), rs.getString("productCondition"), rs.getDouble("productDiscount"), rs.getString("ProductType"), rs.getDouble("manufacturerRebates"), rs.getInt("inventory"));
                hm.put(rs.getString("Id"), petTracker);
                petTracker.setId(rs.getString("Id"));
            }
        } catch (Exception e) {
        }
        return hm;
    }

    public static HashMap<String, Accessory> getAccessory() {
        HashMap<String, Accessory> hm = new HashMap<String, Accessory>();
        try {
            getConnection();

            String selectAcc = "select * from  Productdetails where ProductType=?";
            PreparedStatement pstmt = conn.prepareStatement(selectAcc);
            pstmt.setString(1, "Accessory");
            ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
                Accessory acc = new Accessory(rs.getString("productName"), rs.getDouble("productPrice"), rs.getString("productImage"), rs.getString("productManufacturer"), rs.getString("productCondition"), rs.getDouble("productDiscount"), rs.getString("ProductType"), rs.getDouble("manufacturerRebates"), rs.getInt("inventory"));
                hm.put(rs.getString("Id"), acc);
                acc.setId(rs.getString("Id"));
                //		System.out.println(rs.getString("Id"));
            }
        } catch (Exception e) {
        }
        return hm;
    }

    public static HashMap<String, CustomerAddress> getStoreLocation() {
        HashMap<String, CustomerAddress> hm = new HashMap<String, CustomerAddress>();
        try {
            getConnection();

            String selectLoc = "select * from  StoreLocation";
            PreparedStatement pstmt = conn.prepareStatement(selectLoc);
            ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
                CustomerAddress customerAddress = new CustomerAddress(rs.getString("street"), rs.getString("city"), rs.getString("state"), rs.getString("zipCode"));
                hm.put(rs.getString("StoreID"), customerAddress);
            }
        } catch (Exception e) {
        }
        return hm;
    }

    public static HashMap<String, Integer> getUser_id() {
        HashMap<String, Integer> hm = new HashMap();
        try {
            getConnection();

            String selectAcc = "select * from  Registration";
            PreparedStatement pstmt = conn.prepareStatement(selectAcc);
            ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
                hm.put(rs.getString("username"), rs.getInt("user_id"));
            }
        } catch (Exception e) {
        }
        return hm;
    }

    public static HashMap<String, OrderPayment> selectSaleAmount() {
        HashMap<String, OrderPayment> hm = new HashMap<String, OrderPayment>();
        try {
            getConnection();

            String selectAcc = "select ProductId,OrderPrice,sum(OrderQuantity) as SalesAmount,sum(TotalSales) as OrderTotal from CustomerOrders group by ProductId, OrderPrice";
            PreparedStatement pst = conn.prepareStatement(selectAcc);
            ResultSet rs = pst.executeQuery();

            int i = 0;
            while (rs.next()) {
                OrderPayment orderPayment = new OrderPayment(rs.getString("ProductId"), rs.getDouble("OrderPrice"), rs.getInt("SalesAmount"), rs.getDouble("OrderTotal"));
                i++;
                hm.put(String.valueOf(i), orderPayment);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return hm;
    }

    public static HashMap<String, OrderPayment> selectDailyTransaction() {
        HashMap<String, OrderPayment> hm = new HashMap<String, OrderPayment>();
        try {
            getConnection();

            String selectAcc = "SELECT PurchaseDate ,sum(TotalSales) as OrderTotal from CustomerOrders group by PurchaseDate";
            PreparedStatement pst = conn.prepareStatement(selectAcc);
            ResultSet rs = pst.executeQuery();

            int i = 0;
            while (rs.next()) {
                OrderPayment orderPayment = new OrderPayment(rs.getDate("PurchaseDate"), rs.getDouble("OrderTotal"));
                i++;
                hm.put(String.valueOf(i), orderPayment);
            }
        } catch (Exception e) {
        }
        return hm;
    }

    public static HashMap<String, Product> selectInventory() {
        HashMap<String, Product> hm = new HashMap<String, Product>();
        try {
            getConnection();

            String selectAcc = "select * from Productdetails";
            PreparedStatement pst = conn.prepareStatement(selectAcc);
            ResultSet rs = pst.executeQuery();

            while (rs.next()) {
                Product product = new Product(rs.getString("productName"), rs.getDouble("productPrice"), Integer.parseInt(rs.getString("inventory")));
                hm.put(rs.getString("Id"), product);
                product.setId(rs.getString("Id"));
            }
        } catch (Exception e) {
        }
        return hm;
    }

    public static HashMap<String, Product> selectOnSale() {
        HashMap<String, Product> hm = new HashMap<String, Product>();
        try {
            getConnection();

            String selectAcc = "select * from Productdetails where productDiscount > 0";
            PreparedStatement pst = conn.prepareStatement(selectAcc);
            ResultSet rs = pst.executeQuery();

            while (rs.next()) {
                Product product = new Product(rs.getString("productName"), rs.getDouble("productPrice"), Double.parseDouble(rs.getString("productDiscount")));
                hm.put(rs.getString("Id"), product);
                product.setId(rs.getString("Id"));
            }
        } catch (Exception e) {
        }
        return hm;
    }

    public static HashMap<String, Product> selectRebate() {
        HashMap<String, Product> hm = new HashMap<String, Product>();
        try {
            getConnection();

            String selectAcc = "select * from Productdetails where manufacturerRebates > 0";
            PreparedStatement pst = conn.prepareStatement(selectAcc);
            ResultSet rs = pst.executeQuery();

            while (rs.next()) {
                Product product = new Product(rs.getString("productName"), rs.getDouble("productPrice"), Double.parseDouble(rs.getString("manufacturerRebates")));
                hm.put(rs.getString("Id"), product);
                product.setId(rs.getString("Id"));
            }
        } catch (Exception e) {
        }
        return hm;
    }

    public static void insert() {
        try {

            getConnection();


            String truncatetableacc = "delete from Product_accessories;";
            PreparedStatement pstt = conn.prepareStatement(truncatetableacc);
            pstt.executeUpdate();

            String truncatetableprod = "delete from  Productdetails;";
            PreparedStatement psttprod = conn.prepareStatement(truncatetableprod);
            psttprod.executeUpdate();

            String insertProductQuery = "INSERT INTO  Productdetails(ProductType,Id,productName,productPrice,productImage,productManufacturer,productCondition,productDiscount,manufacturerRebates,inventory)" +
                    "VALUES (?,?,?,?,?,?,?,?,?,?);";

            for (Map.Entry<String, Accessory> entry : SaxParserDataStore.accessories.entrySet()) {
                String name = "Accessory";
                Accessory acc = entry.getValue();

                PreparedStatement pst = conn.prepareStatement(insertProductQuery);
                pst.setString(1, name);
                pst.setString(2, acc.getId());
                pst.setString(3, acc.getName());
                pst.setDouble(4, acc.getPrice());
                pst.setString(5, acc.getImage());
                pst.setString(6, acc.getRetailer());
                pst.setString(7, acc.getCondition());
                pst.setDouble(8, acc.getDiscount());
                pst.setDouble(9, acc.getRebates());
                pst.setInt(10, acc.getInventory());

                pst.executeUpdate();
            }

            for (Map.Entry<String, FitnessWatch> entry : SaxParserDataStore.fitnesses.entrySet()) {
                String name = "FitnessWatch";
                FitnessWatch fitnessWatch = entry.getValue();

                PreparedStatement pst = conn.prepareStatement(insertProductQuery);
                pst.setString(1, name);
                pst.setString(2, fitnessWatch.getId());
                pst.setString(3, fitnessWatch.getName());
                pst.setDouble(4, fitnessWatch.getPrice());
                pst.setString(5, fitnessWatch.getImage());
                pst.setString(6, fitnessWatch.getRetailer());
                pst.setString(7, fitnessWatch.getCondition());
                pst.setDouble(8, fitnessWatch.getDiscount());
                pst.setDouble(9, fitnessWatch.getRebates());
                pst.setInt(10, fitnessWatch.getInventory());

                pst.executeUpdate();
            }

            for (Map.Entry<String, Headphone> entry : SaxParserDataStore.headphones.entrySet()) {
                String name = "Headphone";
                Headphone headphone = entry.getValue();

                PreparedStatement pst = conn.prepareStatement(insertProductQuery);
                pst.setString(1, name);
                pst.setString(2, headphone.getId());
                pst.setString(3, headphone.getName());
                pst.setDouble(4, headphone.getPrice());
                pst.setString(5, headphone.getImage());
                pst.setString(6, headphone.getRetailer());
                pst.setString(7, headphone.getCondition());
                pst.setDouble(8, headphone.getDiscount());
                pst.setDouble(9, headphone.getRebates());
                pst.setInt(10, headphone.getInventory());

                pst.executeUpdate();


            }

            for (Map.Entry<String, Laptop> entry : SaxParserDataStore.laptops.entrySet()) {
                String name = "Laptop";
                Laptop laptop = entry.getValue();

                PreparedStatement pst = conn.prepareStatement(insertProductQuery);
                pst.setString(1, name);
                pst.setString(2, laptop.getId());
                pst.setString(3, laptop.getName());
                pst.setDouble(4, laptop.getPrice());
                pst.setString(5, laptop.getImage());
                pst.setString(6, laptop.getRetailer());
                pst.setString(7, laptop.getCondition());
                pst.setDouble(8, laptop.getDiscount());
                pst.setDouble(9, laptop.getRebates());
                pst.setInt(10, laptop.getInventory());

                pst.executeUpdate();


            }

            for (Map.Entry<String, PetTracker> entry : SaxParserDataStore.pets.entrySet()) {
                String name = "PetTracker";
                PetTracker petTracker = entry.getValue();

                PreparedStatement pst = conn.prepareStatement(insertProductQuery);
                pst.setString(1, name);
                pst.setString(2, petTracker.getId());
                pst.setString(3, petTracker.getName());
                pst.setDouble(4, petTracker.getPrice());
                pst.setString(5, petTracker.getImage());
                pst.setString(6, petTracker.getRetailer());
                pst.setString(7, petTracker.getCondition());
                pst.setDouble(8, petTracker.getDiscount());
                pst.setDouble(9, petTracker.getRebates());
                pst.setInt(10, petTracker.getInventory());

                pst.executeUpdate();


            }

            for (Map.Entry<String, Phone> entry : SaxParserDataStore.phones.entrySet()) {
                String name = "Phone";
                Phone phone = entry.getValue();

                PreparedStatement pst = conn.prepareStatement(insertProductQuery);
                pst.setString(1, name);
                pst.setString(2, phone.getId());
                pst.setString(3, phone.getName());
                pst.setDouble(4, phone.getPrice());
                pst.setString(5, phone.getImage());
                pst.setString(6, phone.getRetailer());
                pst.setString(7, phone.getCondition());
                pst.setDouble(8, phone.getDiscount());
                pst.setDouble(9, phone.getRebates());
                pst.setInt(10, phone.getInventory());

                pst.executeUpdate();

                try {
                    HashMap<String, String> acc = phone.getAccessories();
                    String insertAccessoryQuery = "INSERT INTO Product_accessories(productName,accessoriesName)" +
                            "VALUES (?,?);";
                    for (Map.Entry<String, String> accentry : acc.entrySet()) {
                        PreparedStatement pstacc = conn.prepareStatement(insertAccessoryQuery);
                        pstacc.setString(1, phone.getId());
                        pstacc.setString(2, accentry.getValue());
                        pstacc.executeUpdate();
                    }
                } catch (Exception et) {
                    et.printStackTrace();
                }
            }

            for (Map.Entry<String, SmartWatch> entry : SaxParserDataStore.smarts.entrySet()) {
                String name = "SmartWatch";
                SmartWatch smartWatch = entry.getValue();

                PreparedStatement pst = conn.prepareStatement(insertProductQuery);
                pst.setString(1, name);
                pst.setString(2, smartWatch.getId());
                pst.setString(3, smartWatch.getName());
                pst.setDouble(4, smartWatch.getPrice());
                pst.setString(5, smartWatch.getImage());
                pst.setString(6, smartWatch.getRetailer());
                pst.setString(7, smartWatch.getCondition());
                pst.setDouble(8, smartWatch.getDiscount());
                pst.setDouble(9, smartWatch.getRebates());
                pst.setInt(10, smartWatch.getInventory());

                pst.executeUpdate();
            }

            for (Map.Entry<String, SoundSystem> entry : SaxParserDataStore.sounds.entrySet()) {
                String name = "SoundSystem";
                SoundSystem soundSystem = entry.getValue();

                PreparedStatement pst = conn.prepareStatement(insertProductQuery);
                pst.setString(1, name);
                pst.setString(2, soundSystem.getId());
                pst.setString(3, soundSystem.getName());
                pst.setDouble(4, soundSystem.getPrice());
                pst.setString(5, soundSystem.getImage());
                pst.setString(6, soundSystem.getRetailer());
                pst.setString(7, soundSystem.getCondition());
                pst.setDouble(8, soundSystem.getDiscount());
                pst.setDouble(9, soundSystem.getRebates());
                pst.setInt(10, soundSystem.getInventory());

                pst.executeUpdate();
            }

            for (Map.Entry<String, TV> entry : SaxParserDataStore.tvs.entrySet()) {
                String name = "TV";
                TV tv = entry.getValue();

                PreparedStatement pst = conn.prepareStatement(insertProductQuery);
                pst.setString(1, name);
                pst.setString(2, tv.getId());
                pst.setString(3, tv.getName());
                pst.setDouble(4, tv.getPrice());
                pst.setString(5, tv.getImage());
                pst.setString(6, tv.getRetailer());
                pst.setString(7, tv.getCondition());
                pst.setDouble(8, tv.getDiscount());
                pst.setDouble(9, tv.getRebates());
                pst.setInt(10, tv.getInventory());

                pst.executeUpdate();
            }

            for (Map.Entry<String, VirtualReality> entry : SaxParserDataStore.virtuals.entrySet()) {
                String name = "VirtualReality";
                VirtualReality virtualReality = entry.getValue();

                PreparedStatement pst = conn.prepareStatement(insertProductQuery);
                pst.setString(1, name);
                pst.setString(2, virtualReality.getId());
                pst.setString(3, virtualReality.getName());
                pst.setDouble(4, virtualReality.getPrice());
                pst.setString(5, virtualReality.getImage());
                pst.setString(6, virtualReality.getRetailer());
                pst.setString(7, virtualReality.getCondition());
                pst.setDouble(8, virtualReality.getDiscount());
                pst.setDouble(9, virtualReality.getRebates());
                pst.setInt(10, virtualReality.getInventory());

                pst.executeUpdate();
            }

            for (Map.Entry<String, VoiceAssistant> entry : SaxParserDataStore.voices.entrySet()) {
                String name = "VoiceAssistant";
                VoiceAssistant voiceAssistant = entry.getValue();

                PreparedStatement pst = conn.prepareStatement(insertProductQuery);
                pst.setString(1, name);
                pst.setString(2, voiceAssistant.getId());
                pst.setString(3, voiceAssistant.getName());
                pst.setDouble(4, voiceAssistant.getPrice());
                pst.setString(5, voiceAssistant.getImage());
                pst.setString(6, voiceAssistant.getRetailer());
                pst.setString(7, voiceAssistant.getCondition());
                pst.setDouble(8, voiceAssistant.getDiscount());
                pst.setDouble(9, voiceAssistant.getRebates());
                pst.setInt(10, voiceAssistant.getInventory());

                pst.executeUpdate();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void insertProduct(String productType, String id, String productName, double productPrice, String productImage, String retailer, String condition,
                                     double discount, double rebates, int inventory) {
        try {
            getConnection();
            String insertIntoCustomerOrderQuery = "INSERT INTO  Productdetails(ProductType,Id,productName,productPrice,productImage,productManufacturer,productCondition,productDiscount,manufacturerRebates,inventory)" +
                    "VALUES (?,?,?,?,?,?,?,?,?,?);";
            PreparedStatement pst = conn.prepareStatement(insertIntoCustomerOrderQuery);
            //set the parameter for each column and execute the prepared statement
            pst.setString(1, productType);
            pst.setString(2, id);
            pst.setString(3, productName);
            pst.setDouble(4, productPrice);
            pst.setString(5, productImage);
            pst.setString(6, retailer);
            pst.setString(7, condition);
            pst.setDouble(8, discount);
            pst.setDouble(9, rebates);
            pst.setInt(10, inventory);
            pst.execute();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void deleteProduct(String id) {
        try {
            getConnection();
            String deleteOrderQuery = "Delete from Productdetails where id=?";
            PreparedStatement pst = conn.prepareStatement(deleteOrderQuery);
            pst.setString(1, id);
            pst.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void insertTransactions(int login_id, String customerName, String customerAge, String customerOccupation, String creditCardNo, int orderId, Date d, Date expectedDate, Date actualDate, String productID, String name, String category, String retailer, int review, String delivery_tracking_id, String deliveryType, String zipCode, String status, String orderReturn, String onTime) {
        try {
            java.sql.Date PurchaseDate = new java.sql.Date(d.getTime());
            java.sql.Date ShipDate = new java.sql.Date(expectedDate.getTime());
            java.sql.Date ActualDate = new java.sql.Date(actualDate.getTime());

            getConnection();
            String insertIntoCustomerOrderQuery = "INSERT INTO Transactions(login_ID,Customer_Name, Customer_Age,Customer_Occupation, " +
                    "Credit_card,Order_ID,Order_Date,Expected_Date,Actual_Date,Product_ID,Product_Name,Category,Manufacturer, " +
                    "Review_Rating, Delivery_Tracking_ID, Delivery_Type, Delivery_Zip, Transactions_Status, Order_Returned,Delivery_on_Time) "
                    + "VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
            PreparedStatement pst = conn.prepareStatement(insertIntoCustomerOrderQuery);
            //set the parameter for each column and execute the prepared statement
            pst.setInt(1, login_id);
            pst.setString(2, customerName);
            pst.setInt(3, Integer.parseInt(customerAge));
            pst.setString(4, customerOccupation);
            pst.setString(5, creditCardNo);
            pst.setInt(6, orderId);
            pst.setDate(7, PurchaseDate);
            pst.setDate(8, ShipDate);
            pst.setDate(9, ActualDate);
            pst.setString(10, productID);
            pst.setString(11, name);
            pst.setString(12, category);
            pst.setString(13, retailer);
            pst.setInt(14, review);
            pst.setString(15, delivery_tracking_id);
            pst.setString(16, deliveryType);
            pst.setString(17, zipCode);
            pst.setString(18, status);
            pst.setString(19, orderReturn);
            pst.setString(20, onTime);
            pst.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}