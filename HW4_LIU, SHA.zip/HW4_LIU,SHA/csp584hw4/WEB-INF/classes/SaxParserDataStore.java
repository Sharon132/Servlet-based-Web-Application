
/*********


 http://www.saxproject.org/

 SAX is the Simple API for XML, originally a Java-only API.
 SAX was the first widely adopted API for XML in Java, and is a �de facto� standard.
 The current version is SAX 2.0.1, and there are versions for several programming language environments other than Java.

 The following URL from Oracle is the JAVA documentation for the API

 https://docs.oracle.com/javase/7/docs/api/org/xml/sax/helpers/DefaultHandler.html
 *********/

import java.io.IOException;
import java.util.*;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;


////////////////////////////////////////////////////////////

/**************

 SAX parser use callback function  to notify client object of the XML document structure.
 You should extend DefaultHandler and override the method when parsin the XML document
 ***************/

////////////////////////////////////////////////////////////

public class SaxParserDataStore extends DefaultHandler {
    TV tv;
    SoundSystem sound;
    static Phone phone;
    Laptop laptop;
    VoiceAssistant voice;
    FitnessWatch fitness;
    SmartWatch smart;
    Headphone headphone;
    VirtualReality virtual;
    PetTracker pet;
    Accessory accessory;

    static HashMap<String, TV> tvs;
    static HashMap<String, SoundSystem> sounds;
    static HashMap<String, Phone> phones;
    static HashMap<String, Laptop> laptops;
    static HashMap<String, VoiceAssistant> voices;
    static HashMap<String, FitnessWatch> fitnesses;
    static HashMap<String, SmartWatch> smarts;
    static HashMap<String, Headphone> headphones;
    static HashMap<String, VirtualReality> virtuals;
    static HashMap<String, PetTracker> pets;
    static HashMap<String, Accessory> accessories;


    static HashMap<String, String> accessoryHashMap;//保存一个商品对应的配件

    String consoleXmlFileName;
    String elementValueRead;
    String currentElement = "";

    public SaxParserDataStore() {
    }

    public SaxParserDataStore(String consoleXmlFileName) {
        this.consoleXmlFileName = consoleXmlFileName;
        tvs = new HashMap<String, TV>();
        sounds = new HashMap<String, SoundSystem>();
        phones = new HashMap<String, Phone>();
        laptops = new HashMap<String, Laptop>();
        voices = new HashMap<String, VoiceAssistant>();
        fitnesses = new HashMap<String, FitnessWatch>();
        smarts = new HashMap<String, SmartWatch>();
        headphones = new HashMap<String, Headphone>();
        virtuals = new HashMap<String, VirtualReality>();
        pets = new HashMap<String, PetTracker>();
        accessories = new HashMap<String, Accessory>();

        accessoryHashMap = new HashMap<String, String>();
        parseDocument();
    }

    //parse the xml using sax parser to get the data
    private void parseDocument() {
        SAXParserFactory factory = SAXParserFactory.newInstance();
        try {
            SAXParser parser = factory.newSAXParser();
            parser.parse(consoleXmlFileName, this);
        } catch (ParserConfigurationException e) {
            System.out.println("ParserConfig error");
        } catch (SAXException e) {
            System.out.println("SAXException : xml not well formed");
        } catch (IOException e) {
            System.out.println("IO error");
            System.out.println(e.getMessage());
        }
    }

////////////////////////////////////////////////////////////

    /*************

     There are a number of methods to override in SAX handler  when parsing your XML document :

     Group 1. startDocument() and endDocument() :  Methods that are called at the start and end of an XML document.
     Group 2. startElement() and endElement() :  Methods that are called  at the start and end of a document element.
     Group 3. characters() : Method that is called with the text content in between the start and end tags of an XML document element.


     There are few other methods that you could use for notification for different purposes, check the API at the following URL:

     https://docs.oracle.com/javase/7/docs/api/org/xml/sax/helpers/DefaultHandler.html
     ***************/

////////////////////////////////////////////////////////////

    // when xml start element is parsed store the id into respective hashmap for console,games etc
    @Override
    public void startElement(String str1, String str2, String elementName, Attributes attributes) throws SAXException {

        if (elementName.equalsIgnoreCase("tv")) {
            currentElement = "tv";
            tv = new TV();
            tv.setId(attributes.getValue("id"));
        }
        if (elementName.equalsIgnoreCase("sound")) {
            currentElement = "sound";
            sound = new SoundSystem();
            sound.setId(attributes.getValue("id"));
        }
        if (elementName.equalsIgnoreCase("phone")) {
            currentElement = "phone";
            phone = new Phone();
            phone.setId(attributes.getValue("id"));
        }
        if (elementName.equalsIgnoreCase("laptop")) {
            currentElement = "laptop";
            laptop = new Laptop();
            laptop.setId(attributes.getValue("id"));
        }
        if (elementName.equalsIgnoreCase("voice")) {
            currentElement = "voice";
            voice = new VoiceAssistant();
            voice.setId(attributes.getValue("id"));
        }
        if (elementName.equals("fitness")) {
            currentElement = "fitness";
            fitness = new FitnessWatch();
            fitness.setId(attributes.getValue("id"));
        }
        if (elementName.equals("smart")) {
            currentElement = "smart";
            smart = new SmartWatch();
            smart.setId(attributes.getValue("id"));
        }
        if (elementName.equals("headphone")) {
            currentElement = "headphone";
            headphone = new Headphone();
            headphone.setId(attributes.getValue("id"));
        }
        if (elementName.equals("virtual")) {
            currentElement = "virtual";
            virtual = new VirtualReality();
            virtual.setId(attributes.getValue("id"));
        }
        if (elementName.equals("pet")) {
            currentElement = "pet";
            pet = new PetTracker();
            pet.setId(attributes.getValue("id"));
        }

        if (elementName.equals("accessory") && !currentElement.equals("phone")) {
            currentElement = "accessory";
            accessory = new Accessory();
            accessory.setId(attributes.getValue("id"));
        }
    }

    // when xml end element is parsed store the data into respective hashmap for console,games etc respectively
    @Override
    public void endElement(String str1, String str2, String element) throws SAXException {

        if (element.equals("tv")) {
            tvs.put(tv.getId(), tv);
            return;
        }

        if (element.equals("sound")) {
            sounds.put(sound.getId(), sound);
            return;
        }
        if (element.equals("phone")) {
            phones.put(phone.getId(), phone);
            return;
        }
        if (element.equals("laptop")) {
            laptops.put(laptop.getId(), laptop);
            return;
        }
        if (element.equals("voice")) {
            voices.put(voice.getId(), voice);
            return;
        }
        if (element.equals("fitness")) {
            fitnesses.put(fitness.getId(), fitness);
            return;
        }
        if (element.equals("smart")) {
            smarts.put(smart.getId(), smart);
            return;
        }
        if (element.equals("headphone")) {
            headphones.put(headphone.getId(), headphone);
            return;
        }
        if (element.equals("virtual")) {
            virtuals.put(virtual.getId(), virtual);
            return;
        }
        if (element.equals("pet")) {
            pets.put(pet.getId(), pet);
            return;
        }
        if (element.equals("accessory") && currentElement.equals("accessory")) {
            accessories.put(accessory.getId(), accessory);
            System.out.println("id: " + accessory.getId());
            return;
        }
        if (element.equals("accessory") && currentElement.equals("phone")) {
            accessoryHashMap.put(elementValueRead, elementValueRead);
        }
        if (element.equalsIgnoreCase("accessories") && currentElement.equals("phone")) {
            phone.setAccessories(accessoryHashMap);
            accessoryHashMap = new HashMap<>();
            return;
        }



        if (element.equalsIgnoreCase("image")) {
            if (currentElement.equals("tv"))
                tv.setImage(elementValueRead);
            if (currentElement.equals("sound"))
                sound.setImage(elementValueRead);
            if (currentElement.equals("phone"))
                phone.setImage(elementValueRead);
            if (currentElement.equals("laptop"))
                laptop.setImage(elementValueRead);
            if (currentElement.equals("voice"))
                voice.setImage(elementValueRead);
            if (currentElement.equals("fitness"))
                fitness.setImage(elementValueRead);
            if (currentElement.equals("smart"))
                smart.setImage(elementValueRead);
            if (currentElement.equals("headphone"))
                headphone.setImage(elementValueRead);
            if (currentElement.equals("virtual"))
                virtual.setImage(elementValueRead);
            if (currentElement.equals("pet"))
                pet.setImage(elementValueRead);
            if (currentElement.equals("accessory"))
                accessory.setImage(elementValueRead);
            return;
        }


        if (element.equalsIgnoreCase("discount")) {
            if (currentElement.equals("tv"))
                tv.setDiscount(Double.parseDouble(elementValueRead));
            if (currentElement.equals("sound"))
                sound.setDiscount(Double.parseDouble(elementValueRead));
            if (currentElement.equals("phone"))
                phone.setDiscount(Double.parseDouble(elementValueRead));
            if (currentElement.equals("laptop"))
                laptop.setDiscount(Double.parseDouble(elementValueRead));
            if (currentElement.equals("voice"))
                voice.setDiscount(Double.parseDouble(elementValueRead));
            if (currentElement.equals("fitness"))
                fitness.setDiscount(Double.parseDouble(elementValueRead));
            if (currentElement.equals("smart"))
                smart.setDiscount(Double.parseDouble(elementValueRead));
            if (currentElement.equals("headphone"))
                headphone.setDiscount(Double.parseDouble(elementValueRead));
            if (currentElement.equals("virtual"))
                virtual.setDiscount(Double.parseDouble(elementValueRead));
            if (currentElement.equals("pet"))
                pet.setDiscount(Double.parseDouble(elementValueRead));
            if (currentElement.equals("accessory"))
                accessory.setDiscount(Double.parseDouble(elementValueRead));
            return;
        }


        if (element.equalsIgnoreCase("condition")) {
            if (currentElement.equals("tv"))
                tv.setCondition(elementValueRead);
            if (currentElement.equals("sound"))
                sound.setCondition(elementValueRead);
            if (currentElement.equals("phone"))
                phone.setCondition(elementValueRead);
            if (currentElement.equals("laptop"))
                laptop.setCondition(elementValueRead);
            if (currentElement.equals("voice"))
                voice.setCondition(elementValueRead);
            if (currentElement.equals("fitness"))
                fitness.setCondition(elementValueRead);
            if (currentElement.equals("smart"))
                smart.setCondition(elementValueRead);
            if (currentElement.equals("headphone"))
                headphone.setCondition(elementValueRead);
            if (currentElement.equals("virtual"))
                virtual.setCondition(elementValueRead);
            if (currentElement.equals("pet"))
                pet.setCondition(elementValueRead);
            if (currentElement.equals("accessory"))
                accessory.setCondition(elementValueRead);
            return;
        }

        if (element.equalsIgnoreCase("manufacturer")) {
            if (currentElement.equals("tv"))
                tv.setRetailer(elementValueRead);
            if (currentElement.equals("sound"))
                sound.setRetailer(elementValueRead);
            if (currentElement.equals("phone"))
                phone.setRetailer(elementValueRead);
            if (currentElement.equals("laptop"))
                laptop.setRetailer(elementValueRead);
            if (currentElement.equals("voice"))
                voice.setRetailer(elementValueRead);
            if (currentElement.equals("fitness"))
                fitness.setRetailer(elementValueRead);
            if (currentElement.equals("smart"))
                smart.setRetailer(elementValueRead);
            if (currentElement.equals("headphone"))
                headphone.setRetailer(elementValueRead);
            if (currentElement.equals("virtual"))
                virtual.setRetailer(elementValueRead);
            if (currentElement.equals("pet"))
                pet.setRetailer(elementValueRead);
            if (currentElement.equals("accessory"))
                accessory.setRetailer(elementValueRead);
            return;
        }

        if (element.equalsIgnoreCase("name")) {
            if (currentElement.equals("tv"))
                tv.setName(elementValueRead);
            if (currentElement.equals("sound"))
                sound.setName(elementValueRead);
            if (currentElement.equals("phone"))
                phone.setName(elementValueRead);
            if (currentElement.equals("laptop"))
                laptop.setName(elementValueRead);
            if (currentElement.equals("voice"))
                voice.setName(elementValueRead);
            if (currentElement.equals("fitness"))
                fitness.setName(elementValueRead);
            if (currentElement.equals("smart"))
                smart.setName(elementValueRead);
            if (currentElement.equals("headphone"))
                headphone.setName(elementValueRead);
            if (currentElement.equals("virtual"))
                virtual.setName(elementValueRead);
            if (currentElement.equals("pet"))
                pet.setName(elementValueRead);
            if (currentElement.equals("accessory"))
                accessory.setName(elementValueRead);
            return;
        }

        if (element.equalsIgnoreCase("price")) {
            if (currentElement.equals("tv"))
                tv.setPrice(Double.parseDouble(elementValueRead));
            if (currentElement.equals("sound"))
                sound.setPrice(Double.parseDouble(elementValueRead));
            if (currentElement.equals("phone"))
                phone.setPrice(Double.parseDouble(elementValueRead));
            if (currentElement.equals("laptop"))
                laptop.setPrice(Double.parseDouble(elementValueRead));
            if (currentElement.equals("voice"))
                voice.setPrice(Double.parseDouble(elementValueRead));
            if (currentElement.equals("fitness"))
                fitness.setPrice(Double.parseDouble(elementValueRead));
            if (currentElement.equals("smart"))
                smart.setPrice(Double.parseDouble(elementValueRead));
            if (currentElement.equals("headphone"))
                headphone.setPrice(Double.parseDouble(elementValueRead));
            if (currentElement.equals("virtual"))
                virtual.setPrice(Double.parseDouble(elementValueRead));
            if (currentElement.equals("pet"))
                pet.setPrice(Double.parseDouble(elementValueRead));
            if (currentElement.equals("accessory"))
                accessory.setPrice(Double.parseDouble(elementValueRead));
            return;
        }

        if (element.equalsIgnoreCase("rebates")) {
            if (currentElement.equals("tv"))
                tv.setRebates(Double.parseDouble(elementValueRead));
            if (currentElement.equals("sound"))
                sound.setRebates(Double.parseDouble(elementValueRead));
            if (currentElement.equals("phone"))
                phone.setRebates(Double.parseDouble(elementValueRead));
            if (currentElement.equals("laptop"))
                laptop.setRebates(Double.parseDouble(elementValueRead));
            if (currentElement.equals("voice"))
                voice.setRebates(Double.parseDouble(elementValueRead));
            if (currentElement.equals("fitness"))
                fitness.setRebates(Double.parseDouble(elementValueRead));
            if (currentElement.equals("smart"))
                smart.setRebates(Double.parseDouble(elementValueRead));
            if (currentElement.equals("headphone"))
                headphone.setRebates(Double.parseDouble(elementValueRead));
            if (currentElement.equals("virtual"))
                virtual.setRebates(Double.parseDouble(elementValueRead));
            if (currentElement.equals("pet"))
                pet.setRebates(Double.parseDouble(elementValueRead));
            if (currentElement.equals("accessory"))
                accessory.setRebates(Double.parseDouble(elementValueRead));
            return;
        }

        if (element.equalsIgnoreCase("inventory")) {
            if (currentElement.equals("tv"))
                tv.setInventory(Integer.parseInt(elementValueRead));
            if (currentElement.equals("sound"))
                sound.setInventory(Integer.parseInt(elementValueRead));
            if (currentElement.equals("phone"))
                phone.setInventory(Integer.parseInt(elementValueRead));
            if (currentElement.equals("laptop"))
                laptop.setInventory(Integer.parseInt(elementValueRead));
            if (currentElement.equals("voice"))
                voice.setInventory(Integer.parseInt(elementValueRead));
            if (currentElement.equals("fitness"))
                fitness.setInventory(Integer.parseInt(elementValueRead));
            if (currentElement.equals("smart"))
                smart.setInventory(Integer.parseInt(elementValueRead));
            if (currentElement.equals("headphone"))
                headphone.setInventory(Integer.parseInt(elementValueRead));
            if (currentElement.equals("virtual"))
                virtual.setInventory(Integer.parseInt(elementValueRead));
            if (currentElement.equals("pet"))
                pet.setInventory(Integer.parseInt(elementValueRead));
            if (currentElement.equals("accessory"))
                accessory.setInventory(Integer.parseInt(elementValueRead));
            return;
        }

    }

    //get each element in xml tag
    @Override
    public void characters(char[] content, int begin, int end) throws SAXException {
        elementValueRead = new String(content, begin, end);
    }



    /////////////////////////////////////////
    // 	     Kick-Start SAX in main       //
    ////////////////////////////////////////
//    }
    public static void addHashmap() {
        String TOMCAT_HOME = System.getProperty("catalina.home");
        new SaxParserDataStore(TOMCAT_HOME+"/webapps/csp584hw4/ProductCatalog.xml");


//        tvs = MySqlDataStoreUtilities.getTV();
//        sounds= MySqlDataStoreUtilities.getSoundSystem();
//        phones = MySqlDataStoreUtilities.getPhoneAcc();
//        laptops=MySqlDataStoreUtilities.getLaptop();
//        voices = MySqlDataStoreUtilities.getVoiceAssistant();
//        fitnesses = MySqlDataStoreUtilities.getFitnessWatch();
//        smarts = MySqlDataStoreUtilities.getSmartWatch();
//        headphones = MySqlDataStoreUtilities.getHeadphone();
//        virtuals = MySqlDataStoreUtilities.getVirtualReality();
//        pets = MySqlDataStoreUtilities.getPetTracker();
//        accessories = MySqlDataStoreUtilities.getAccessory();
//        accessoryHashMap = phone.getAccessories();
    }
}
