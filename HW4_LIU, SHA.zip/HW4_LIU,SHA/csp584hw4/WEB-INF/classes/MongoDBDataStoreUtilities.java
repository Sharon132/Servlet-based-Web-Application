import com.mongodb.*;
import com.mongodb.client.MongoDatabase;

import java.util.*;

public class MongoDBDataStoreUtilities {
    static DBCollection myReviews;

    public static DBCollection getConnection() {
        MongoClient mongo;
        mongo = new MongoClient("localhost", 27017);

        DB db = mongo.getDB("CustomerReviews");
        myReviews = db.getCollection("myReviews");
        return myReviews;
    }

    public static void main(String[] args) {

        try {
            MongoClient mongoClient = new MongoClient("localhost", 27017);
            MongoDatabase mongoDatabase = mongoClient.getDatabase("mycol");
            System.out.println("Connect to database successfully");
        } catch (Exception e) {
            System.err.println(e.getClass().getName() + ": " + e.getMessage());
        }
    }


    public static String insertReview(String productname, String producttype, String productPrice, String storeID, String storeZip, String storeCity, String storeState, String productOnSale, String productMaker, String rebate,
                                      String username, String userAge, String userGender, String userOccupation, String Rating, String reviewDate, String reviewText) {
        try {
            getConnection();
            BasicDBObject doc = new BasicDBObject("title", "myReviews").
                    append("ProductModelName", productname).
                    append("ProductType", producttype).
                    append("ProductPrice", (int) Double.parseDouble(productPrice)).

                    append("StoreID", storeID).
                    append("StoreZip", storeZip).
                    append("StoreCity", storeCity).
                    append("StoreState", storeState).
                    append("ProductOnSale", productOnSale).

                    append("ManufacturerName", productMaker).
                    append("ManufacturerRebate", rebate).

                    append("UserName", username).
                    append("UserAge", Integer.parseInt(userAge)).
                    append("UserGender", userGender).
                    append("UserOccupation", userOccupation).

                    append("ReviewRating", Integer.parseInt(Rating)).
                    append("ReviewDate", reviewDate).
                    append("ReviewText", reviewText);
            myReviews.insert(doc);
            return "Successful";
        } catch (Exception e) {
            return "UnSuccessful";
        }

    }

    public static HashMap<String, ArrayList<Review>> selectReview() {
        HashMap<String, ArrayList<Review>> reviews;

        try {

            getConnection();
            DBCursor cursor = myReviews.find();
            reviews = new HashMap();
            while (cursor.hasNext()) {
                //create a query
                BasicDBObject obj = (BasicDBObject) cursor.next();

                if (!reviews.containsKey(obj.getString("ProductModelName"))) {
                    ArrayList<Review> arr = new ArrayList<Review>();
                    reviews.put(obj.getString("ProductModelName"), arr);
                }
                ArrayList<Review> listReview = reviews.get(obj.getString("ProductModelName"));
                Review review = new Review(obj.getString("ProductModelName"), obj.getString("ProductType"), obj.getString("ProductPrice"), obj.getString("StoreID"), obj.getString("StoreZip"),
                        obj.getString("StoreCity"), obj.getString("StoreState"), obj.getString("ProductOnSale"), obj.getString("ManufacturerName"),
                        obj.getString("ManufacturerRebate"), obj.getString("UserName"), obj.getString("UserAge"), obj.getString("UserGender"), obj.getString("UserOccupation"), obj.getString("ReviewRating"), obj.getString("ReviewDate"), obj.getString("ReviewText"));
                //add to review hashmap
                listReview.add(review);

            }
            return reviews;
        } catch (Exception e) {
            reviews = null;
            return reviews;
        }
    }


    public static ArrayList<TrendingBestRating> topProducts() {
        ArrayList<TrendingBestRating> Bestrate = new ArrayList<TrendingBestRating>();
        try {

            getConnection();
            int retlimit = 5;
            DBObject sort = new BasicDBObject();
            sort.put("ReviewRating", -1);
            DBCursor cursor = myReviews.find().limit(retlimit).sort(sort);
            while (cursor.hasNext()) {
                BasicDBObject obj = (BasicDBObject) cursor.next();

                String prodcutnm = obj.get("ProductModelName").toString();
                String rating = obj.get("ReviewRating").toString();
                TrendingBestRating best = new TrendingBestRating(prodcutnm, rating);
                Bestrate.add(best);
            }

        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        return Bestrate;
    }

    public static ArrayList<TrendingMostsoldzip> mostsoldZip() {
        ArrayList<TrendingMostsoldzip> mostsoldzip = new ArrayList<TrendingMostsoldzip>();
        try {
            System.out.println("top5");
            getConnection();
            DBObject groupProducts = new BasicDBObject("_id", "$StoreZip");
            groupProducts.put("count", new BasicDBObject("$sum", 1));

            DBObject group = new BasicDBObject("$group", groupProducts);
            DBObject limit = new BasicDBObject();
            limit = new BasicDBObject("$limit", 5);

            DBObject sortFields = new BasicDBObject("count", -1);
            DBObject sort = new BasicDBObject("$sort", sortFields);
            AggregationOutput output = myReviews.aggregate(group, sort, limit);


            for (DBObject res : output.results()) {
                System.out.println(res);
                String zipcode = (res.get("_id")).toString();
                String count = (res.get("count")).toString();
                TrendingMostsoldzip mostsldzip = new TrendingMostsoldzip(zipcode, count);
                mostsoldzip.add(mostsldzip);
            }
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        return mostsoldzip;
    }

    public static ArrayList<TrendingMostSold> mostsoldProducts() {
        ArrayList<TrendingMostSold> mostsold = new ArrayList<TrendingMostSold>();
        try {
            getConnection();
            DBObject groupProducts = new BasicDBObject("_id", "$ProductModelName");
            groupProducts.put("count", new BasicDBObject("$sum", 1));
            DBObject group = new BasicDBObject("$group", groupProducts);
            DBObject limit = new BasicDBObject();
            limit = new BasicDBObject("$limit", 5);

            DBObject sortFields = new BasicDBObject("count", -1);
            DBObject sort = new BasicDBObject("$sort", sortFields);
            AggregationOutput output = myReviews.aggregate(group, sort, limit);

            for (DBObject res : output.results()) {

                String productName = (res.get("_id")).toString();
                String count = (res.get("count")).toString();
                TrendingMostSold mostsld = new TrendingMostSold(productName, count);
                mostsold.add(mostsld);

            }
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        return mostsold;

    }

    //Get all the reviews grouped by product and zip code;
    public static ArrayList<Review> selectReviewForChart() {

        ArrayList<Review> reviewList = new ArrayList<Review>();
        try {

            getConnection();
            Map<String, Object> dbObjIdMap = new HashMap<String, Object>();
            dbObjIdMap.put("retailerpin", "$retailerpin");
            dbObjIdMap.put("productName", "$productName");
            DBObject groupFields = new BasicDBObject("_id", new BasicDBObject(dbObjIdMap));
            groupFields.put("count", new BasicDBObject("$sum", 1));
            DBObject group = new BasicDBObject("$group", groupFields);

            DBObject projectFields = new BasicDBObject("_id", 0);
            projectFields.put("retailerpin", "$_id");
            projectFields.put("productName", "$productName");
            projectFields.put("reviewCount", "$count");
            DBObject project = new BasicDBObject("$project", projectFields);

            DBObject sort = new BasicDBObject();
            sort.put("reviewCount", -1);

            DBObject orderby = new BasicDBObject();
            orderby = new BasicDBObject("$sort", sort);


            AggregationOutput aggregate = myReviews.aggregate(group, project, orderby);

            for (DBObject result : aggregate.results()) {

                BasicDBObject obj = (BasicDBObject) result;
                Object o = com.mongodb.util.JSON.parse(obj.getString("retailerpin"));
                BasicDBObject dbObj = (BasicDBObject) o;
                Review review = new Review(dbObj.getString("ProductModelName"), dbObj.getString("StoreZip"),
                        obj.getString("reviewCount"), null);
                reviewList.add(review);

            }
            return reviewList;

        } catch (

                Exception e) {
            reviewList = null;

            return reviewList;
        }
    }
}