import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;


//This servlet is only for removing product (function) and update product (html), not include function of updating product.
@WebServlet("/RemoveUpdateProduct")
public class RemoveUpdateProduct extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        response.setContentType("text/html");
        PrintWriter pw = response.getWriter();

        Utilities utility = new Utilities(request, pw);

        String productId = request.getParameter("productId");
        String name = request.getParameter("productName");
        String price = request.getParameter("price");
        String manufacturer = request.getParameter("manufacturer");
        String condition = request.getParameter("condition");
        String discount = request.getParameter("discount");
        String catalog = request.getParameter("catalog");
        String image = request.getParameter("image");
        String rebates = request.getParameter("rebates");
        String inventory = request.getParameter("inventory");

        if (request.getParameter("Product") != null && request.getParameter("Product").equals("Remove")) {
            MySqlDataStoreUtilities.deleteProduct(productId);
            //Remove Product
            if (utility.removeProduct(productId, catalog)) {
                response.sendRedirect("StoreManagerHome");
            }

        } else if (request.getParameter("Product") != null && request.getParameter("Product").equals("Update")) {
            //Update Product

            utility.printHtml("Header.html");
            utility.printHtml("LeftNavigationBar.html");

            pw.print("<div id='content'>");
            pw.print("<div class='post'>");
            pw.print("<h3 class='title'>");
            pw.print("Update product");
            pw.print("</h3>");
            pw.print("<div class='entry'>");


            //显示更新product的表格
            pw.print("<form action='UpdateProduct' method='post'");
            pw.print("<table style='width:100%'><tr><td>");

            pw.print("<h4>Product ID: </h4></td><td><input type='text' name='productId' value='" + productId + "' class='input' required></input>");
            utility.removeProduct(productId, catalog);
            MySqlDataStoreUtilities.deleteProduct(productId);
            pw.print("</td></tr><tr><td>");
            pw.print("</tr><tr><td>");

            pw.print("<input type='hidden' name='image' value='" + image + "'>");

            pw.print("<h4>Product Name: </h4></td><td><input type='text' name='productName' value='" + name + "' class='input' required></input>");

            pw.print("</tr><tr><td>");
            pw.print("</td></tr><tr><td>");

            pw.print("<h4>Product Type</h4><td><select id='catalog' name='catalog' class='input'>" +
                    "<option value='FitnessWatch' selected>Fitness watch</option>" +
                    "<option value='SmartWatch'>Smart watch</option>" +
                    "<option value='Headphone'>Headphone</option>" +
                    "<option value='VirtualReality'>Virtual reality</option>" +
                    "<option value='PetTracker'>Pet tracker</option>" +
                    "<option value='TV'>TV</option>" +
                    "<option value='SoundSystem'>Sound system</option>" +
                    "<option value='Phone'>Phone</option>" +
                    "<option value='Laptop'>Laptop</option>" +
                    "<option value='VoiceAssistant'>Voice assistant</option>" +
                    "<option value='Accessory'>Accessory</option></select>");
            pw.print("</td></tr></td><tr><td>");


            pw.print("<h4>Price</h4></td><td><input type='text' name='price' value='" + price + "' class='input' required></input>");
            pw.print("</td></tr><tr><td>");
            pw.print("<h4>Manufacturer</h4></td><td><input type='text' name='manufacturer' value='" + manufacturer + "' class='input' required></input>");
            pw.print("</td></tr><tr><td>");

            pw.print("<h4>Condition</h4><td><select name='condition' class='input'>" +
                    "<option value='New' selected>New</option>" +
                    "<option value='Used'>Used</option>" +
                    "<option value='Refurbished'>Refurbished</option></select>");
            pw.print("</td></tr></td><tr><td>");

            pw.print("<h4>Discount</h4></td><td><input type='text' name='discount' value='" + discount + "' class='input' required></input>");
            pw.print("</td></tr><tr><td>");

            pw.print("<h4>Rebates</h4></td><td><input type='text' name='rebates' value='" + rebates + "' class='input' required></input>");
            pw.print("</td></tr><tr><td>");

            pw.print("<h4>Inventory</h4></td><td><input type='text' name='inventory' value='" + inventory + "' class='input' required></input>");
            pw.print("</td></tr><tr><td>");

            pw.print("<input type='submit' class='btnbuy' value='Update' style='float: right;height: 20px margin: 20px; margin-right: 10px;'></input>");
            pw.print("</td></tr><tr><td></td><td>");
            pw.print("</td></tr></table>");
            pw.print("</form></div></div></div>");
            utility.printHtml("Footer.html");
        }
    }
}
