import sun.util.resources.cldr.zh.CalendarData_zh_Hans_HK;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

@WebServlet("/Payment")

public class Payment extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter pw = response.getWriter();


        Utilities utility = new Utilities(request, pw);
        if (!utility.isLoggedin()) {
            HttpSession session = request.getSession(true);
            session.setAttribute("login_msg", "Please Login to Pay");
            response.sendRedirect("Login");
            return;
        }
        // get the payment details like credit card no address processed from cart servlet

        //get customer name
        HttpSession session = request.getSession();
        String userName = session.getAttribute("username").toString();

        String street = request.getParameter("street");
        String city = request.getParameter("city");
        String state = request.getParameter("state");
        String zipCode = request.getParameter("zipCode");
        String deliveryMethod = request.getParameter("deliveryMethod");

        String creditCardNo = request.getParameter("creditCardNo");
        String userAddress = street + ", " + city + ", " + state + ", " + zipCode;
        String storeLocation = request.getParameter("storeLocation");

        //用户信息
        String customer_name = request.getParameter("customer_name");
        String customer_age = request.getParameter("customer_age");
        String customer_occupation = request.getParameter("customer_occupation");

        //存储数量的map
        HashMap<String, Integer> qtyMap = (HashMap<String, Integer>) session.getAttribute("qtyMap");

        HashMap<String, Integer> hm = MySqlDataStoreUtilities.getUser_id();
        //存储商品种类的hashMap


        int user_id = hm.get(userName);


        if (!street.isEmpty() && !city.isEmpty() && !state.isEmpty() && !zipCode.isEmpty() && !creditCardNo.isEmpty() && !deliveryMethod.isEmpty()) {
            //生成唯一的订单号
            SimpleDateFormat df = new SimpleDateFormat("HHmmss");//设置日期格式
            int orderId = Integer.parseInt(df.format(new Date()));  //设置订单号为当前下单时间的时分秒

            //获取下单日期
            SimpleDateFormat deliveryDateFormat = new SimpleDateFormat("yyyy-MM-dd");//设置日期格式
            String day = deliveryDateFormat.format(new Date());
            String purchaseDay = day;
            Calendar c = Calendar.getInstance();
            try {
                c.setTime(deliveryDateFormat.parse(day));
            } catch (ParseException e) {
                e.printStackTrace();
            }
            c.add(Calendar.DATE, 14);  // number of days to add
            day = deliveryDateFormat.format(c.getTime());

            //根据value(storeLocation)找storeId
            String storeId = "";
            HashMap<String, CustomerAddress> stores = MySqlDataStoreUtilities.getStoreLocation();
            for (Map.Entry<String, CustomerAddress> entry : stores.entrySet()) {
                String location = entry.getValue().getStreet() + ", " + entry.getValue().getCity() + ", " + entry.getValue().getState() + ", " + entry.getValue().getZipCode();
                if (location.equals(storeLocation)) {
                    storeId = entry.getKey();
                    break;
                }
            }
            String streetPick = "";
            String cityPick = "";
            String statePick = "";
            String zipCodePick = "";
            for (CustomerAddress customerAddress : stores.values()) {
                String location = customerAddress.getStreet() + ", " + customerAddress.getCity() + ", " + customerAddress.getState() + ", " + customerAddress.getZipCode();
                if (location.equals(storeLocation)) {
                    streetPick = customerAddress.getStreet();
                    cityPick = customerAddress.getCity();
                    statePick = customerAddress.getState();
                    zipCodePick = customerAddress.getZipCode();
                }
            }


            //重复名字跳过
            HashSet<String> set = new HashSet<>();
//
            if ("pickup".equalsIgnoreCase(deliveryMethod)) {
                //获取用户的住址
                MySqlDataStoreUtilities.insertCustomerAddress(userName, streetPick, cityPick, statePick, zipCodePick);
                for (OrderItem oi : utility.getCustomerOrders()) {
                    String name = oi.getName();
                    if (set.contains(name)) {
                        continue;
                    } else {
                        set.add(name);
                    }
                    //总价
                    double totalsales = (oi.getPrice() - oi.getDiscount()) * qtyMap.get(oi.getName());
                    double totaldiscount = oi.getDiscount() * qtyMap.get(oi.getName());
                    utility.storePayment(user_id, userName, storeLocation, creditCardNo, orderId, purchaseDay, day, oi.getName(), oi.getProductType(), qtyMap.get(oi.getName()), oi.getPrice(), 0, totaldiscount, totalsales, storeId, storeLocation);
                    utility.storeTransactions(user_id,customer_name,customer_age,customer_occupation,creditCardNo,orderId,oi.getName(),oi.getName(),oi.getProductType(),oi.getRetailer(),"Store pickup",zipCodePick,userName);
                }
            } else if ("delivery".equalsIgnoreCase(deliveryMethod)) {
                //获取用户的住址
                MySqlDataStoreUtilities.insertCustomerAddress(userName, street, city, state, zipCode);
                for (OrderItem oi : utility.getCustomerOrders()) {
                    String name = oi.getName();
                    if (set.contains(name)) {
                        continue;
                    } else {
                        set.add(name);
                    }
                    //总价
                    double totalsales = (oi.getPrice() - oi.getDiscount()) * qtyMap.get(oi.getName());
                    double totaldiscount = oi.getDiscount() * qtyMap.get(oi.getName());
                    utility.storePayment(user_id, userName, userAddress, creditCardNo, orderId, purchaseDay, day, oi.getName(), oi.getProductType(), qtyMap.get(oi.getName()), oi.getPrice(), 18, totaldiscount, totalsales, "none", "none");
                    utility.storeTransactions(user_id,customer_name,customer_age,customer_occupation,creditCardNo,orderId,oi.getName(),oi.getName(),oi.getProductType(),oi.getRetailer(),"Home Delivery",zipCode,userName);
                }
            } else {
                printError(utility, pw);
            }
            OrdersHashMap.orders.remove(utility.username());
            utility.printHtml("Header.html");
            utility.printHtml("LeftNavigationBar.html");
            pw.print("<div id='content'><div class='post'><h2 class='title meta'>");
            pw.print("<a style='font-size: 24px;'>Order</a>");
            pw.print("</h2><div class='entry'>");

            pw.print("<h2>Your Order");
            pw.print("&nbsp&nbsp");
            pw.print("is stored ");
            pw.print("<br>Your Order No is " + (orderId));
            if (!storeLocation.isEmpty())
                pw.print("<br/>Delivery Method: Pick up at " + storeLocation);
            else
                pw.print("<br/>Delivery Method: Home Delivery to  " + userAddress);

            //获得delivery date
//            pw.print("<br>Estimated delivery date: " + day);

            pw.print("</h2></div></div></div>");
            utility.printHtml("Footer.html");
        } else {
            printError(utility, pw);
        }

    }

    public void printError(Utilities utility, PrintWriter pw) {
        utility.printHtml("Header.html");
        utility.printHtml("LeftNavigationBar.html");
        pw.print("<div id='content'><div class='post'><h2 class='title meta'>");
        pw.print("<a style='font-size: 24px;'>Order</a>");
        pw.print("</h2><div class='entry'>");

        pw.print("<h4 style='color:red'>Please enter valid info</h4>");
        pw.print("</h2></div></div></div>");
        utility.printHtml("Footer.html");
    }
}
